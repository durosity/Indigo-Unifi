# Unifi Protect Plugin for Indigo Domotics

A plugin for Indigo Domotics 2025.1 that integrates Unifi Protect security cameras and NVRs/controllers. This plugin provides real-time monitoring and control of Unifi Protect devices through websocket connections for immediate event notifications.

## Features

### Multi-Controller Support
- Support for multiple Unifi Protect controllers
- Each controller is a separate device that can be configured independently
- Cameras link to their parent controller device

### Real-Time Updates
- Uses websockets for immediate event notifications (no polling)
- Instant motion detection alerts
- Real-time person, vehicle, and package detection
- Doorbell ring notifications
- Connection status monitoring

### Camera Monitoring
- Motion detection with timestamps
- Smart detection: Person, Vehicle, Package
- Doorbell ring detection and history
- Dark/light sensor status
- Camera connection status
- Voltage monitoring (for supported cameras)
- Recording mode status
- IR mode status
- Status light indicator

### Camera Control
- Set recording mode (Always, Detections Only, Never)
- Control IR mode (Auto, On, Off, Auto Filter Only)
- Enable/disable status light
- Configure overlays (name, date, logo)
- Set custom status messages
- Enable/disable detection types
- Reboot cameras
- Take snapshots

### Video Access
- RTSP URLs for each quality level (High, Medium, Low)
- Snapshot URL for still images
- Direct access for control pages and variables

### Controller Management
- View controller statistics (uptime, CPU, memory, storage)
- Firmware version tracking
- Camera count monitoring
- Controller restart capability

## Requirements

- Indigo Domotics 2025.1 or later
- Unifi Protect controller (UDM Pro, UNVR, CloudKey+, etc.)
- Local admin account on Unifi Protect (SSO accounts not supported)
- Network access to Unifi Protect controller

## Installation

1. Download the plugin
2. Double-click the `.indigoPlugin` file to install
3. Enable the plugin in Indigo

## Configuration

### Step 1: Create a Controller Device

1. Create a new device in Indigo
2. Select "Unifi Protect Controller" as the device type
3. Configure the following:
   - **Controller IP Address**: The local IP address of your Unifi Protect controller
   - **Port**: Usually 443 (HTTPS)
   - **Username**: Local admin username
   - **Password**: Local admin password
   - **Verify SSL Certificate**: Enable if you have a valid SSL certificate (usually leave unchecked for local access)

### Step 2: Discover Cameras

1. After the controller device is created and connected, open its device settings
2. Click the "Discover and Create Devices" button
3. The plugin will automatically create device entries for all cameras on the controller

Alternatively, you can manually create camera devices:
1. Create a new device in Indigo
2. Select "Unifi Protect Camera" as the device type
3. Select the controller from the dropdown
4. Enter the Camera ID (found in Unifi Protect settings)
5. Enter a friendly name for the camera

## Device States

### Controller States
- **Status**: Connection status
- **Connected**: Boolean connection state
- **Uptime**: Controller uptime
- **CPU Usage**: Current CPU utilization
- **Memory Usage**: Current memory utilization
- **Storage Used**: Used storage in bytes
- **Storage Total**: Total storage capacity in bytes
- **Firmware Version**: Current firmware version
- **Camera Count**: Number of connected cameras

### Camera States
- **Motion Detected**: Boolean state for motion detection
- **Last Motion**: Timestamp of last motion event
- **Person Detected**: Boolean state for person detection
- **Last Person Detection**: Timestamp of last person detection
- **Vehicle Detected**: Boolean state for vehicle detection
- **Package Detected**: Boolean state for package detection
- **Doorbell Ringing**: Boolean state for doorbell ring
- **Last Doorbell Ring**: Timestamp of last doorbell ring
- **Is Dark**: Boolean indicating if camera detects darkness
- **Voltage**: Current voltage (for supported cameras)
- **Recording Mode**: Current recording mode
- **IR Mode**: Current IR LED mode
- **Status Light**: Boolean for status light state
- **Status**: Camera connection status
- **Is Connected**: Boolean connection state
- **RTSP URL (High/Medium/Low)**: Stream URLs for each quality
- **Snapshot URL**: URL for still image snapshots
- **Firmware Version**: Camera firmware version
- **Model**: Camera model

## Actions

### Controller Actions
- **Restart Controller**: Restart the Unifi Protect controller

### Camera Actions
- **Set Recording Mode**: Change recording behavior (Always/Detections/Never)
- **Set IR Mode**: Control infrared LEDs (Auto/On/Off/Auto Filter Only)
- **Set Status Light**: Enable or disable the camera status light
- **Set Overlay Settings**: Control on-screen display elements
- **Set Status Message**: Set a custom status message
- **Enable Detection Types**: Configure which detection types are active
- **Reboot Camera**: Reboot the camera
- **Take Snapshot**: Capture a still image (optionally save to file)

## Triggers

The plugin supports the following trigger events:
- **Motion Detected**: Triggered when motion is detected
- **Person Detected**: Triggered when a person is detected
- **Vehicle Detected**: Triggered when a vehicle is detected
- **Package Detected**: Triggered when a package is detected
- **Doorbell Ring**: Triggered when doorbell is pressed
- **Camera Connected**: Triggered when camera comes online
- **Camera Disconnected**: Triggered when camera goes offline
- **Camera Is Dark**: Triggered when camera detects darkness
- **Camera Is Light**: Triggered when camera detects light

Each trigger can be configured to fire for specific cameras.

## Usage Examples

### Motion Detection Alert
Create a trigger for "Motion Detected" on your front door camera, then use it to:
- Turn on lights
- Send a notification
- Start recording
- Announce via text-to-speech

### Doorbell Integration
Create a trigger for "Doorbell Ring" to:
- Play a chime sound
- Flash lights
- Send notification with snapshot
- Unlock door after verification

### Smart Detection
Use person detection to:
- Only trigger alerts for people (not animals)
- Log visitor times
- Control access systems

### Control Page Integration
Use the snapshot URL state in Indigo control pages:
- Display live camera feeds
- Create security dashboards
- Monitor multiple cameras

## Troubleshooting

### Controller Won't Connect
- Verify IP address and port are correct
- Ensure username/password are for a local admin account (not SSO)
- Check network connectivity to the controller
- Try disabling SSL verification

### Cameras Not Updating
- Verify controller device is connected
- Check camera is online in Unifi Protect interface
- Restart controller device in Indigo
- Check Indigo log for websocket errors

### Missing RTSP URLs
- Verify RTSP is enabled on the camera in Unifi Protect settings
- Some camera models may not support all quality levels
- Check that channels are properly configured

### Detection Events Not Triggering
- Verify detection types are enabled in Unifi Protect
- Check that triggers are properly configured in Indigo
- Ensure camera has required license for smart detections

## Future Enhancements

This plugin is designed with extensibility in mind. Planned future additions include:
- Unifi Access integration (door locks, access points)
- Additional device types (sensors, lights, etc.)
- Event playback and clip management
- Advanced analytics and reporting

## Support

For issues, questions, or feature requests, please check the Indigo Forums.

## License

This plugin uses the uiprotect library which is licensed under MIT.

## Credits

- Built using the uiprotect Python library (https://github.com/uilibs/uiprotect)
- Designed for Indigo Domotics 2025.1 with API v3.4

## Version History

### 1.0.0 (Initial Release)
- Multi-controller support
- Real-time websocket events
- Camera monitoring and control
- Smart detection support
- Doorbell integration
- Complete action and trigger support
