#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
UniFi Plugin for Indigo Domotics
Supports UniFi Protect and UniFi Network with WebSocket real-time updates
Direct API implementation - no external dependencies required
"""

import indigo
import asyncio
import threading
from datetime import datetime
import traceback
import json
import ssl
import urllib.request
import urllib.error
import urllib.parse
from http.cookiejar import CookieJar
import base64
import time
import socket
import struct
import hashlib
import os


################################################################################
class UnifiProtectAPI:
    """Direct UniFi Protect API implementation"""
    
    def __init__(self, host, port, username, password, verify_ssl=False):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.base_url = f"https://{host}:{port}"
        self.headers = {}
        self.cookies = CookieJar()
        self.bootstrap_data = None
        
        # Create SSL context
        if not verify_ssl:
            self.ssl_context = ssl._create_unverified_context()
        else:
            self.ssl_context = ssl.create_default_context()
            
        # Create URL opener with cookies
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookies),
            urllib.request.HTTPSHandler(context=self.ssl_context)
        )
        
    def _make_request(self, method, path, data=None, timeout=30, retry=True):
        """Make HTTP request to Protect API"""
        url = f"{self.base_url}{path}"
        
        # Prepare request
        if data:
            data = json.dumps(data).encode('utf-8')
            
        request = urllib.request.Request(url, data=data, method=method)
        
        # Add headers
        request.add_header('Content-Type', 'application/json')
        for key, value in self.headers.items():
            request.add_header(key, value)
            
        try:
            response = self.opener.open(request, timeout=timeout)
            response_data = response.read().decode('utf-8')
            
            if not response_data:
                return {}
                
            # Try to parse as JSON
            try:
                return json.loads(response_data)
            except json.JSONDecodeError as json_err:
                # Response is not JSON - might be HTML error page
                if response_data.startswith('<'):
                    raise Exception(f"Got HTML response instead of JSON (status {response.status}). Check authentication.")
                else:
                    raise Exception(f"Invalid JSON response: {response_data[:200]}")
            
        except urllib.error.HTTPError as e:
            # Handle 401 Unauthorized - session expired, re-login and retry once
            if e.code == 401 and retry:
                try:
                    self.login()
                    return self._make_request(method, path, data, timeout, retry=False)
                except:
                    pass
                    
            error_body = e.read()
            error_data = error_body.decode('utf-8') if error_body else ''
            raise Exception(f"HTTP {e.code}: {error_data}")
        except urllib.error.URLError as e:
            if "timed out" in str(e):
                raise Exception(f"Connection timeout after {timeout}s - check IP address ({self.host}) and port ({self.port})")
            else:
                raise Exception(f"Network error: {str(e)} - verify controller IP/hostname")
        except Exception as e:
            if "HTTP" in str(e) or "JSON" in str(e) or "HTML" in str(e):
                raise  # Re-raise our custom exceptions
            raise Exception(f"Request failed: {str(e)}")
            
    def login(self):
        """Authenticate with UniFi Protect"""
        # Try to login with credentials
        login_data = {
            "username": self.username,
            "password": self.password,
            "rememberMe": True
        }
        
        try:
            result = self._make_request('POST', '/api/auth/login', login_data)
            
            # Extract CSRF token from cookies - UniFi uses 'TOKEN' cookie for CSRF
            csrf_token = None
            jwt_token = None
            all_cookies = []
            for cookie in self.cookies:
                all_cookies.append(f"{cookie.name}={cookie.value[:20]}...")
                # Look for TOKEN cookie (uppercase) - this is the JWT
                if cookie.name == 'TOKEN':
                    jwt_token = cookie.value
                    break
            
            # If we have a JWT token, try to extract the csrfToken from inside it
            if jwt_token:
                try:
                    import base64
                    # JWT format: header.payload.signature
                    parts = jwt_token.split('.')
                    if len(parts) >= 2:
                        # Decode the payload (add padding if needed)
                        payload = parts[1]
                        # Add padding if needed
                        padding = 4 - (len(payload) % 4)
                        if padding != 4:
                            payload += '=' * padding
                        decoded = base64.b64decode(payload)
                        payload_json = json.loads(decoded)
                        # Extract the csrfToken from the JWT payload
                        if 'csrfToken' in payload_json:
                            csrf_token = payload_json['csrfToken']
                except Exception as decode_error:
                    # If we can't decode, fall back to using the whole JWT
                    csrf_token = jwt_token
            
            # Store debug info
            self._cookie_debug = f"Cookies: {', '.join(all_cookies)}"
            if csrf_token and jwt_token and csrf_token != jwt_token:
                self._token_debug = f"CSRF Token: Extracted from JWT ({csrf_token[:20]}...)"
            elif csrf_token:
                self._token_debug = f"CSRF Token: Using full JWT"
            else:
                self._token_debug = f"CSRF Token: NOT FOUND"
            
            # If we found a token, add it as X-CSRF-Token header for write operations
            if csrf_token:
                self.headers['X-CSRF-Token'] = csrf_token
            
            # Also try to get token from response body if present
            if isinstance(result, dict) and 'token' in result:
                self.headers['X-CSRF-Token'] = result['token']
                self._token_debug = f"CSRF Token: Found in response body"
                    
            return True
        except urllib.error.URLError as e:
            raise Exception(f"Login failed - Network error: {str(e)}. Check IP address and port.")
        except urllib.error.HTTPError as e:
            raise Exception(f"Login failed - HTTP {e.code}: {e.reason}")
        except Exception as e:
            raise Exception(f"Login failed: {str(e)}")
            
    def get_bootstrap(self):
        """Get full system bootstrap data"""
        try:
            # Bootstrap can be large, use longer timeout
            self.bootstrap_data = self._make_request('GET', '/proxy/protect/api/bootstrap', timeout=60)
            return self.bootstrap_data
        except Exception as e:
            raise Exception(f"Failed to get bootstrap: {str(e)}")
            
    def get_camera(self, camera_id):
        """Get camera by ID"""
        if not self.bootstrap_data:
            self.get_bootstrap()
            
        cameras = self.bootstrap_data.get('cameras', [])
        for camera in cameras:
            if camera.get('id') == camera_id:
                return camera
        return None
        
    def get_cameras(self):
        """Get all cameras"""
        if not self.bootstrap_data:
            self.get_bootstrap()
        return self.bootstrap_data.get('cameras', [])
        
    def get_nvr(self):
        """Get NVR info"""
        if not self.bootstrap_data:
            self.get_bootstrap()
        return self.bootstrap_data.get('nvr', {})
        
    def update_camera(self, camera_id, settings):
        """Update camera settings - sends only the exact changes requested"""
        path = f'/proxy/protect/api/cameras/{camera_id}'
        
        # Store request details for debugging
        self._last_update_path = path
        self._last_update_settings = settings
        
        return self._make_request('PATCH', path, settings)
    
    def _deep_merge(self, dest, src):
        """Deep merge src dict into dest dict"""
        for key, value in src.items():
            if key in dest and isinstance(dest[key], dict) and isinstance(value, dict):
                self._deep_merge(dest[key], value)
            else:
                dest[key] = value
        
    def reboot_camera(self, camera_id):
        """Reboot a camera"""
        path = f'/proxy/protect/api/cameras/{camera_id}/reboot'
        return self._make_request('POST', path)
        
    def restart_nvr(self):
        """Restart the NVR"""
        return self._make_request('POST', '/proxy/protect/api/nvr/reboot')


################################################################################
class UnifiNetworkAPI:
    """Direct UniFi Network API implementation"""
    
    def __init__(self, host, port, username, password, site='default', verify_ssl=False):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.site = site
        self.verify_ssl = verify_ssl
        self.base_url = f"https://{host}:{port}"
        self.headers = {}
        self.cookies = CookieJar()
        
        # Create SSL context
        if not verify_ssl:
            self.ssl_context = ssl._create_unverified_context()
        else:
            self.ssl_context = ssl.create_default_context()
            
        # Create URL opener with cookies
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookies),
            urllib.request.HTTPSHandler(context=self.ssl_context)
        )
        
    def _make_request(self, method, path, data=None, timeout=30, retry=True):
        """Make HTTP request to Network API"""
        url = f"{self.base_url}{path}"
        
        # Prepare request
        if data:
            data = json.dumps(data).encode('utf-8')
            
        request = urllib.request.Request(url, data=data, method=method)
        
        # Add headers
        request.add_header('Content-Type', 'application/json')
        for key, value in self.headers.items():
            request.add_header(key, value)
            
        try:
            response = self.opener.open(request, timeout=timeout)
            response_data = response.read().decode('utf-8')
            
            if not response_data:
                return {}
            
            # Check if response looks like HTML (controller returning error page)
            if response_data.strip().startswith('<'):
                raise Exception("Controller returned HTML error page (API may be temporarily unavailable)")
                
            return json.loads(response_data)
            
        except urllib.error.HTTPError as e:
            # Handle 401 Unauthorized - session expired, re-login and retry once
            if e.code == 401 and retry:
                try:
                    self.login()
                    return self._make_request(method, path, data, timeout, retry=False)
                except:
                    pass
            
            error_body = e.read()
            error_data = error_body.decode('utf-8') if error_body else ''
            raise Exception(f"HTTP {e.code}: {error_data}")
        except urllib.error.URLError as e:
            raise Exception(f"Network error: {str(e)}")
        except json.JSONDecodeError as e:
            # JSON parsing failed - probably HTML error page
            preview = response_data[:100] if len(response_data) > 100 else response_data
            raise Exception(f"Invalid JSON response (controller may be restarting): {preview}...")
        except Exception as e:
            raise Exception(f"Request failed: {str(e)}")
            
    def login(self):
        """Authenticate with UniFi Network"""
        login_data = {
            "username": self.username,
            "password": self.password,
            "remember": True
        }
        
        try:
            result = self._make_request('POST', '/api/auth/login', login_data)
            
            # Extract CSRF token similar to Protect
            csrf_token = None
            jwt_token = None
            for cookie in self.cookies:
                if cookie.name == 'TOKEN':
                    jwt_token = cookie.value
                    break
            
            if jwt_token:
                try:
                    parts = jwt_token.split('.')
                    if len(parts) >= 2:
                        payload = parts[1]
                        padding = 4 - (len(payload) % 4)
                        if padding != 4:
                            payload += '=' * padding
                        decoded = base64.b64decode(payload)
                        payload_json = json.loads(decoded)
                        if 'csrfToken' in payload_json:
                            csrf_token = payload_json['csrfToken']
                except Exception:
                    csrf_token = jwt_token
            
            if csrf_token:
                self.headers['X-CSRF-Token'] = csrf_token
                    
            return True
        except Exception as e:
            raise Exception(f"Login failed: {str(e)}")
    
    def get_site_info(self):
        """Get site information"""
        path = f'/proxy/network/api/s/{self.site}/self'
        return self._make_request('GET', path)
    
    def get_devices(self):
        """Get all network devices (switches, APs, gateways)"""
        path = f'/proxy/network/api/s/{self.site}/stat/device'
        result = self._make_request('GET', path)
        return result.get('data', [])
    
    def get_device(self, device_id):
        """Get specific device by ID"""
        devices = self.get_devices()
        for device in devices:
            if device.get('_id') == device_id or device.get('mac') == device_id:
                return device
        return None
    
    def get_clients(self):
        """Get all active clients"""
        path = f'/proxy/network/api/s/{self.site}/stat/sta'
        result = self._make_request('GET', path)
        return result.get('data', [])
    
    def get_all_clients(self):
        """Get all clients (including known/inactive)"""
        path = f'/proxy/network/api/s/{self.site}/rest/user'
        result = self._make_request('GET', path)
        return result.get('data', [])
    
    def get_client(self, mac):
        """Get specific client by MAC address"""
        # Try active clients first
        clients = self.get_clients()
        for client in clients:
            if client.get('mac', '').lower() == mac.lower():
                return client
        
        # Try all clients
        all_clients = self.get_all_clients()
        for client in all_clients:
            if client.get('mac', '').lower() == mac.lower():
                return client
        
        return None
    
    def block_client(self, mac):
        """Block a client"""
        path = f'/proxy/network/api/s/{self.site}/cmd/stamgr'
        data = {
            "cmd": "block-sta",
            "mac": mac.lower()
        }
        return self._make_request('POST', path, data)
    
    def unblock_client(self, mac):
        """Unblock a client"""
        path = f'/proxy/network/api/s/{self.site}/cmd/stamgr'
        data = {
            "cmd": "unblock-sta",
            "mac": mac.lower()
        }
        return self._make_request('POST', path, data)
    
    def reconnect_client(self, mac):
        """Force client to reconnect (kick)"""
        path = f'/proxy/network/api/s/{self.site}/cmd/stamgr'
        data = {
            "cmd": "kick-sta",
            "mac": mac.lower()
        }
        return self._make_request('POST', path, data)
    
    def set_device_name(self, device_id, name):
        """Set device name"""
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {"name": name}
        return self._make_request('PUT', path, data)
    
    def set_device_led(self, device_id, enabled):
        """Enable/disable device LED"""
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {"led_override": "on" if enabled else "off"}
        return self._make_request('PUT', path, data)
    
    def locate_device(self, device_id, enabled=True):
        """Flash device LEDs for location"""
        path = f'/proxy/network/api/s/{self.site}/cmd/devmgr'
        data = {
            "cmd": "set-locate",
            "mac": device_id,
            "site": self.site,
            "enabled": enabled
        }
        return self._make_request('POST', path, data)
    
    def restart_device(self, device_id):
        """Restart a network device"""
        path = f'/proxy/network/api/s/{self.site}/cmd/devmgr'
        data = {
            "cmd": "restart",
            "mac": device_id
        }
        return self._make_request('POST', path, data)
    
    def disable_device(self, device_id):
        """Disable a network device"""
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {"disabled": True}
        return self._make_request('PUT', path, data)
    
    def enable_device(self, device_id):
        """Enable a network device"""
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {"disabled": False}
        return self._make_request('PUT', path, data)
    
    def set_port_override(self, device_id, port_idx, overrides):
        """
        Set port overrides on a switch port
        
        Args:
            device_id: Device _id (not MAC)
            port_idx: Port index number
            overrides: Dict of port settings to override (e.g. {"poe_mode": "auto"})
        """
        # First, get current device config to preserve existing port_overrides
        device = self.get_device(device_id)
        if not device:
            return None
        
        # Get existing port overrides
        existing_overrides = device.get('port_overrides', [])
        
        # Find if this port already has an override
        port_override_found = False
        updated_overrides = []
        
        for override in existing_overrides:
            if override.get('port_idx') == port_idx:
                # Update this port's override
                updated_override = override.copy()
                updated_override.update(overrides)
                updated_overrides.append(updated_override)
                port_override_found = True
            else:
                # Keep other ports' overrides unchanged
                updated_overrides.append(override)
        
        # If port didn't have an override before, add it
        if not port_override_found:
            updated_overrides.append({
                "port_idx": port_idx,
                **overrides
            })
        
        # Send updated overrides
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {
            "port_overrides": updated_overrides
        }
        
        # Debug logging - show what we're sending
        if hasattr(self, 'logger') and hasattr(self, 'debug') and self.debug:
            self.logger.debug(f"set_port_override: Sending to {path}")
            self.logger.debug(f"  Port {port_idx} override: {overrides}")
            self.logger.debug(f"  Total overrides being sent: {len(updated_overrides)}")
        
        return self._make_request('PUT', path, data)
    
    def enable_port(self, device_id, port_idx):
        """Enable a switch port by removing overrides that would disable it"""
        device = self.get_device(device_id)
        if not device:
            return None
        
        existing_overrides = device.get('port_overrides', [])
        updated_overrides = []
        
        # Remove any override for this port to let it use default settings
        for override in existing_overrides:
            if override.get('port_idx') != port_idx:
                updated_overrides.append(override)
        
        path = f'/proxy/network/api/s/{self.site}/rest/device/{device_id}'
        data = {"port_overrides": updated_overrides}
        return self._make_request('PUT', path, data)
    
    def disable_port(self, device_id, port_idx):
        """Disable a switch port by forcing link down"""
        # Force port down by disabling autoneg and setting invalid speed
        # This effectively disables the port without a proper "disabled" flag
        return self.set_port_override(device_id, port_idx, {
            "autoneg": False,
            "speed": 10,  # Force to 10Mbps
            "full_duplex": False  # Force half-duplex
        })
    
    def set_port_poe_mode(self, device_id, port_idx, poe_mode):
        """
        Set PoE mode on a switch port
        
        Args:
            poe_mode: "off", "auto", "pasv24", or "passthrough"
        """
        return self.set_port_override(device_id, port_idx, {"poe_mode": poe_mode})
    
    def cycle_port_poe(self, device_mac, port_idx):
        """Power cycle a port's PoE (official UniFi power-cycle command)"""
        path = f'/proxy/network/api/s/{self.site}/cmd/devmgr'
        data = {
            "cmd": "power-cycle",
            "mac": device_mac,
            "port_idx": port_idx
        }
        return self._make_request('POST', path, data)
    
    def get_wlans(self):
        """Get all SSIDs/WLANs"""
        path = f'/proxy/network/api/s/{self.site}/rest/wlanconf'
        result = self._make_request('GET', path)
        return result.get('data', [])
    
    def get_networks(self):
        """Get all networks/VLANs"""
        path = f'/proxy/network/api/s/{self.site}/rest/networkconf'
        result = self._make_request('GET', path)
        return result.get('data', [])


################################################################################
class UnifiWebSocket:
    """WebSocket handler for real-time UniFi updates"""
    
    def __init__(self, host, port, cookies, ssl_context, update_callback, logger, debug=False, ws_path="/proxy/network/wss/s/default/events"):
        self.host = host
        self.port = port
        self.cookies = cookies
        self.ssl_context = ssl_context
        self.update_callback = update_callback
        self.logger = logger
        self.debug = debug
        self.ws_path = ws_path
        self.ws_thread = None
        self.stop_flag = False
        self.connected = False
        self.reconnect_delay = 5
        
    def start(self):
        """Start WebSocket connection in background thread"""
        self.stop_flag = False
        self.ws_thread = threading.Thread(target=self._ws_loop, daemon=True)
        self.ws_thread.start()
        
    def stop(self):
        """Stop WebSocket connection"""
        self.stop_flag = True
        if self.ws_thread:
            self.ws_thread.join(timeout=5)
    
    def _ws_loop(self):
        """Main WebSocket connection loop with auto-reconnect"""
        while not self.stop_flag:
            try:
                if self.debug:
                    self.logger.debug(f"WebSocket: Connecting to {self.host}:{self.port}{self.ws_path}")
                
                # Build cookie header
                cookie_header = "; ".join([f"{c.name}={c.value}" for c in self.cookies])
                
                # Create socket connection
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)
                
                # Wrap with SSL
                try:
                    wrapped_sock = self.ssl_context.wrap_socket(sock, server_hostname=self.host)
                    wrapped_sock.connect((self.host, self.port))
                except Exception as ssl_error:
                    if self.debug:
                        self.logger.debug(f"WebSocket SSL connection failed: {ssl_error}")
                    raise
                
                # Generate WebSocket key
                import base64
                import hashlib
                import os
                ws_key = base64.b64encode(os.urandom(16)).decode('utf-8')
                
                # Send WebSocket upgrade request
                upgrade_request = (
                    f"GET {self.ws_path} HTTP/1.1\r\n"
                    f"Host: {self.host}:{self.port}\r\n"
                    f"Upgrade: websocket\r\n"
                    f"Connection: Upgrade\r\n"
                    f"Cookie: {cookie_header}\r\n"
                    f"Sec-WebSocket-Key: {ws_key}\r\n"
                    f"Sec-WebSocket-Version: 13\r\n"
                    f"Origin: https://{self.host}:{self.port}\r\n"
                    f"\r\n"
                ).encode()
                
                wrapped_sock.send(upgrade_request)
                
                # Read upgrade response
                response = b""
                while b"\r\n\r\n" not in response:
                    chunk = wrapped_sock.recv(1024)
                    if not chunk:
                        raise Exception("Connection closed during handshake")
                    response += chunk
                
                response_str = response.decode('utf-8', errors='ignore')
                
                # Check for successful upgrade
                if "101" not in response_str.split('\r\n')[0]:
                    if self.debug:
                        self.logger.debug(f"WebSocket handshake failed. Response: {response_str[:200]}")
                    raise Exception("WebSocket upgrade failed - check response")
                
                self.connected = True
                if self.debug:
                    self.logger.debug("WebSocket: Connected successfully")
                
                # Read messages
                while not self.stop_flag and self.connected:
                    try:
                        # Read WebSocket frame
                        frame_data = self._read_ws_frame(wrapped_sock)
                        if frame_data:
                            try:
                                message = json.loads(frame_data.decode('utf-8'))
                                if self.debug:
                                    self.logger.debug(f"WebSocket message: {message.get('meta', {}).get('message', 'unknown')}")
                                
                                # Pass to callback
                                if self.update_callback:
                                    self.update_callback(message)
                            except json.JSONDecodeError:
                                # Binary/control frames are normal, don't spam logs
                                pass
                    except socket.timeout:
                        # Send ping to keep connection alive
                        self._send_ping(wrapped_sock)
                    except Exception as e:
                        if self.debug:
                            self.logger.debug(f"WebSocket read error: {e}")
                        break
                
                wrapped_sock.close()
                
            except Exception as e:
                if not self.stop_flag:
                    # Don't log as warning if it's a known connection issue
                    if "upgrade failed" in str(e).lower() or "handshake" in str(e).lower():
                        if self.debug:
                            self.logger.debug(f"WebSocket connection failed: {e}. Will retry in {self.reconnect_delay}s")
                    else:
                        self.logger.warning(f"WebSocket connection error: {e}. Reconnecting in {self.reconnect_delay}s")
                self.connected = False
                
            # Wait before reconnecting
            if not self.stop_flag:
                time.sleep(self.reconnect_delay)
    
    def _read_ws_frame(self, sock):
        """Read a WebSocket frame"""
        # Read first 2 bytes
        header = sock.recv(2)
        if len(header) < 2:
            return None
        
        # Parse frame header
        fin = (header[0] & 0x80) != 0
        opcode = header[0] & 0x0F
        masked = (header[1] & 0x80) != 0
        payload_len = header[1] & 0x7F
        
        # Handle extended payload length
        if payload_len == 126:
            ext_len = sock.recv(2)
            payload_len = struct.unpack('>H', ext_len)[0]
        elif payload_len == 127:
            ext_len = sock.recv(8)
            payload_len = struct.unpack('>Q', ext_len)[0]
        
        # Read masking key if present
        if masked:
            masking_key = sock.recv(4)
        
        # Read payload
        payload = b''
        while len(payload) < payload_len:
            chunk = sock.recv(payload_len - len(payload))
            if not chunk:
                break
            payload += chunk
        
        # Unmask if needed
        if masked:
            unmasked = bytearray(payload)
            for i in range(len(unmasked)):
                unmasked[i] ^= masking_key[i % 4]
            payload = bytes(unmasked)
        
        # Handle close frame
        if opcode == 0x8:
            self.connected = False
            return None
        
        return payload
    
    def _send_ping(self, sock):
        """Send WebSocket ping frame"""
        try:
            # Ping frame: FIN=1, opcode=9, no mask, no payload
            ping_frame = struct.pack('BB', 0x89, 0)
            sock.send(ping_frame)
        except Exception:
            pass


################################################################################
class Plugin(indigo.PluginBase):
    """Main plugin class"""

    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        super(Plugin, self).__init__(pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
        self.debug = pluginPrefs.get("showDebugInfo", False)
        
        # Controllers dictionary: {deviceId: controller_info}
        self.controllers = {}
        
        # Client tracking
        # Track deleted client MACs to prevent auto-recreation
        self.deleted_clients = set(pluginPrefs.get("deletedClients", []))
        
        # Polling thread
        self.polling_thread = None
        self.stop_polling = False
    
    def closedPrefsConfigUi(self, valuesDict, userCancelled):
        """Called when plugin config dialog is closed"""
        if not userCancelled:
            self.debug = valuesDict.get("showDebugInfo", False)
            self.logger.info(f"Debug mode: {'enabled' if self.debug else 'disabled'}")
            
            # Update auto-create settings
            auto_create = valuesDict.get("autoCreateClients", True)
            known_only = valuesDict.get("autoCreateKnownOnly", True)
            if auto_create:
                mode = "known clients only" if known_only else "all clients"
                self.logger.info(f"Client auto-discovery enabled: {mode}")
            else:
                self.logger.info("Client auto-discovery disabled")
        return True
        
    ########################################
    def startup(self):
        """Called when plugin starts"""
        self.logger.info("Starting UniFi Plugin v1.7.7 (Phase 3A-pt1 - Name Tags Fixed)")
        
        # Start polling thread
        self.stop_polling = False
        self.polling_thread = threading.Thread(target=self._polling_loop, daemon=True)
        self.polling_thread.start()
        
    def shutdown(self):
        """Called when plugin stops"""
        self.logger.info("Shutting down UniFi Plugin")
        
        # Stop polling
        self.stop_polling = True
        if self.polling_thread:
            self.polling_thread.join(timeout=5)
            
        # Stop WebSocket connections and disconnect all controllers
        for controller_id in list(self.controllers.keys()):
            controller = self.controllers[controller_id]
            if 'websocket' in controller:
                controller['websocket'].stop()
            if 'protect_websocket' in controller:
                controller['protect_websocket'].stop()
        
        self.controllers.clear()
    
    ########################################
    # Trigger Methods
    ########################################
    
    def triggerStartProcessing(self, trigger):
        """Called when a trigger starts"""
        if self.debug:
            self.logger.debug(f"Trigger started: {trigger.name} (Type: {trigger.pluginTypeId})")
    
    def triggerStopProcessing(self, trigger):
        """Called when a trigger stops"""
        if self.debug:
            self.logger.debug(f"Trigger stopped: {trigger.name}")
        
    ########################################
    # Device Management
    ########################################
    
    def deviceStartComm(self, dev):
        """Called when device communication starts"""
        if dev.deviceTypeId == "unifiController":
            self.start_controller(dev)
        elif dev.deviceTypeId == "protectCamera":
            self.setup_camera(dev)
        elif dev.deviceTypeId == "networkDevice":
            self.setup_network_device(dev)
        elif dev.deviceTypeId == "unifiPort":
            self.setup_port_device(dev)
        elif dev.deviceTypeId == "clientDevice":
            self.setup_client_device(dev)
            
    def deviceStopComm(self, dev):
        """Called when device communication stops"""
        if dev.deviceTypeId == "unifiController":
            self.stop_controller(dev.id)
    
    def deviceUpdated(self, oldDev, newDev):
        """Called when device is updated"""
        # Handle device enable/disable state changes
        if newDev.deviceTypeId == "networkDevice":
            if oldDev.onState != newDev.onState:
                # On/Off state changed - update device
                self.update_network_device_enabled(newDev)
        # Note: For port devices, we handle control via actionControlDevice only
        # to avoid double-calling when buttons are pressed
    
    def didDeviceCommPropertyChange(self, oldDev, newDev):
        """Called when device properties change - refresh state if control mode changed"""
        if newDev.deviceTypeId == "unifiPort":
            old_mode = oldDev.pluginProps.get("controlMode", "poe")
            new_mode = newDev.pluginProps.get("controlMode", "poe")
            
            if old_mode != new_mode:
                # Control mode changed - refresh the device state
                self.logger.info(f"{newDev.name}: Control mode changed from {old_mode} to {new_mode}, refreshing state")
                controller_id = int(newDev.pluginProps.get("controllerId", 0))
                device_mac = newDev.pluginProps.get("deviceMac", "")
                port_number = int(newDev.pluginProps.get("portNumber", 0))
                
                if controller_id and device_mac and port_number:
                    # Small delay to ensure config is saved
                    time.sleep(0.5)
                    self.update_port_states(controller_id, device_mac, port_number)
        
        elif newDev.deviceTypeId == "clientDevice":
            old_display = oldDev.pluginProps.get("displayState", "status")
            new_display = newDev.pluginProps.get("displayState", "status")
            
            if old_display != new_display:
                # Display state changed - update the device
                self.logger.info(f"{newDev.name}: Display state changed from {old_display} to {new_display}")
                # The UiDisplayStateId is set in XML, but we need to update Indigo's internal state
                # Force a state refresh
                controller_id = int(newDev.pluginProps.get("controllerId", 0))
                client_mac = newDev.pluginProps.get("clientMac", "").lower()
                if controller_id and client_mac:
                    time.sleep(0.5)
                    self.update_client_states(controller_id, client_mac)
        
        # Return True if comm should restart, False otherwise
        return False
            
    def start_controller(self, dev):
        """Start a UniFi controller connection"""
        try:
            address = dev.pluginProps.get("address", "")
            port = int(dev.pluginProps.get("port", 443))
            username = dev.pluginProps.get("username", "")
            password = dev.pluginProps.get("password", "")
            verify_ssl = dev.pluginProps.get("verifySSL", False)
            enable_protect = dev.pluginProps.get("enableProtect", True)
            enable_network = dev.pluginProps.get("enableNetwork", True)
            
            if not all([address, username, password]):
                self.logger.error(f"{dev.name}: Missing required configuration")
                dev.updateStateOnServer("status", "Error: Missing config")
                dev.updateStateOnServer("connected", False)
                return
                
            self.logger.info(f"{dev.name}: Connecting to {address}:{port}")
            
            controller_info = {
                "device": dev,
                "cameras": {},
                "network_devices": {},
                "ports": {},
                "clients": {},  # {mac: device_id}
                "last_update": time.time()
            }
            
            # Initialize Protect API if enabled
            if enable_protect:
                try:
                    protect_api = UnifiProtectAPI(address, port, username, password, verify_ssl)
                    protect_api.login()
                    
                    if self.debug:
                        if hasattr(protect_api, '_cookie_debug'):
                            self.logger.debug(f"{dev.name} Protect: {protect_api._cookie_debug}")
                        if hasattr(protect_api, '_token_debug'):
                            self.logger.debug(f"{dev.name} Protect: {protect_api._token_debug}")
                    
                    protect_api.get_bootstrap()
                    controller_info["protect_api"] = protect_api
                    
                    # Try to start WebSocket for Protect if enabled
                    enable_protect_ws = dev.pluginProps.get("enableProtectWebSocket", False)
                    if enable_protect_ws:
                        try:
                            def protect_ws_callback(message):
                                self._handle_protect_websocket_message(dev.id, message)
                            
                            # UniFi Protect uses a different WebSocket path
                            # Home Assistant uses /proxy/protect/ws/updates
                            protect_websocket = UnifiWebSocket(
                                address, port,
                                protect_api.cookies,
                                protect_api.ssl_context,
                                protect_ws_callback,
                                self.logger,
                                self.debug,
                                ws_path="/proxy/protect/ws/updates"  # Correct path for Protect
                            )
                            protect_websocket.start()
                            controller_info["protect_websocket"] = protect_websocket
                            
                            self.logger.info(f"{dev.name}: UniFi Protect WebSocket enabled")
                        except Exception as ws_error:
                            self.logger.warning(f"{dev.name}: UniFi Protect WebSocket failed: {ws_error}")
                    
                    self.logger.info(f"{dev.name}: UniFi Protect connected")
                except Exception as e:
                    error_msg = str(e)
                    # Check for common Protect unavailability errors
                    if "502" in error_msg or "503" in error_msg or "Bad Gateway" in error_msg:
                        self.logger.info(f"{dev.name}: UniFi Protect not available on this controller")
                        controller_info["protect_unavailable"] = True
                    else:
                        self.logger.warning(f"{dev.name}: UniFi Protect connection failed: {e}")
                    # Don't let Protect failure stop Network from working
                    enable_protect = False
            
            # Initialize Network API if enabled
            if enable_network:
                try:
                    network_api = UnifiNetworkAPI(address, port, username, password, verify_ssl=verify_ssl)
                    network_api.login()
                    controller_info["network_api"] = network_api
                    
                    # Start WebSocket if enabled
                    enable_network_ws = dev.pluginProps.get("enableNetworkWebSocket", True)
                    if enable_network_ws:
                        try:
                            def ws_callback(message):
                                self._handle_websocket_message(dev.id, message)
                            
                            websocket = UnifiWebSocket(
                                address, port, 
                                network_api.cookies, 
                                network_api.ssl_context,
                                ws_callback,
                                self.logger,
                                self.debug
                            )
                            websocket.start()
                            controller_info["websocket"] = websocket
                            
                            self.logger.info(f"{dev.name}: UniFi Network connected with WebSocket")
                        except Exception as ws_error:
                            self.logger.warning(f"{dev.name}: UniFi Network WebSocket failed, using polling: {ws_error}")
                            self.logger.info(f"{dev.name}: UniFi Network connected (polling mode)")
                    else:
                        self.logger.info(f"{dev.name}: UniFi Network connected (polling mode)")
                        
                except Exception as e:
                    self.logger.warning(f"{dev.name}: UniFi Network connection failed: {e}")
            
            # Store controller info
            self.controllers[dev.id] = controller_info
            
            # Update controller states
            self.update_controller_states(dev.id)
            
            dev.updateStateOnServer("status", "Connected")
            dev.updateStateOnServer("connected", True)
            
            self.logger.info(f"{dev.name}: Connected successfully")
            
            # Setup any waiting devices
            self._setup_waiting_devices(dev.id)
            
        except Exception as e:
            self.logger.error(f"{dev.name}: Connection error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            dev.updateStateOnServer("status", f"Error: {str(e)}")
            dev.updateStateOnServer("connected", False)
            
    def stop_controller(self, dev_id):
        """Stop a controller connection"""
        if dev_id in self.controllers:
            controller = self.controllers[dev_id]
            dev = controller["device"]
            
            # Stop WebSockets if present
            if 'websocket' in controller:
                controller['websocket'].stop()
            if 'protect_websocket' in controller:
                controller['protect_websocket'].stop()
            
            dev.updateStateOnServer("status", "Disconnected")
            dev.updateStateOnServer("connected", False)
            
            del self.controllers[dev_id]
            
            self.logger.info(f"{dev.name}: Disconnected")
    
    def _handle_websocket_message(self, controller_id, message):
        """Handle WebSocket message from UniFi Network"""
        try:
            meta = message.get('meta', {})
            msg_type = meta.get('message', '')
            
            if self.debug:
                self.logger.debug(f"Network WebSocket event: {msg_type}")
            
            # Handle different message types
            if msg_type == 'device:update':
                # Device state changed
                data = message.get('data', [])
                for device_data in data:
                    self._update_network_device_from_ws(controller_id, device_data)
            
            elif msg_type == 'device:sync':
                # Full device sync
                data = message.get('data', [])
                for device_data in data:
                    self._update_network_device_from_ws(controller_id, device_data)
            
            elif msg_type in ['sta:connect', 'sta:disconnect', 'sta:sync']:
                # Client connected/disconnected - will handle in Phase 3
                pass
                
        except Exception as e:
            if self.debug:
                self.logger.error(f"Error handling Network WebSocket message: {e}")
                self.logger.error(traceback.format_exc())
    
    def _handle_protect_websocket_message(self, controller_id, message):
        """Handle WebSocket message from UniFi Protect"""
        try:
            # Protect WebSocket sends action packets
            action = message.get('action')
            
            if self.debug:
                self.logger.debug(f"Protect WebSocket action: {action}")
            
            # Handle update actions for cameras
            if action == 'update':
                # Get the new data
                new_update_id = message.get('newUpdateId')
                model_key = message.get('modelKey')
                
                # If it's a camera update, refresh that camera
                if model_key == 'camera':
                    camera_id = message.get('id')
                    if camera_id and controller_id in self.controllers:
                        controller = self.controllers[controller_id]
                        if camera_id in controller.get("cameras", {}):
                            # Refresh bootstrap to get latest data
                            if "protect_api" in controller:
                                controller["protect_api"].get_bootstrap()
                            # Update this specific camera
                            self.update_camera_states(controller_id, camera_id)
                            
        except Exception as e:
            if self.debug:
                self.logger.error(f"Error handling Protect WebSocket message: {e}")
                self.logger.error(traceback.format_exc())
    
    def _update_network_device_from_ws(self, controller_id, device_data):
        """Update network device from WebSocket data"""
        try:
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            device_mac = device_data.get('mac', '')
            
            # Find Indigo device for this network device
            for net_dev in indigo.devices.iter("self.networkDevice"):
                if int(net_dev.pluginProps.get("controllerId", 0)) == controller_id:
                    if net_dev.pluginProps.get("deviceMac", "") == device_mac:
                        # Update this device
                        self.update_network_device_states(controller_id, device_mac)
                        break
            
            # Also update any port devices for this switch
            port_table = device_data.get('port_table', [])
            if port_table:
                # This is a switch with ports - update all port devices
                if self.debug:
                    self.logger.debug(f"WebSocket: Switch {device_mac} has {len(port_table)} ports, updating port devices")
                for port_dev in indigo.devices.iter("self.unifiPort"):
                    if int(port_dev.pluginProps.get("controllerId", 0)) == controller_id:
                        if port_dev.pluginProps.get("deviceMac", "") == device_mac:
                            port_number = int(port_dev.pluginProps.get("portNumber", 0))
                            if port_number > 0:
                                if self.debug:
                                    self.logger.debug(f"WebSocket: Updating port device {port_dev.name} (port {port_number})")
                                self.update_port_states(controller_id, device_mac, port_number)
                        
        except Exception as e:
            if self.debug:
                self.logger.error(f"Error updating device from WebSocket: {e}")
    
    def setup_camera(self, dev):
        """Setup a camera device"""
        controller_id = int(dev.pluginProps.get("controllerId", 0))
        camera_id = dev.pluginProps.get("cameraId", "")
        
        if controller_id == 0 or not camera_id:
            self.logger.error(f"{dev.name}: Missing controller or camera ID")
            dev.updateStateOnServer("status", "Error: Missing config")
            return
            
        if controller_id not in self.controllers:
            self.logger.warning(f"{dev.name}: Controller not connected yet")
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        
        controller = self.controllers[controller_id]
        if "protect_api" not in controller:
            self.logger.error(f"{dev.name}: UniFi Protect not enabled on controller")
            dev.updateStateOnServer("status", "Error: Protect not enabled")
            return
            
        # Link camera to controller
        controller["cameras"][camera_id] = dev.id
        
        # Update initial camera states
        self.update_camera_states(controller_id, camera_id)
        
        self.logger.debug(f"{dev.name}: Setup complete")
    
    def setup_network_device(self, dev):
        """Setup a network device"""
        controller_id = int(dev.pluginProps.get("controllerId", 0))
        device_mac = dev.pluginProps.get("deviceMac", "")
        
        if controller_id == 0 or not device_mac:
            self.logger.error(f"{dev.name}: Missing controller or device MAC")
            dev.updateStateOnServer("status", "Error: Missing config")
            return
            
        if controller_id not in self.controllers:
            self.logger.warning(f"{dev.name}: Controller not connected yet")
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        
        controller = self.controllers[controller_id]
        if "network_api" not in controller:
            self.logger.error(f"{dev.name}: UniFi Network not enabled on controller")
            dev.updateStateOnServer("status", "Error: Network not enabled")
            return
            
        # Link device to controller
        controller["network_devices"][device_mac] = dev.id
        
        # Update initial device states
        self.update_network_device_states(controller_id, device_mac)
        
        self.logger.debug(f"{dev.name}: Setup complete")
    
    def setup_port_device(self, dev):
        """Setup a port device"""
        parent_id = int(dev.pluginProps.get("parentDevice", 0))
        port_number = int(dev.pluginProps.get("portNumber", 0))
        controller_id = int(dev.pluginProps.get("controllerId", 0))
        device_mac = dev.pluginProps.get("deviceMac", "")
        
        if parent_id == 0 or port_number == 0:
            self.logger.error(f"{dev.name}: Missing parent device or port number")
            dev.updateStateOnServer("portName", "Error: Missing config")
            return
        
        if controller_id not in self.controllers:
            self.logger.warning(f"{dev.name}: Controller not connected yet")
            dev.updateStateOnServer("portName", "Waiting for controller")
            return
        
        controller = self.controllers[controller_id]
        if "network_api" not in controller:
            self.logger.error(f"{dev.name}: UniFi Network not enabled on controller")
            dev.updateStateOnServer("portName", "Error: Network not enabled")
            return
        
        # Link port to controller with unique key: mac:port
        port_key = f"{device_mac}:{port_number}"
        controller["ports"][port_key] = dev.id
        
        # Update initial port states
        self.update_port_states(controller_id, device_mac, port_number)
        
        self.logger.debug(f"{dev.name}: Setup complete")
    
    def setup_client_device(self, dev):
        """Setup a client device"""
        controller_id = int(dev.pluginProps.get("controllerId", 0))
        client_mac = dev.pluginProps.get("clientMac", "").lower()
        
        if controller_id == 0 or not client_mac:
            self.logger.error(f"{dev.name}: Missing controller or client MAC")
            dev.updateStateOnServer("status", "Error: Missing config")
            return
            
        if controller_id not in self.controllers:
            self.logger.warning(f"{dev.name}: Controller not connected yet")
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        
        controller = self.controllers[controller_id]
        if "network_api" not in controller:
            self.logger.error(f"{dev.name}: UniFi Network not enabled on controller")
            dev.updateStateOnServer("status", "Error: Network not enabled")
            return
            
        # Link client to controller
        controller["clients"][client_mac] = dev.id
        
        # Update initial client states
        self.update_client_states(controller_id, client_mac)
        
        self.logger.debug(f"{dev.name}: Setup complete")
    
    def _setup_waiting_devices(self, controller_id):
        """Setup devices that were waiting for this controller"""
        # Setup cameras
        for dev in indigo.devices.iter("self.protectCamera"):
            cam_controller_id = int(dev.pluginProps.get("controllerId", 0))
            if cam_controller_id == controller_id:
                status = dev.states.get("status", "")
                if status == "Waiting for controller":
                    self.logger.info(f"{dev.name}: Controller now available, setting up")
                    self.setup_camera(dev)
        
        # Setup network devices
        for dev in indigo.devices.iter("self.networkDevice"):
            net_controller_id = int(dev.pluginProps.get("controllerId", 0))
            if net_controller_id == controller_id:
                status = dev.states.get("status", "")
                if status == "Waiting for controller":
                    self.logger.info(f"{dev.name}: Controller now available, setting up")
                    self.setup_network_device(dev)
        
        # Setup port devices
        for dev in indigo.devices.iter("self.unifiPort"):
            port_controller_id = int(dev.pluginProps.get("controllerId", 0))
            if port_controller_id == controller_id:
                port_name = dev.states.get("portName", "")
                if port_name == "Waiting for controller":
                    self.logger.info(f"{dev.name}: Controller now available, setting up")
                    self.setup_port_device(dev)
        
        # Setup client devices
        for dev in indigo.devices.iter("self.clientDevice"):
            client_controller_id = int(dev.pluginProps.get("controllerId", 0))
            if client_controller_id == controller_id:
                status = dev.states.get("status", "")
                if status == "Waiting for controller":
                    self.logger.info(f"{dev.name}: Controller now available, setting up")
                    self.setup_client_device(dev)
        
    ########################################
    # Polling Loop
    ########################################
    
    def _polling_loop(self):
        """Background polling loop for updates"""
        while not self.stop_polling:
            try:
                # Poll each controller
                for controller_id in list(self.controllers.keys()):
                    try:
                        controller = self.controllers[controller_id]
                        
                        # Refresh Protect data every 2 seconds
                        if "protect_api" in controller and not controller.get("protect_unavailable", False):
                            if time.time() - controller["last_update"] > 2:
                                try:
                                    api = controller["protect_api"]
                                    api.get_bootstrap()
                                    controller["last_update"] = time.time()
                                    
                                    # Update controller states
                                    self.update_controller_states(controller_id)
                                
                                    # Update all camera states
                                    for camera_id in controller["cameras"].keys():
                                        self.update_camera_states(controller_id, camera_id)
                                        
                                except Exception as e:
                                    error_msg = str(e)
                                    # If we get 502/503, mark Protect as unavailable
                                    if "502" in error_msg or "503" in error_msg or "Bad Gateway" in error_msg:
                                        self.logger.info(f"UniFi Protect became unavailable, disabling polling")
                                        controller["protect_unavailable"] = True
                                    elif self.debug:
                                        self.logger.debug(f"Protect polling error: {e}")
                        
                        # Refresh Network data every 10 seconds (WebSocket handles most updates)
                        if "network_api" in controller:
                            if time.time() - controller.get("last_network_update", 0) > 10:
                                controller["last_network_update"] = time.time()
                                
                                # Update network device states (make a copy of keys to avoid iteration issues)
                                for device_mac in list(controller["network_devices"].keys()):
                                    self.update_network_device_states(controller_id, device_mac)
                                
                                # Update port states
                                for port_key in list(controller["ports"].keys()):
                                    # port_key format is "mac:port_number"
                                    try:
                                        mac, port_num = port_key.split(":")
                                        self.update_port_states(controller_id, mac, int(port_num))
                                    except (ValueError, AttributeError):
                                        pass
                                
                                # Update client states
                                for client_mac in list(controller["clients"].keys()):
                                    self.update_client_states(controller_id, client_mac)
                                
                                # Auto-discover new clients if enabled
                                if self.pluginPrefs.get("autoCreateClients", True):
                                    self._auto_discover_clients(controller_id)
                                
                    except Exception as e:
                        # Don't spam errors for timeouts - controller might be busy
                        if "timed out" in str(e).lower() or "timeout" in str(e).lower():
                            if self.debug:
                                self.logger.debug(f"Controller {controller_id} update timeout - will retry next cycle")
                        else:
                            self.logger.error(f"Error polling controller {controller_id}: {e}")
                            if self.debug:
                                self.logger.error(traceback.format_exc())
                        
                # Sleep between polls
                time.sleep(2)
                
            except Exception as e:
                self.logger.error(f"Error in polling loop: {e}")
                time.sleep(5)
                
    ########################################
    # State Updates - Controller
    ########################################
    
    def update_controller_states(self, dev_id):
        """Update controller device states"""
        try:
            controller = self.controllers[dev_id]
            dev = controller["device"]
            
            states = []
            
            # Update Protect states if enabled
            if "protect_api" in controller:
                api = controller["protect_api"]
                nvr = api.get_nvr()
                cameras = api.get_cameras()
                
                states.append({"key": "protectVersion", "value": nvr.get('version', 'Unknown')})
                states.append({"key": "cameraCount", "value": len(cameras)})
                
                # System info
                if 'systemInfo' in nvr:
                    sys_info = nvr['systemInfo']
                    if 'cpu' in sys_info:
                        cpu_val = sys_info['cpu'].get('averageLoad')
                        if cpu_val is not None:
                            states.append({"key": "cpuUsage", "value": float(f"{cpu_val:.2f}")})
                        else:
                            states.append({"key": "cpuUsage", "value": 0.0})
                    if 'memory' in sys_info:
                        mem = sys_info['memory']
                        if 'total' in mem and 'available' in mem:
                            used_pct = ((mem['total'] - mem['available']) / mem['total']) * 100
                            states.append({"key": "memoryUsage", "value": float(f"{used_pct:.2f}")})
                            
                # Uptime
                if 'uptime' in nvr:
                    uptime_val = nvr['uptime']
                    if uptime_val is not None:
                        if uptime_val > 1000000:
                            uptime_sec = uptime_val // 1000
                        else:
                            uptime_sec = uptime_val
                        days = uptime_sec // 86400
                        hours = (uptime_sec % 86400) // 3600
                        minutes = (uptime_sec % 3600) // 60
                        uptime_str = f"{days}d {hours}h {minutes}m"
                        states.append({"key": "uptime", "value": uptime_str})
                    
                # Storage
                if 'storageStats' in nvr:
                    storage = nvr['storageStats']
                    used = storage.get('used', storage.get('usedBytes', 0))
                    total = storage.get('size', storage.get('capacity', 0))
                    
                    if used is not None and used > 1000000000:
                        used = used / 1073741824
                    if total is not None and total > 1000000000:
                        total = total / 1073741824
                    
                    if used is not None:
                        states.append({"key": "storageUsed", "value": float(f"{used:.2f}")})
                    if total is not None:
                        states.append({"key": "storageTotal", "value": float(f"{total:.2f}")})
            
            # Update Network states if enabled
            if "network_api" in controller:
                api = controller["network_api"]
                devices = api.get_devices()
                
                states.append({"key": "networkDeviceCount", "value": len(devices)})
                
                # Count device types
                switches = sum(1 for d in devices if d.get('type') == 'usw')
                aps = sum(1 for d in devices if d.get('type') == 'uap')
                gateways = sum(1 for d in devices if d.get('type') in ['ugw', 'udm'])
                
                states.append({"key": "switchCount", "value": switches})
                states.append({"key": "apCount", "value": aps})
                states.append({"key": "gatewayCount", "value": gateways})
            
            if states:
                dev.updateStatesOnServer(states)
                
        except Exception as e:
            error_msg = str(e).lower()
            # Check if it's a transient API issue
            if any(x in error_msg for x in ['html error page', 'invalid json', 'controller may be', 'timeout', 'timed out']):
                self.logger.warning(f"Controller {controller['device'].name}: API temporarily unavailable, will retry")
                # Mark controller as temporarily unavailable
                controller["device"].updateStateOnServer("status", "API unavailable")
            else:
                # Real error - log with details
                self.logger.error(f"Error updating controller {dev_id} states: {e}")
                if self.debug:
                    self.logger.error(traceback.format_exc())
    
    ########################################
    # State Updates - Protect Cameras
    ########################################
    
    def update_camera_states(self, controller_id, camera_id):
        """Update camera device states"""
        try:
            controller = self.controllers[controller_id]
            api = controller["protect_api"]
            
            camera = api.get_camera(camera_id)
            if not camera:
                self.logger.warning(f"Camera {camera_id} not found")
                return
                
            dev_id = controller["cameras"].get(camera_id)
            if not dev_id or dev_id not in indigo.devices:
                return
                
            dev = indigo.devices[dev_id]
            
            # Store previous state values for trigger detection
            prev_motion = dev.states.get("motionDetected", False)
            prev_person = dev.states.get("personDetected", False)
            prev_vehicle = dev.states.get("vehicleDetected", False)
            prev_package = dev.states.get("packageDetected", False)
            prev_doorbell = dev.states.get("doorbellRinging", False)
            prev_connected = dev.states.get("isConnected", True)
            prev_dark = dev.states.get("isDark", False)
            
            # Build states list
            is_connected = camera.get('isConnected', False)
            is_dark = camera.get('isDark', False)
            
            states = [
                {"key": "status", "value": "online" if is_connected else "offline"},
                {"key": "isConnected", "value": is_connected},
                {"key": "model", "value": camera.get('marketName', camera.get('type', 'Unknown'))},
                {"key": "firmwareVersion", "value": camera.get('firmwareVersion', 'Unknown')},
                {"key": "isDark", "value": is_dark},
                {"key": "ipAddress", "value": camera.get('host', 'Unknown')},
                {"key": "macAddress", "value": camera.get('mac', 'Unknown')},
            ]
            
            # Uptime
            if 'uptime' in camera and camera['uptime'] is not None:
                uptime_sec = camera['uptime']
                days = uptime_sec // 86400
                hours = (uptime_sec % 86400) // 3600
                states.append({"key": "uptime", "value": f"{days}d {hours}h"})
            else:
                states.append({"key": "uptime", "value": "Offline"})
            
            # Network speed
            if 'phyRate' in camera:
                states.append({"key": "linkSpeed", "value": camera['phyRate']})
            
            # Recording settings
            if 'recordingSettings' in camera:
                rec = camera['recordingSettings']
                states.append({"key": "recordingMode", "value": rec.get('mode', 'unknown')})
                
            # ISP settings (IR mode)
            if 'ispSettings' in camera:
                isp = camera['ispSettings']
                states.append({"key": "irMode", "value": isp.get('irLedMode', 'unknown')})
                
            # LED settings
            if 'ledSettings' in camera:
                led = camera['ledSettings']
                states.append({"key": "statusLight", "value": led.get('isEnabled', False)})
            
            # Voltage
            voltage = camera.get('voltage')
            if voltage is not None:
                states.append({"key": "voltage", "value": voltage})
            else:
                states.append({"key": "voltage", "value": 0})
                    
            # RTSP URLs
            if 'channels' in camera:
                for channel in camera['channels']:
                    if channel.get('isRtspEnabled'):
                        name = channel.get('name', '').capitalize()
                        rtsp_alias = channel.get('rtspAlias', '')
                        if name and rtsp_alias:
                            rtsp_url = f"rtsps://{api.host}:7441/{rtsp_alias}?enableSrtp"
                            states.append({"key": f"rtspUrl{name}", "value": rtsp_url})
                            
            # Snapshot URL
            camera_ip = camera.get('host', '')
            if camera_ip:
                snapshot_url = f"http://{camera_ip}/snap.jpeg"
                states.append({"key": "snapshotUrl", "value": snapshot_url})
            
            # Motion detection
            motion_active = False
            if 'lastMotion' in camera:
                last_motion = camera.get('lastMotion')
                if last_motion:
                    motion_time = datetime.fromtimestamp(last_motion / 1000).strftime("%Y-%m-%d %H:%M:%S")
                    states.append({"key": "lastMotion", "value": motion_time})
                    
                    # Consider motion active if within last 10 seconds
                    if (time.time() * 1000 - last_motion) < 10000:
                        motion_active = True
                    
            states.append({"key": "motionDetected", "value": motion_active})
            states.append({"key": "onOffState", "value": motion_active})
            
            # Smart detections (person, vehicle, package)
            has_person = False
            has_vehicle = False
            has_package = False
            
            if 'lastSmartDetect' in camera:
                last_smart = camera.get('lastSmartDetect')
                # Check if recent (within last 10 seconds)
                if last_smart and (time.time() * 1000 - last_smart) < 10000:
                    # Get smart detect types
                    smart_types = camera.get('lastSmartDetectTypes', [])
                    if 'person' in smart_types:
                        has_person = True
                    if 'vehicle' in smart_types:
                        has_vehicle = True
                    if 'package' in smart_types:
                        has_package = True
                
                # Update last person detection time
                if has_person and last_smart:
                    detect_time = datetime.fromtimestamp(last_smart / 1000).strftime("%Y-%m-%d %H:%M:%S")
                    states.append({"key": "lastPersonDetection", "value": detect_time})
            
            states.append({"key": "personDetected", "value": has_person})
            states.append({"key": "vehicleDetected", "value": has_vehicle})
            states.append({"key": "packageDetected", "value": has_package})
            
            # Doorbell ring
            doorbell_active = False
            if 'lastRing' in camera:
                last_ring = camera.get('lastRing')
                if last_ring:
                    # Consider doorbell active if within last 5 seconds
                    if (time.time() * 1000 - last_ring) < 5000:
                        doorbell_active = True
                    
                    ring_time = datetime.fromtimestamp(last_ring / 1000).strftime("%Y-%m-%d %H:%M:%S")
                    states.append({"key": "lastDoorbellRing", "value": ring_time})
            
            states.append({"key": "doorbellRinging", "value": doorbell_active})
            
            # Update all states
            dev.updateStatesOnServer(states)
            
            # Fire triggers for state changes
            if motion_active and not prev_motion:
                self._fire_trigger("motionDetected", dev)
            
            if has_person and not prev_person:
                self._fire_trigger("personDetected", dev)
            
            if has_vehicle and not prev_vehicle:
                self._fire_trigger("vehicleDetected", dev)
            
            if has_package and not prev_package:
                self._fire_trigger("packageDetected", dev)
            
            if doorbell_active and not prev_doorbell:
                self._fire_trigger("doorbellRing", dev)
            
            if is_connected != prev_connected:
                if is_connected:
                    self._fire_trigger("cameraConnected", dev)
                else:
                    self._fire_trigger("cameraDisconnected", dev)
            
            if is_dark != prev_dark:
                if is_dark:
                    self._fire_trigger("cameraDark", dev)
                else:
                    self._fire_trigger("cameraLight", dev)
            
        except TimeoutError as e:
            # Network timeout - log as warning
            dev_id = controller["cameras"].get(camera_id) if controller_id in self.controllers else None
            if dev_id and dev_id in indigo.devices:
                dev = indigo.devices[dev_id]
                self.logger.warning(f"{dev.name}: Network timeout, will retry")
                dev.updateStateOnServer("status", "unavailable")
            else:
                self.logger.warning(f"Camera {camera_id}: Network timeout")
        except Exception as e:
            # Check if it's a timeout buried in the message
            error_msg = str(e).lower()
            if 'timeout' in error_msg or 'timed out' in error_msg:
                dev_id = controller["cameras"].get(camera_id) if controller_id in self.controllers else None
                if dev_id and dev_id in indigo.devices:
                    dev = indigo.devices[dev_id]
                    self.logger.warning(f"{dev.name}: Network timeout, will retry")
                    dev.updateStateOnServer("status", "unavailable")
                else:
                    self.logger.warning(f"Camera {camera_id}: Network timeout")
            else:
                # Real error - log with details
                self.logger.error(f"Error updating camera {camera_id} states: {e}")
                if self.debug:
                    self.logger.error(traceback.format_exc())
    
    ########################################
    # State Updates - Network Devices
    ########################################
    
    def update_network_device_states(self, controller_id, device_mac):
        """Update network device states"""
        try:
            controller = self.controllers[controller_id]
            api = controller["network_api"]
            
            device = api.get_device(device_mac)
            if not device:
                self.logger.warning(f"Network device {device_mac} not found")
                return
                
            dev_id = controller["network_devices"].get(device_mac)
            if not dev_id or dev_id not in indigo.devices:
                return
                
            dev = indigo.devices[dev_id]
            
            # Device state
            state = device.get('state', 0)
            is_adopted = state == 1
            is_connected = device.get('state', 0) == 1
            is_disabled = device.get('disabled', False)
            
            # Build states list
            states = [
                {"key": "status", "value": "online" if is_connected else "offline"},
                {"key": "isConnected", "value": is_connected},
                {"key": "adopted", "value": is_adopted},
                {"key": "disabled", "value": is_disabled},
                {"key": "model", "value": device.get('model', 'Unknown')},
                {"key": "firmwareVersion", "value": device.get('version', 'Unknown')},
                {"key": "ipAddress", "value": device.get('ip', 'Unknown')},
                {"key": "macAddress", "value": device.get('mac', 'Unknown')},
                {"key": "deviceType", "value": device.get('type', 'unknown')},
                {"key": "deviceName", "value": device.get('name', 'Unknown')},
            ]
            
            # Uptime
            if 'uptime' in device:
                uptime_sec = device['uptime']
                days = uptime_sec // 86400
                hours = (uptime_sec % 86400) // 3600
                minutes = (uptime_sec % 3600) // 60
                uptime_str = f"{days}d {hours}h {minutes}m"
                states.append({"key": "uptime", "value": uptime_str})
                states.append({"key": "uptimeSeconds", "value": uptime_sec})
            
            # System stats
            if 'system-stats' in device:
                sys_stats = device['system-stats']
                if 'cpu' in sys_stats:
                    # CPU can be a float string like "2.4" or "  2.4" (with spaces)
                    try:
                        cpu_val = float(str(sys_stats['cpu']).strip())
                        states.append({"key": "cpuUsage", "value": round(cpu_val, 1)})
                    except (ValueError, TypeError):
                        pass
                if 'mem' in sys_stats:
                    # Memory can also be a float string
                    try:
                        mem_val = float(str(sys_stats['mem']).strip())
                        states.append({"key": "memoryUsage", "value": round(mem_val, 1)})
                    except (ValueError, TypeError):
                        pass
                if 'temps' in sys_stats:
                    temps = sys_stats.get('temps', [])
                    if temps:
                        try:
                            temp_val = float(str(temps[0]).strip())
                            states.append({"key": "temperature", "value": round(temp_val, 1)})
                        except (ValueError, TypeError, IndexError):
                            pass
            
            # LED state
            led_override = device.get('led_override', 'default')
            led_enabled = led_override == 'on' or (led_override == 'default' and not device.get('led_override_color_brightness', 0) == 0)
            states.append({"key": "ledEnabled", "value": led_enabled})
            states.append({"key": "ledOverride", "value": led_override})
            
            # Update available
            states.append({"key": "updateAvailable", "value": device.get('upgradable', False)})
            
            # Device-specific states
            device_type = device.get('type', '')
            
            if device_type == 'usw':  # Switch
                # Port count
                port_table = device.get('port_table', [])
                states.append({"key": "portCount", "value": len(port_table)})
                
                # PoE stats
                if 'port_table' in device:
                    poe_consumption = 0
                    for p in device['port_table']:
                        poe_power = p.get('poe_power', 0)
                        # PoE power can be a string or number
                        try:
                            if isinstance(poe_power, str):
                                poe_power = float(poe_power)
                            poe_consumption += float(poe_power)
                        except (ValueError, TypeError):
                            pass
                    states.append({"key": "poeConsumption", "value": round(poe_consumption, 2)})
                
            elif device_type == 'uap':  # Access Point
                # Client count
                states.append({"key": "connectedClients", "value": device.get('num_sta', 0)})
                states.append({"key": "guestClients", "value": device.get('guest-num_sta', 0)})
                states.append({"key": "userClients", "value": device.get('user-num_sta', 0)})
                
                # Radio states - map to 2G/5G based on radio name
                radio_table = device.get('radio_table', [])
                if isinstance(radio_table, list):
                    for radio in radio_table:
                        if isinstance(radio, dict):
                            name = radio.get('name', '').lower()
                            channel = radio.get('channel', 0)
                            
                            # Map radio names to state keys
                            # Common UniFi radio names: ng (2.4GHz), na (5GHz), 6e (6GHz)
                            state_key = None
                            if 'ng' in name or '2g' in name or name == 'wifi0':
                                state_key = "channel2G"
                            elif 'na' in name or '5g' in name or name == 'wifi1':
                                state_key = "channel5G"
                            # 6GHz not supported yet in our states
                            
                            if state_key and channel:
                                # Channel can be a number or "auto"
                                try:
                                    channel_val = int(channel)
                                    states.append({"key": state_key, "value": channel_val})
                                except (ValueError, TypeError):
                                    # If it's "auto" or invalid, store as 0
                                    states.append({"key": state_key, "value": 0})
                        
                # Satisfaction score
                if 'satisfaction' in device:
                    try:
                        sat_val = int(device['satisfaction'])
                        states.append({"key": "satisfaction", "value": sat_val})
                    except (ValueError, TypeError):
                        pass
            
            # Update on/off state based on disabled status
            states.append({"key": "onOffState", "value": not is_disabled})
            
            # Update all states
            dev.updateStatesOnServer(states)
            
            # Update device onState property to match disabled state
            if dev.onState == is_disabled:  # If they don't match, update
                dev.updateStateOnServer("onOffState", not is_disabled)
                
        except TimeoutError as e:
            # Network timeout - log as warning, mark device as temporarily unavailable
            dev_id = controller["network_devices"].get(device_mac) if controller_id in self.controllers else None
            if dev_id and dev_id in indigo.devices:
                dev = indigo.devices[dev_id]
                self.logger.warning(f"{dev.name}: Network timeout, will retry")
                dev.updateStateOnServer("status", "unavailable")
            else:
                self.logger.warning(f"Network device {device_mac}: Network timeout")
        except Exception as e:
            # Check if it's a timeout buried in the message
            error_msg = str(e).lower()
            if 'timeout' in error_msg or 'timed out' in error_msg:
                dev_id = controller["network_devices"].get(device_mac) if controller_id in self.controllers else None
                if dev_id and dev_id in indigo.devices:
                    dev = indigo.devices[dev_id]
                    self.logger.warning(f"{dev.name}: Network timeout, will retry")
                    dev.updateStateOnServer("status", "unavailable")
                else:
                    self.logger.warning(f"Network device {device_mac}: Network timeout")
            else:
                # Real error - log with details
                self.logger.error(f"Error updating network device {device_mac} states: {e}")
                if self.debug:
                    self.logger.error(traceback.format_exc())
    
    def update_network_device_enabled(self, dev):
        """Update network device enabled/disabled state"""
        try:
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            
            # Get device to find its _id
            device = api.get_device(device_mac)
            if not device:
                return
            
            device_id = device.get('_id')
            
            # Update enabled/disabled state
            if dev.onState:
                api.enable_device(device_id)
                self.logger.info(f"{dev.name}: Enabled")
            else:
                api.disable_device(device_id)
                self.logger.info(f"{dev.name}: Disabled")
            
            # Refresh states
            time.sleep(1)
            self.update_network_device_states(controller_id, device_mac)
            
        except Exception as e:
            self.logger.error(f"Error updating device enabled state: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    def update_port_states(self, controller_id, device_mac, port_number):
        """Update port device states from API"""
        try:
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            # Get port device
            port_key = f"{device_mac}:{port_number}"
            if port_key not in controller["ports"]:
                return
            
            dev = indigo.devices[controller["ports"][port_key]]
            api = controller["network_api"]
            
            # Get switch data
            device = api.get_device(device_mac)
            if not device:
                return
            
            # Find the port in port_table
            port_table = device.get('port_table', [])
            port_data = None
            for port in port_table:
                # Match by port_num or port_idx
                if port.get('port_num') == port_number or port.get('port_idx') == port_number:
                    port_data = port
                    break
            
            if not port_data:
                self.logger.debug(f"{dev.name}: Port {port_number} not found in port_table")
                return
            
            # Build states list
            states = []
            
            # Port identity
            port_idx = port_data.get('port_idx', port_number)
            port_name = port_data.get('name', f"Port {port_number}")
            states.append({"key": "portNumber", "value": port_number})
            states.append({"key": "portName", "value": port_name})
            states.append({"key": "portIdx", "value": port_idx})
            
            # Port status
            port_enabled = not port_data.get('disabled', False)  # Check 'disabled' field
            states.append({"key": "enabled", "value": port_enabled})
            states.append({"key": "up", "value": port_data.get('up', False)})
            states.append({"key": "speed", "value": port_data.get('speed', 0)})
            states.append({"key": "fullDuplex", "value": port_data.get('full_duplex', False)})
            
            # PoE
            poe_enable = port_data.get('poe_enable', False)
            poe_mode = port_data.get('poe_mode', 'off')
            poe_power = port_data.get('poe_power', 0)
            poe_voltage = port_data.get('poe_voltage', 0)
            poe_current = port_data.get('poe_current', 0)
            poe_caps = port_data.get('poe_caps', 0)  # PoE capability (0=none, 1-4=various PoE standards)
            
            # Port is PoE capable if poe_caps > 0
            poe_capable = poe_caps > 0
            
            states.append({"key": "poeCapable", "value": poe_capable})
            states.append({"key": "poeEnable", "value": poe_enable})
            states.append({"key": "poeEnabled", "value": poe_enable})  # Also update poeEnabled for on/off state
            states.append({"key": "poeMode", "value": poe_mode})
            states.append({"key": "poePower", "value": round(float(poe_power) if poe_power else 0, 2)})
            states.append({"key": "poeVoltage", "value": round(float(poe_voltage) if poe_voltage else 0, 2)})
            # PoE current can be float like "164.79" - convert to int milliamps
            try:
                current_val = int(round(float(poe_current))) if poe_current else 0
            except (ValueError, TypeError):
                current_val = 0
            states.append({"key": "poeCurrent", "value": current_val})
            
            # Connected device - look for client MAC in various fields
            # The 'mac' field is the client MAC when a device is connected
            client_mac = port_data.get('mac', '')
            
            # If no MAC in port_data, check if there's a connected client via other indicators
            has_client = bool(client_mac) or port_data.get('port_poe', False) or port_data.get('up', False)
            
            states.append({"key": "hasClient", "value": has_client})
            states.append({"key": "clientMac", "value": client_mac})
            states.append({"key": "clientName", "value": port_data.get('name', '')})
            
            # Traffic stats
            states.append({"key": "rxBytes", "value": port_data.get('rx_bytes', 0)})
            states.append({"key": "txBytes", "value": port_data.get('tx_bytes', 0)})
            states.append({"key": "rxPackets", "value": port_data.get('rx_packets', 0)})
            states.append({"key": "txPackets", "value": port_data.get('tx_packets', 0)})
            
            # Update all states
            dev.updateStatesOnServer(states)
            
            # Update device onState property based on control mode
            control_mode = dev.pluginProps.get("controlMode", "poe")
            
            if control_mode == "poe":
                # PoE Control Mode: Device ON if PoE is enabled
                desired_state = poe_mode != 'off'
            elif control_mode == "reboot":
                # PoE Reboot Mode: Device always ON (since it's just a momentary action)
                desired_state = poe_mode != 'off'
            elif control_mode == "port":
                # Port Active/Inactive Mode: Device ON if port is not disabled
                desired_state = port_enabled
            else:
                # Default to PoE mode behavior
                desired_state = poe_mode != 'off'
            
            if dev.onState != desired_state:
                dev.updateStateOnServer("onOffState", desired_state)
            
            # Check for trigger conditions
            old_up = dev.states.get("up", False)
            old_poe = dev.states.get("poeEnable", False)
            old_has_client = dev.states.get("hasClient", False)
            
            new_up = port_data.get('up', False)
            new_poe = poe_enable
            new_has_client = has_client
            
            # Fire triggers on state changes
            if old_up != new_up:
                if new_up:
                    self._fire_trigger("portLinkUp", dev)
                else:
                    self._fire_trigger("portLinkDown", dev)
            
            if old_poe != new_poe:
                if new_poe:
                    self._fire_trigger("portPoeOn", dev)
                else:
                    self._fire_trigger("portPoeOff", dev)
            
            if old_has_client != new_has_client:
                if new_has_client:
                    self._fire_trigger("portDeviceConnected", dev)
                else:
                    self._fire_trigger("portDeviceDisconnected", dev)
            
        except TimeoutError as e:
            # Network timeout - log as warning
            self.logger.warning(f"Port device: Network timeout, will retry")
        except Exception as e:
            # Check if it's a timeout buried in the message
            error_msg = str(e).lower()
            if 'timeout' in error_msg or 'timed out' in error_msg:
                self.logger.warning(f"Port device: Network timeout, will retry")
            else:
                # Real error - log with details
                self.logger.error(f"Error updating port states: {e}")
                if self.debug:
                    self.logger.error(traceback.format_exc())
    
    ########################################
    # State Updates - Client Devices
    ########################################
    
    def update_client_states(self, controller_id, client_mac):
        """Update client device states"""
        try:
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            # Get client device
            if client_mac not in controller["clients"]:
                return
            
            dev_id = controller["clients"][client_mac]
            if dev_id not in indigo.devices:
                return
            
            dev = indigo.devices[dev_id]
            api = controller["network_api"]
            
            # Get client data
            client = api.get_client(client_mac)
            
            if not client:
                # Client not found - mark as offline
                states = [
                    {"key": "status", "value": "offline"},
                    {"key": "isConnected", "value": False},
                    {"key": "isHome", "value": False}
                ]
                dev.updateStatesOnServer(states)
                return
            
            # Build states list
            states = []
            
            # Connection status
            is_wired = client.get('is_wired', False)
            is_guest = client.get('is_guest', False)
            is_connected = True  # If we got client data, they're connected
            
            states.append({"key": "isConnected", "value": is_connected})
            states.append({"key": "status", "value": "online"})
            states.append({"key": "connectionType", "value": "wired" if is_wired else "wireless"})
            
            # Identity
            name = client.get('name', client.get('hostname', 'Unknown'))
            states.append({"key": "clientName", "value": name})
            states.append({"key": "macAddress", "value": client_mac})
            states.append({"key": "ipAddress", "value": client.get('ip', 'Unknown')})
            states.append({"key": "hostname", "value": client.get('hostname', 'Unknown')})
            
            # Timing
            if 'first_seen' in client:
                states.append({"key": "connectedSince", "value": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(client['first_seen']))})
            
            if 'last_seen' in client:
                last_seen = client['last_seen']
                age_sec = int(time.time() - last_seen)
                if age_sec < 300:  # Less than 5 minutes = "Home"
                    states.append({"key": "isHome", "value": True})
                    states.append({"key": "lastSeenAge", "value": f"{age_sec} seconds ago"})
                else:
                    states.append({"key": "isHome", "value": False})
                    if age_sec < 3600:
                        states.append({"key": "lastSeenAge", "value": f"{age_sec // 60} minutes ago"})
                    elif age_sec < 86400:
                        states.append({"key": "lastSeenAge", "value": f"{age_sec // 3600} hours ago"})
                    else:
                        states.append({"key": "lastSeenAge", "value": f"{age_sec // 86400} days ago"})
            else:
                states.append({"key": "isHome", "value": False})
            
            # Wired connection details
            if is_wired:
                if 'sw_mac' in client:
                    states.append({"key": "switchMac", "value": client['sw_mac']})
                    # Get switch name
                    switch_dev = api.get_device(client['sw_mac'])
                    if switch_dev:
                        states.append({"key": "switchName", "value": switch_dev.get('name', 'Unknown')})
                
                if 'sw_port' in client:
                    port_num = client['sw_port']
                    states.append({"key": "portNumber", "value": port_num})
                    states.append({"key": "switchPort", "value": f"Port {port_num}"})
                    
                    # Check if port has PoE
                    if switch_dev:
                        port_table = switch_dev.get('port_table', [])
                        for port in port_table:
                            if port.get('port_idx') == port_num or port.get('port_num') == port_num:
                                poe_caps = port.get('poe_caps', 0)
                                poe_enable = port.get('poe_enable', False)
                                poe_power = port.get('poe_power', 0)
                                
                                states.append({"key": "poeAvailable", "value": poe_caps > 0})
                                states.append({"key": "poeEnabled", "value": poe_enable})
                                states.append({"key": "poePower", "value": round(float(poe_power) if poe_power else 0, 2)})
                                break
                        else:
                            states.append({"key": "poeAvailable", "value": False})
                            states.append({"key": "poeEnabled", "value": False})
                            states.append({"key": "poePower", "value": 0})
                else:
                    states.append({"key": "poeAvailable", "value": False})
                    states.append({"key": "poeEnabled", "value": False})
                    states.append({"key": "poePower", "value": 0})
            else:
                # Wireless connection details
                if 'ap_mac' in client:
                    states.append({"key": "apMac", "value": client['ap_mac']})
                    # Get AP name
                    ap_dev = api.get_device(client['ap_mac'])
                    if ap_dev:
                        states.append({"key": "apName", "value": ap_dev.get('name', 'Unknown')})
                
                states.append({"key": "ssid", "value": client.get('essid', 'Unknown')})
                states.append({"key": "channel", "value": client.get('channel', 0)})
                states.append({"key": "signalStrength", "value": client.get('signal', 0)})
                states.append({"key": "radio", "value": client.get('radio', 'Unknown')})
                
                # No PoE on wireless
                states.append({"key": "poeAvailable", "value": False})
                states.append({"key": "poeEnabled", "value": False})
                states.append({"key": "poePower", "value": 0})
            
            # Blocking status
            is_blocked = client.get('blocked', False)
            states.append({"key": "isBlocked", "value": is_blocked})
            
            # Device info
            states.append({"key": "deviceType", "value": client.get('dev_cat', 'Unknown')})
            states.append({"key": "manufacturer", "value": client.get('oui', 'Unknown')})
            states.append({"key": "oui", "value": client.get('oui', 'Unknown')})
            
            # Experience score
            if 'satisfaction' in client:
                states.append({"key": "experience", "value": client['satisfaction']})
            
            # Traffic stats
            states.append({"key": "rxBytes", "value": client.get('rx_bytes', 0)})
            states.append({"key": "txBytes", "value": client.get('tx_bytes', 0)})
            states.append({"key": "rxPackets", "value": client.get('rx_packets', 0)})
            states.append({"key": "txPackets", "value": client.get('tx_packets', 0)})
            
            # Convert bytes/sec to Mbps
            rx_rate = client.get('rx_rate', 0) / 1000000 if client.get('rx_rate') else 0
            tx_rate = client.get('tx_rate', 0) / 1000000 if client.get('tx_rate') else 0
            states.append({"key": "rxRate", "value": round(rx_rate, 2)})
            states.append({"key": "txRate", "value": round(tx_rate, 2)})
            
            # Update all states first
            dev.updateStatesOnServer(states)
            
            # Update display state based on user preference
            display_state = dev.pluginProps.get("displayState", "status")
            # Get the value of the selected state
            display_value = dev.states.get(display_state, "Unknown")
            dev.updateStateOnServer("display", str(display_value))
            
            # Update device onState based on control mode
            control_mode = dev.pluginProps.get("controlMode", "poe")
            
            if control_mode == "poe":
                # PoE Control Mode: Device ON if PoE is enabled (if on PoE port)
                if is_wired and states:
                    # Find poeEnabled in states
                    poe_enabled = False
                    for state in states:
                        if state["key"] == "poeEnabled":
                            poe_enabled = state["value"]
                            break
                    desired_state = poe_enabled
                else:
                    desired_state = False
            elif control_mode == "reboot":
                # PoE Reboot Mode: Always ON (momentary action)
                desired_state = True
            else:
                # Default
                desired_state = False
            
            # Safety check for onState attribute (may not exist on devices created before v1.7.2)
            if hasattr(dev, 'onState'):
                if dev.onState != desired_state:
                    dev.updateStateOnServer("onOffState", desired_state)
            else:
                # Device doesn't support onState yet - just update the state
                dev.updateStateOnServer("onOffState", desired_state)
            
        except TimeoutError as e:
            # Network timeout - log as warning
            self.logger.warning(f"Client device: Network timeout, will retry")
        except Exception as e:
            # Check if it's a timeout buried in the message
            error_msg = str(e).lower()
            if 'timeout' in error_msg or 'timed out' in error_msg:
                self.logger.warning(f"Client device: Network timeout, will retry")
            else:
                # Real error - log with details
                self.logger.error(f"Error updating client {client_mac} states: {e}")
                if self.debug:
                    self.logger.error(traceback.format_exc())
    
    def update_client_control(self, dev, action=None):
        """Update client control state when toggled - handles PoE control modes"""
        try:
            # Get fresh device state from Indigo
            dev = indigo.devices[dev.id]
            
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            client_mac = dev.pluginProps.get("clientMac", "").lower()
            control_mode = dev.pluginProps.get("controlMode", "poe")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            
            # Get client info
            client = api.get_client(client_mac)
            if not client:
                self.logger.warning(f"{dev.name}: Client not found on network")
                return
            
            # Check connection type
            is_wired = client.get('is_wired', False)
            
            if not is_wired:
                self.logger.warning(f"{dev.name}: PoE control unavailable - connected via WiFi")
                return
            
            # Get port information
            switch_mac = client.get('sw_mac')
            port_num = client.get('sw_port')
            
            if not switch_mac or not port_num:
                self.logger.warning(f"{dev.name}: PoE control unavailable - port information not available")
                return
            
            # Get switch device to check PoE capability
            switch_dev = api.get_device(switch_mac)
            if not switch_dev:
                self.logger.warning(f"{dev.name}: PoE control unavailable - switch not found")
                return
            
            # Find port in port_table
            port_table = switch_dev.get('port_table', [])
            port_data = None
            for port in port_table:
                if port.get('port_idx') == port_num or port.get('port_num') == port_num:
                    port_data = port
                    break
            
            if not port_data:
                self.logger.warning(f"{dev.name}: PoE control unavailable - port not found")
                return
            
            # Check PoE capability
            poe_caps = port_data.get('poe_caps', 0)
            if poe_caps == 0:
                self.logger.warning(f"{dev.name}: PoE control unavailable - port does not support PoE")
                return
            
            # Determine what to do based on control mode and action
            if control_mode == "poe":
                # PoE Control Mode: Toggle PoE on/off
                if action and hasattr(action, 'deviceAction'):
                    if action.deviceAction == indigo.kDeviceAction.TurnOn:
                        # Turn PoE ON
                        api.set_port_poe_mode(switch_mac, port_num, "auto")
                        self.logger.info(f"{dev.name}: Enabled PoE on port {port_num}")
                    elif action.deviceAction == indigo.kDeviceAction.TurnOff:
                        # Turn PoE OFF
                        api.set_port_poe_mode(switch_mac, port_num, "off")
                        self.logger.info(f"{dev.name}: Disabled PoE on port {port_num}")
                    elif action.deviceAction == indigo.kDeviceAction.Toggle:
                        # Toggle PoE
                        current_mode = port_data.get('poe_mode', 'off')
                        new_mode = "off" if current_mode != "off" else "auto"
                        api.set_port_poe_mode(switch_mac, port_num, new_mode)
                        self.logger.info(f"{dev.name}: Toggled PoE on port {port_num} to {new_mode}")
            
            elif control_mode == "reboot":
                # PoE Reboot Mode: Power cycle the port
                if action and hasattr(action, 'deviceAction'):
                    if action.deviceAction == indigo.kDeviceAction.TurnOff:
                        # Power cycle
                        api.cycle_port_poe(switch_mac, port_num)
                        self.logger.info(f"{dev.name}: Power cycled PoE on port {port_num}")
            
            # Update states after short delay
            time.sleep(0.5)
            self.update_client_states(controller_id, client_mac)
            
        except Exception as e:
            self.logger.error(f"Error updating client control: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    def update_port_control(self, dev, action=None):
        """Update port control state when toggled - handles PoE, Reboot, or Port control modes"""
        try:
            # Get fresh device state from Indigo
            dev = indigo.devices[dev.id]
            
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            port_number = int(dev.pluginProps.get("portNumber", 0))
            control_mode = dev.pluginProps.get("controlMode", "poe")
            reboot_duration = int(dev.pluginProps.get("rebootDuration", 5))
            
            # Determine what action to take
            # If called from actionControlDevice, use the action
            # If called from deviceUpdated, use the current onState
            if action is not None:
                # Called from button press - check action.deviceAction
                device_action = str(action.deviceAction)
                turn_on = (device_action == "TurnOn")
                turn_off = (device_action == "TurnOff")
                
                if self.debug:
                    self.logger.debug(f"{dev.name}: Action control - deviceAction={device_action}, turn_on={turn_on}, turn_off={turn_off}")
            else:
                # Called from deviceUpdated - use current state
                turn_on = dev.onState
                turn_off = not dev.onState
                
                if self.debug:
                    self.logger.debug(f"{dev.name}: State change - onState={dev.onState}")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            
            # Get parent switch to find device_id
            device = api.get_device(device_mac)
            if not device:
                return
            
            device_id = device.get('_id')
            
            # Find port_idx
            port_table = device.get('port_table', [])
            port_idx = None
            for port in port_table:
                if port.get('port_num') == port_number or port.get('port_idx') == port_number:
                    port_idx = port.get('port_idx', port_number)
                    break
            
            if port_idx is None:
                return
            
            # Handle different control modes
            if control_mode == "poe":
                # PoE Control Mode: ON/OFF toggles PoE
                if turn_on:
                    # Immediately update state (optimistic)
                    dev.updateStateOnServer("onOffState", True)
                    api.set_port_poe_mode(device_id, port_idx, "auto")
                    self.logger.info(f"{dev.name}: PoE enabled")
                elif turn_off:
                    # Immediately update state (optimistic)
                    dev.updateStateOnServer("onOffState", False)
                    api.set_port_poe_mode(device_id, port_idx, "off")
                    self.logger.info(f"{dev.name}: PoE disabled")
                    
            elif control_mode == "reboot":
                # PoE Reboot Mode: OFF button power cycles using official API
                if turn_off:
                    # Keep device showing ON during reboot (it's a momentary action)
                    dev.updateStateOnServer("onOffState", True)
                    self.logger.info(f"{dev.name}: PoE power cycling (using UniFi power-cycle command)")
                    result = api.cycle_port_poe(device_mac, port_idx)
                    if self.debug:
                        self.logger.debug(f"{dev.name}: Power cycle API result: {result}")
                    self.logger.info(f"{dev.name}: PoE power cycle command sent")
                # Ignore ON button presses in reboot mode - device stays ON
                    
            elif control_mode == "port":
                # Port Enable/Disable Mode: ON/OFF toggles entire port
                if turn_on:
                    # Immediately update state (optimistic)
                    dev.updateStateOnServer("onOffState", True)
                    if self.debug:
                        self.logger.debug(f"{dev.name}: Sending enable_port(device_id={device_id}, port_idx={port_idx})")
                    result = api.enable_port(device_id, port_idx)
                    if self.debug:
                        self.logger.debug(f"{dev.name}: Enable port API result: {result}")
                    self.logger.info(f"{dev.name}: Port enabled")
                elif turn_off:
                    # Immediately update state (optimistic)
                    dev.updateStateOnServer("onOffState", False)
                    if self.debug:
                        self.logger.debug(f"{dev.name}: Sending disable_port(device_id={device_id}, port_idx={port_idx})")
                    result = api.disable_port(device_id, port_idx)
                    if self.debug:
                        self.logger.debug(f"{dev.name}: Disable port API result: {result}")
                    self.logger.info(f"{dev.name}: Port disabled")
            
            # Refresh states after a short delay to verify
            time.sleep(0.5)
            self.update_port_states(controller_id, device_mac, port_number)
            
        except Exception as e:
            self.logger.error(f"Error updating port control state: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    def _fire_trigger(self, event_id, dev):
        """Fire a trigger for an event"""
        try:
            if self.debug:
                self.logger.debug(f"Checking triggers for event {event_id} on device {dev.name}")
            
            trigger_count = 0
            for trigger in indigo.triggers.iter(f"self.{event_id}"):
                trigger_count += 1
                # Check if trigger is configured for this specific device or any device
                device_filter = trigger.pluginProps.get("device", "")
                
                if self.debug:
                    self.logger.debug(f"  Trigger '{trigger.name}': device_filter={device_filter}, dev.id={dev.id}")
                
                if device_filter == "" or int(device_filter) == dev.id:
                    indigo.trigger.execute(trigger)
                    self.logger.info(f"Fired trigger '{trigger.name}' for {dev.name}")
            
            if self.debug and trigger_count == 0:
                self.logger.debug(f"No triggers found for event {event_id}")
                    
        except Exception as e:
            self.logger.error(f"Error firing trigger {event_id}: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    ########################################
    # UI Methods
    ########################################
    
    def _get_unique_device_name(self, base_name):
        """Generate a unique device name by appending a number if needed"""
        # Check if base name exists
        existing_names = [dev.name for dev in indigo.devices]
        
        if base_name not in existing_names:
            return base_name
        
        # Name exists, find a unique variant
        counter = 2
        while True:
            new_name = f"{base_name} {counter}"
            if new_name not in existing_names:
                return new_name
            counter += 1
            # Safety limit
            if counter > 100:
                return f"{base_name} {counter}"
    
    def getControllerList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of controllers for device config"""
        controllers = []
        for dev in indigo.devices.iter("self.unifiController"):
            controllers.append((dev.id, dev.name))
        return controllers
    
    def getCameraList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of cameras for event config"""
        cameras = [("", "Any Camera")]
        for dev in indigo.devices.iter("self.protectCamera"):
            cameras.append((str(dev.id), dev.name))
        if self.debug:
            self.logger.debug(f"getCameraList returning {len(cameras)} items (including Any)")
        return cameras
    
    def getNetworkDeviceList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of network devices for event config"""
        devices = [("", "Any Device")]
        for dev in indigo.devices.iter("self.networkDevice"):
            devices.append((str(dev.id), dev.name))
        if self.debug:
            self.logger.debug(f"getNetworkDeviceList returning {len(devices)} items (including Any)")
        return devices
    
    def getPortDeviceList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of port devices for event config"""
        ports = [("", "Any Port")]
        for dev in indigo.devices.iter("self.unifiPort"):
            ports.append((str(dev.id), dev.name))
        if self.debug:
            self.logger.debug(f"getPortDeviceList returning {len(ports)} items (including Any)")
        return ports
    
    def getClientList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of client devices for event config"""
        clients = [("", "Any Client")]
        for dev in indigo.devices.iter("self.clientDevice"):
            clients.append((str(dev.id), dev.name))
        if self.debug:
            self.logger.debug(f"getClientList returning {len(clients)} items (including Any)")
        return clients
    
    def getPortList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of ports for the selected parent switch"""
        ports = []
        
        # Get parent device ID from valuesDict
        parent_id = valuesDict.get("parentDevice") if valuesDict else None
        if not parent_id:
            return [("0", "Select a switch first")]
        
        try:
            parent_dev = indigo.devices[int(parent_id)]
            port_count_val = parent_dev.states.get("portCount", 0)
            
            # Handle case where portCount might be boolean or invalid
            try:
                port_count = int(port_count_val)
            except (ValueError, TypeError):
                return [("0", "Switch port count unavailable")]
            
            if port_count == 0:
                return [("0", "No ports available")]
            
            # Create list of port numbers
            for port_num in range(1, port_count + 1):
                ports.append((str(port_num), f"Port {port_num}"))
            
        except Exception as e:
            self.logger.debug(f"Error getting port list: {e}")
            return [("0", "Error loading ports")]
        
        return ports
    
    def menuDiscoverCameras(self, action):
        """Menu action to discover cameras"""
        try:
            props = action.props
            controller_id = int(props.get("controllerId", 0))
            if controller_id == 0:
                self.logger.error("No controller selected")
                return False
            
            # Call the device config method
            return self.createCameraDevices(props, None, controller_id)
            
        except Exception as e:
            self.logger.error(f"Error in menu discover cameras: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def menuDiscoverNetworkDevices(self, action):
        """Menu action to discover network devices"""
        try:
            props = action.props
            controller_id = int(props.get("controllerId", 0))
            if controller_id == 0:
                self.logger.error("No controller selected")
                return False
            
            # Call the device config method
            return self.createNetworkDevices(props, None, controller_id)
            
        except Exception as e:
            self.logger.error(f"Error in menu discover network devices: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def menuDiscoverAllClients(self, action):
        """Menu action to discover all clients"""
        try:
            props = action.props
            controller_id = int(props.get("controllerId", 0))
            min_last_seen = int(props.get("minLastSeen", 30))
            
            if controller_id == 0:
                self.logger.error("No controller selected")
                return False
            
            if controller_id not in self.controllers:
                self.logger.error("Controller not connected")
                return False
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error("UniFi Network not enabled")
                return False
            
            api = controller["network_api"]
            
            # Get all clients
            all_clients = api.get_all_clients()
            active_clients = api.get_clients()
            
            # Combine and deduplicate
            client_map = {}
            for client in all_clients + active_clients:
                mac = client.get('mac', '').lower()
                if mac:
                    client_map[mac] = client
            
            # Get existing devices
            existing_macs = set()
            for dev in indigo.devices.iter("self.clientDevice"):
                dev_mac = dev.pluginProps.get("clientMac", "").lower()
                if dev_mac:
                    existing_macs.add(dev_mac)
            
            # Filter by last_seen if specified
            current_time = time.time()
            cutoff_time = current_time - (min_last_seen * 24 * 3600) if min_last_seen > 0 else 0
            
            created_count = 0
            for mac, client in client_map.items():
                if mac in existing_macs:
                    continue
                
                # Check last_seen
                if cutoff_time > 0:
                    last_seen = client.get('last_seen', 0)
                    if last_seen < cutoff_time:
                        continue
                
                # Create device
                self._create_client_device(controller_id, client)
                created_count += 1
            
            self.logger.info(f"Created {created_count} client devices")
            return True
            
        except Exception as e:
            self.logger.error(f"Error discovering all clients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def menuDiscoverUnknownClients(self, action):
        """Menu action to discover unknown clients"""
        try:
            props = action.props
            controller_id = int(props.get("controllerId", 0))
            
            if controller_id == 0:
                self.logger.error("No controller selected")
                return False
            
            if controller_id not in self.controllers:
                self.logger.error("Controller not connected")
                return False
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error("UniFi Network not enabled")
                return False
            
            api = controller["network_api"]
            
            # Get all clients
            all_clients = api.get_all_clients()
            active_clients = api.get_clients()
            
            # Combine and deduplicate
            client_map = {}
            for client in all_clients + active_clients:
                mac = client.get('mac', '').lower()
                if mac:
                    client_map[mac] = client
            
            # Get existing devices
            existing_macs = set()
            for dev in indigo.devices.iter("self.clientDevice"):
                dev_mac = dev.pluginProps.get("clientMac", "").lower()
                if dev_mac:
                    existing_macs.add(dev_mac)
            
            created_count = 0
            for mac, client in client_map.items():
                if mac in existing_macs:
                    continue
                
                if mac in self.deleted_clients:
                    continue  # Skip previously deleted
                
                # Only create unknown/guest clients
                is_noted = client.get('noted', False)
                has_fixed_ip = client.get('use_fixedip', False)
                
                if is_noted or has_fixed_ip:
                    continue  # Skip known clients
                
                # Create device
                self._create_client_device(controller_id, client)
                created_count += 1
            
            self.logger.info(f"Created {created_count} unknown client devices")
            return True
            
        except Exception as e:
            self.logger.error(f"Error discovering unknown clients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def menuRemoveMissingClients(self, action):
        """Menu action to remove clients not on controller"""
        try:
            props = action.props
            controller_id = int(props.get("controllerId", 0))
            
            if controller_id == 0:
                self.logger.error("No controller selected")
                return False
            
            if controller_id not in self.controllers:
                self.logger.error("Controller not connected")
                return False
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error("UniFi Network not enabled")
                return False
            
            api = controller["network_api"]
            
            # Get all clients from controller
            all_clients = api.get_all_clients()
            active_clients = api.get_clients()
            
            # Get all MACs from controller
            controller_macs = set()
            for client in all_clients + active_clients:
                mac = client.get('mac', '').lower()
                if mac:
                    controller_macs.add(mac)
            
            # Check each client device
            removed_count = 0
            for dev in indigo.devices.iter("self.clientDevice"):
                dev_controller_id = int(dev.pluginProps.get("controllerId", 0))
                if dev_controller_id != controller_id:
                    continue
                
                dev_mac = dev.pluginProps.get("clientMac", "").lower()
                if dev_mac and dev_mac not in controller_macs:
                    # Client not on controller anymore - delete
                    self.logger.info(f"Removing missing client: {dev.name}")
                    indigo.device.delete(dev)
                    removed_count += 1
            
            self.logger.info(f"Removed {removed_count} missing client devices")
            return True
            
        except Exception as e:
            self.logger.error(f"Error removing missing clients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def createCameraDevices(self, valuesDict, typeId, devId):
        """Create camera devices from controller"""
        try:
            # Check if this is being called from device config (devId exists but device may not be started)
            if devId == 0:
                self.logger.error("Controller device not yet created")
                return valuesDict
            
            # Get the device
            dev = indigo.devices[devId]
            
            # Check if controller is already connected
            if devId not in self.controllers:
                # Not connected yet - need to connect temporarily
                self.logger.info(f"{dev.name}: Connecting to discover cameras...")
                
                address = valuesDict.get("address", dev.pluginProps.get("address", ""))
                port = int(valuesDict.get("port", dev.pluginProps.get("port", 443)))
                username = valuesDict.get("username", dev.pluginProps.get("username", ""))
                password = valuesDict.get("password", dev.pluginProps.get("password", ""))
                verify_ssl = valuesDict.get("verifySSL", dev.pluginProps.get("verifySSL", False))
                enable_protect = valuesDict.get("enableProtect", dev.pluginProps.get("enableProtect", True))
                
                if not all([address, username, password]):
                    self.logger.error(f"{dev.name}: Missing required configuration (IP, username, or password)")
                    return valuesDict
                
                if not enable_protect:
                    self.logger.error(f"{dev.name}: UniFi Protect is not enabled")
                    return valuesDict
                
                # Create temporary API connection
                try:
                    temp_api = UnifiProtectAPI(address, port, username, password, verify_ssl)
                    temp_api.login()
                    temp_api.get_bootstrap()
                    
                    cameras = temp_api.get_cameras()
                    if not cameras:
                        self.logger.error(f"{dev.name}: No cameras found")
                        return valuesDict
                    
                    # Get existing camera device IDs
                    existing_cameras = {}
                    for camera_dev in indigo.devices.iter("self.protectCamera"):
                        cam_id = camera_dev.pluginProps.get("cameraId")
                        if cam_id:
                            existing_cameras[cam_id] = camera_dev.id
                    
                    # Create missing cameras
                    created = 0
                    for camera in cameras:
                        camera_id = camera.get('id')
                        camera_name = camera.get('name', camera.get('marketName', 'Unknown Camera'))
                        
                        if camera_id not in existing_cameras:
                            # Ensure unique name
                            unique_name = self._get_unique_device_name(camera_name)
                            
                            # Create new device
                            props = {
                                "controllerId": str(devId),
                                "cameraId": camera_id,
                                "cameraName": camera_name
                            }
                            
                            new_dev = indigo.device.create(
                                protocol=indigo.kProtocol.Plugin,
                                address=camera_id,
                                name=unique_name,
                                deviceTypeId="protectCamera",
                                props=props
                            )
                            
                            created += 1
                            self.logger.info(f"Created camera device: {unique_name}")
                    
                    if created > 0:
                        self.logger.info(f"Created {created} new camera device(s)")
                    else:
                        self.logger.info("All cameras already exist")
                    
                    return valuesDict
                    
                except Exception as e:
                    self.logger.error(f"{dev.name}: Connection error: {e}")
                    if self.debug:
                        self.logger.error(traceback.format_exc())
                    return valuesDict
            
            # Controller is already connected
            controller = self.controllers[devId]
            if "protect_api" not in controller:
                self.logger.error(f"{dev.name}: UniFi Protect not enabled")
                return valuesDict
                
            api = controller["protect_api"]
            
            cameras = api.get_cameras()
            if not cameras:
                self.logger.error(f"{dev.name}: No cameras found")
                return valuesDict
            
            # Get existing camera device IDs
            existing_cameras = {}
            for camera_dev in indigo.devices.iter("self.protectCamera"):
                cam_id = camera_dev.pluginProps.get("cameraId")
                if cam_id:
                    existing_cameras[cam_id] = camera_dev.id
            
            # Create missing cameras
            created = 0
            for camera in cameras:
                camera_id = camera.get('id')
                camera_name = camera.get('name', camera.get('marketName', 'Unknown Camera'))
                
                if camera_id not in existing_cameras:
                    # Ensure unique name
                    unique_name = self._get_unique_device_name(camera_name)
                    
                    # Create new device
                    props = {
                        "controllerId": str(devId),
                        "cameraId": camera_id,
                        "cameraName": camera_name
                    }
                    
                    new_dev = indigo.device.create(
                        protocol=indigo.kProtocol.Plugin,
                        address=camera_id,
                        name=unique_name,
                        deviceTypeId="protectCamera",
                        props=props
                    )
                    
                    created += 1
                    self.logger.info(f"Created camera device: {unique_name}")
            
            if created > 0:
                self.logger.info(f"Created {created} new camera device(s)")
            else:
                self.logger.info("All cameras already exist")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating camera devices: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def createNetworkDevices(self, valuesDict, typeId, devId):
        """Create network devices from controller"""
        try:
            # Check if this is being called from device config (devId exists but device may not be started)
            if devId == 0:
                self.logger.error("Controller device not yet created")
                return False
            
            # Get the device
            dev = indigo.devices[devId]
            
            # Get suffix from valuesDict (current config) or device props (saved config)
            suffix = valuesDict.get("deviceNameSuffix", dev.pluginProps.get("deviceNameSuffix", " (UniFi Network)"))
            # Ensure suffix is a string, not boolean
            if not isinstance(suffix, str):
                suffix = " (UniFi Network)"
            
            # Check if controller is already connected
            if devId not in self.controllers:
                # Not connected yet - need to connect temporarily
                self.logger.info(f"{dev.name}: Connecting to discover network devices...")
                
                address = valuesDict.get("address", dev.pluginProps.get("address", ""))
                port = int(valuesDict.get("port", dev.pluginProps.get("port", 443)))
                username = valuesDict.get("username", dev.pluginProps.get("username", ""))
                password = valuesDict.get("password", dev.pluginProps.get("password", ""))
                verify_ssl = valuesDict.get("verifySSL", dev.pluginProps.get("verifySSL", False))
                enable_network = valuesDict.get("enableNetwork", dev.pluginProps.get("enableNetwork", True))
                
                if not all([address, username, password]):
                    self.logger.error(f"{dev.name}: Missing required configuration (IP, username, or password)")
                    return False
                
                if not enable_network:
                    self.logger.error(f"{dev.name}: UniFi Network is not enabled")
                    return False
                
                # Create temporary API connection
                try:
                    temp_api = UnifiNetworkAPI(address, port, username, password, verify_ssl=verify_ssl)
                    temp_api.login()
                    
                    devices = temp_api.get_devices()
                    if not devices:
                        self.logger.error(f"{dev.name}: No network devices found")
                        return False
                    
                    # Get existing network device MACs
                    existing_devices = {}
                    for net_dev in indigo.devices.iter("self.networkDevice"):
                        dev_mac = net_dev.pluginProps.get("deviceMac")
                        if dev_mac:
                            existing_devices[dev_mac] = net_dev.id
                    
                    # Create missing devices
                    created = 0
                    for device in devices:
                        device_mac = device.get('mac')
                        device_name = device.get('name', device.get('model', 'Unknown Device'))
                        device_type = device.get('type', 'unknown')
                        
                        if device_mac not in existing_devices:
                            # Add suffix if configured
                            if suffix:
                                full_name = f"{device_name}{suffix}"
                            else:
                                full_name = device_name
                            
                            # Ensure unique name
                            unique_name = self._get_unique_device_name(full_name)
                            
                            # Create new device
                            props = {
                                "controllerId": str(devId),
                                "deviceMac": device_mac,
                                "deviceName": device_name,
                                "deviceType": device_type
                            }
                            
                            new_dev = indigo.device.create(
                                protocol=indigo.kProtocol.Plugin,
                                address=device_mac,
                                name=unique_name,
                                deviceTypeId="networkDevice",
                                props=props
                            )
                            
                            created += 1
                            self.logger.info(f"Created network device: {unique_name} ({device_type})")
                    
                    if created > 0:
                        self.logger.info(f"Created {created} new network device(s)")
                    else:
                        self.logger.info("All network devices already exist")
                    
                    return valuesDict
                    
                except Exception as e:
                    self.logger.error(f"{dev.name}: Connection error: {e}")
                    if self.debug:
                        self.logger.error(traceback.format_exc())
                    return valuesDict
            
            # Controller is already connected
            controller = self.controllers[devId]
            if "network_api" not in controller:
                self.logger.error(f"{dev.name}: UniFi Network not enabled")
                return False
                
            api = controller["network_api"]
            
            devices = api.get_devices()
            if not devices:
                self.logger.error(f"{dev.name}: No network devices found")
                return False
            
            # Get existing network device MACs
            existing_devices = {}
            for net_dev in indigo.devices.iter("self.networkDevice"):
                dev_mac = net_dev.pluginProps.get("deviceMac")
                if dev_mac:
                    existing_devices[dev_mac] = net_dev.id
            
            # Create missing devices
            created = 0
            for device in devices:
                device_mac = device.get('mac')
                device_name = device.get('name', device.get('model', 'Unknown Device'))
                device_type = device.get('type', 'unknown')
                
                if device_mac not in existing_devices:
                    # Add suffix if configured
                    if suffix:
                        full_name = f"{device_name}{suffix}"
                    else:
                        full_name = device_name
                    
                    # Ensure unique name
                    unique_name = self._get_unique_device_name(full_name)
                    
                    # Create new device
                    props = {
                        "controllerId": str(devId),
                        "deviceMac": device_mac,
                        "deviceName": device_name,
                        "deviceType": device_type
                    }
                    
                    new_dev = indigo.device.create(
                        protocol=indigo.kProtocol.Plugin,
                        address=device_mac,
                        name=unique_name,
                        deviceTypeId="networkDevice",
                        props=props
                    )
                    
                    created += 1
                    self.logger.info(f"Created network device: {unique_name} ({device_type})")
            
            if created > 0:
                self.logger.info(f"Created {created} new network device(s)")
            else:
                self.logger.info("All network devices already exist")
            
            return valuesDict
            
        except Exception as e:
            self.logger.error(f"Error creating network devices: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return valuesDict
    
    ########################################
    # Client Device Management
    ########################################
    
    def _auto_discover_clients(self, controller_id):
        """Auto-discover and create new client devices"""
        try:
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            
            # Get all clients
            all_clients = api.get_all_clients()
            active_clients = api.get_clients()
            
            # Combine and deduplicate
            all_macs = set()
            client_map = {}
            
            for client in all_clients + active_clients:
                mac = client.get('mac', '').lower()
                if mac:
                    all_macs.add(mac)
                    client_map[mac] = client
            
            # Get existing client devices for this controller
            existing_macs = set(controller["clients"].keys())
            
            # Also check all client devices in Indigo (not just ones we're tracking)
            for dev in indigo.devices.iter("self.clientDevice"):
                dev_mac = dev.pluginProps.get("clientMac", "").lower()
                if dev_mac:
                    existing_macs.add(dev_mac)
            
            # Check each new client
            for mac in all_macs:
                if mac in existing_macs:
                    continue  # Already have device
                
                if mac in self.deleted_clients:
                    continue  # User deleted this client, don't recreate
                
                client = client_map[mac]
                
                # Check if we should auto-create
                known_only = self.pluginPrefs.get("autoCreateKnownOnly", True)
                
                if known_only:
                    # Use 'noted' field - True means user has "noted" this client (known)
                    # Or use 'use_fixedip' - True means client has been configured
                    is_noted = client.get('noted', False)
                    has_fixed_ip = client.get('use_fixedip', False)
                    
                    if not (is_noted or has_fixed_ip):
                        continue  # Skip unknown/unmanaged clients
                
                # Create the device
                self._create_client_device(controller_id, client)
            
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Auto-discovery error: {e}")
    
    def _create_client_device(self, controller_id, client):
        """Create a single client device"""
        try:
            mac = client.get('mac', '').lower()
            if not mac:
                return None
            
            # Get client name
            name = client.get('name', client.get('hostname', mac))
            
            # Ensure unique name
            unique_name = self._get_unique_device_name(f"Client: {name}")
            
            # Create device
            props = {
                "controllerId": str(controller_id),
                "clientMac": mac,
                "controlMode": "poe"  # Default to PoE control
            }
            
            new_dev = indigo.device.create(
                protocol=indigo.kProtocol.Plugin,
                address=mac,
                name=unique_name,
                deviceTypeId="clientDevice",
                props=props,
                folder=0
            )
            
            self.logger.info(f"Created client device: {unique_name} ({mac})")
            
            # Setup the device
            self.setup_client_device(new_dev)
            
            return new_dev
            
        except Exception as e:
            self.logger.error(f"Error creating client device: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return None
    
    def _save_deleted_clients(self):
        """Save deleted clients list to preferences"""
        try:
            prefs = self.pluginPrefs
            prefs["deletedClients"] = list(self.deleted_clients)
            self.savePluginPrefs()
        except Exception as e:
            self.logger.error(f"Error saving deleted clients: {e}")
    
    def deviceDeleted(self, dev):
        """Called when a device is deleted"""
        if dev.deviceTypeId == "clientDevice":
            # Track deleted client MAC to prevent auto-recreation
            client_mac = dev.pluginProps.get("clientMac", "").lower()
            if client_mac:
                self.deleted_clients.add(client_mac)
                self._save_deleted_clients()
                if self.debug:
                    self.logger.debug(f"Tracking deleted client: {client_mac}")
    
    def createPortDevices(self, valuesDict, typeId, devId):
        """Create port devices for a switch - called from switch device config button"""
        try:
            if devId == 0:
                self.logger.error("Device not yet created")
                return valuesDict
            
            # Get the parent switch device
            parent_dev = indigo.devices[devId]
            controller_id = int(parent_dev.pluginProps.get("controllerId", 0))
            device_mac = parent_dev.pluginProps.get("deviceMac", "")
            
            if controller_id == 0:
                self.logger.error(f"{parent_dev.name}: No controller configured")
                return valuesDict
            
            # Get port data from switch
            if controller_id not in self.controllers:
                self.logger.error(f"{parent_dev.name}: Controller not connected")
                return valuesDict
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error(f"{parent_dev.name}: UniFi Network not enabled")
                return valuesDict
            
            api = controller["network_api"]
            device_data = api.get_device(device_mac)
            
            if not device_data:
                self.logger.error(f"{parent_dev.name}: Could not get device data")
                return valuesDict
            
            # Debug: Show all top-level keys in device data to find where custom names might be
            if self.debug:
                self.logger.debug(f"{parent_dev.name}: Device data top-level keys: {list(device_data.keys())[:20]}")  # First 20 keys
            
            port_table = device_data.get('port_table', [])
            # Ensure port_table is actually a list
            if not isinstance(port_table, list):
                self.logger.error(f"{parent_dev.name}: Invalid port_table data type")
                return valuesDict
            if not port_table:
                self.logger.error(f"{parent_dev.name}: No ports found")
                return valuesDict
            
            # Get port_overrides which contains custom port names/configs
            port_overrides = device_data.get('port_overrides', [])
            if self.debug:
                self.logger.debug(f"{parent_dev.name}: Found {len(port_overrides)} port overrides")
                if len(port_overrides) > 0:
                    # Log first few overrides to see structure
                    for i, override in enumerate(port_overrides[:3]):
                        if isinstance(override, dict):
                            self.logger.debug(f"  Override {i}: port_idx={override.get('port_idx')}, name='{override.get('name', 'NO_NAME')}'")
            
            # Build a lookup dictionary for port overrides by port_idx
            override_by_idx = {}
            for override in port_overrides:
                if isinstance(override, dict):
                    port_idx = override.get('port_idx')
                    if port_idx is not None:
                        override_by_idx[port_idx] = override
            
            # Get existing ports for this switch
            existing_ports = {}
            for port_dev in indigo.devices.iter("self.unifiPort"):
                if int(port_dev.pluginProps.get("parentDevice", 0)) == devId:
                    port_num = int(port_dev.pluginProps.get("portNumber", 0))
                    if port_num > 0:
                        existing_ports[port_num] = port_dev.id
            
            # Create missing ports
            created = 0
            for port in port_table:
                port_idx = port.get('port_idx')
                port_num = port.get('port_num', port_idx)  # Some use port_num, some port_idx
                
                # Debug: log port data to see what fields are available
                if self.debug and port_num == 1:
                    self.logger.debug(f"{parent_dev.name} Port {port_num} data keys: {list(port.keys())}")
                    self.logger.debug(f"{parent_dev.name} Port {port_num} name field: '{port.get('name', 'NOT_FOUND')}'")
                
                if port_num and port_num not in existing_ports:
                    # Get port name - check port overrides first (where custom names are stored)
                    port_idx_for_name = port.get('port_idx', port_num)
                    port_name = None
                    
                    # Check if there's an override with a custom name
                    if port_idx_for_name in override_by_idx:
                        override = override_by_idx[port_idx_for_name]
                        port_name = override.get('name', '').strip()
                        if self.debug and port_num <= 2:
                            self.logger.debug(f"{parent_dev.name} Port {port_num}: Found override with name='{port_name}'")
                    
                    # Fall back to port_table name if no override
                    if not port_name:
                        port_name = port.get('name', '').strip()
                    
                    # Try other possible name fields
                    if not port_name:
                        port_name = port.get('portconf_name', '').strip()
                    
                    # If still no name, or name is generic like "Port 1", use switch name + port number
                    if not port_name or port_name.lower().startswith('port '):
                        port_name = f"{parent_dev.name} - Port {port_num}"
                    
                    # Ensure unique name
                    unique_name = self._get_unique_device_name(port_name)
                    
                    # Create new port device
                    props = {
                        "parentDevice": str(devId),
                        "portNumber": str(port_num),
                        "controllerId": str(controller_id),
                        "deviceMac": device_mac
                    }
                    
                    new_dev = indigo.device.create(
                        protocol=indigo.kProtocol.Plugin,
                        address=f"{device_mac}:{port_num}",
                        name=unique_name,
                        deviceTypeId="unifiPort",
                        props=props
                    )
                    
                    created += 1
                    self.logger.info(f"Created port device: {unique_name}")
            
            if created > 0:
                self.logger.info(f"Created {created} new port device(s)")
            else:
                self.logger.info("All ports already exist")
            
            return valuesDict
            
        except Exception as e:
            self.logger.error(f"Error creating port devices: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return valuesDict
    
    ########################################
    # Action Methods - Protect
    ########################################
    
    def actionRestartController(self, action):
        """Restart controller"""
        try:
            dev = indigo.devices[action.deviceId]
            
            if dev.id not in self.controllers:
                self.logger.error(f"{dev.name}: Controller not connected")
                return
            
            controller = self.controllers[dev.id]
            if "protect_api" in controller:
                api = controller["protect_api"]
                self.logger.info(f"{dev.name}: Restarting Protect NVR")
                api.restart_nvr()
            else:
                self.logger.error(f"{dev.name}: UniFi Protect not enabled")
                
        except Exception as e:
            self.logger.error(f"Error restarting controller: {e}")
    
    def actionDiscoverAllClients(self, action):
        """Action to discover all clients from controller device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = dev.id
            
            # Get minLastSeen from action props
            min_last_seen = int(action.props.get("minLastSeen", 30))
            
            # Create a fake action object with the right structure for the menu method
            class FakeAction:
                def __init__(self, controller_id, min_last_seen):
                    self.props = {
                        "controllerId": str(controller_id),
                        "minLastSeen": str(min_last_seen)
                    }
            
            fake_action = FakeAction(controller_id, min_last_seen)
            return self.menuDiscoverAllClients(fake_action)
            
        except Exception as e:
            self.logger.error(f"Error in actionDiscoverAllClients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def actionDiscoverUnknownClients(self, action):
        """Action to discover unknown clients from controller device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = dev.id
            
            # Create a fake action object
            class FakeAction:
                def __init__(self, controller_id):
                    self.props = {"controllerId": str(controller_id)}
            
            fake_action = FakeAction(controller_id)
            return self.menuDiscoverUnknownClients(fake_action)
            
        except Exception as e:
            self.logger.error(f"Error in actionDiscoverUnknownClients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def actionRemoveMissingClients(self, action):
        """Action to remove missing clients from controller device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = dev.id
            
            # Create a fake action object
            class FakeAction:
                def __init__(self, controller_id):
                    self.props = {"controllerId": str(controller_id)}
            
            fake_action = FakeAction(controller_id)
            return self.menuRemoveMissingClients(fake_action)
            
        except Exception as e:
            self.logger.error(f"Error in actionRemoveMissingClients: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return False
    
    def actionSetRecordingMode(self, action):
        """Set camera recording mode"""
        try:
            dev = indigo.devices[action.deviceId]
            mode = action.props.get("recordingMode", "always")
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting recording mode to {mode}")
            
            settings = {
                "recordingSettings": {
                    "mode": mode
                }
            }
            api.update_camera(camera_id, settings)
            
            # Refresh states
            controller_id = self._get_controller_for_camera(dev)
            self.update_camera_states(controller_id, camera_id)
            
        except Exception as e:
            self.logger.error(f"Error setting recording mode: {e}")
    
    def actionSetIRMode(self, action):
        """Set camera IR mode"""
        try:
            dev = indigo.devices[action.deviceId]
            mode = action.props.get("irMode", "auto")
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting IR mode to {mode}")
            
            settings = {
                "ispSettings": {
                    "irLedMode": mode
                }
            }
            api.update_camera(camera_id, settings)
            
            # Refresh states
            controller_id = self._get_controller_for_camera(dev)
            self.update_camera_states(controller_id, camera_id)
            
        except Exception as e:
            self.logger.error(f"Error setting IR mode: {e}")
    
    def actionSetStatusLight(self, action):
        """Set camera status light"""
        try:
            dev = indigo.devices[action.deviceId]
            enabled = action.props.get("enabled", True)
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting status light to {enabled}")
            
            settings = {
                "ledSettings": {
                    "isEnabled": enabled
                }
            }
            api.update_camera(camera_id, settings)
            
            # Refresh states
            controller_id = self._get_controller_for_camera(dev)
            self.update_camera_states(controller_id, camera_id)
            
        except Exception as e:
            self.logger.error(f"Error setting status light: {e}")
    
    def actionSetOverlays(self, action):
        """Set camera overlay settings"""
        try:
            dev = indigo.devices[action.deviceId]
            show_name = action.props.get("showName", True)
            show_date = action.props.get("showDate", True)
            show_logo = action.props.get("showLogo", False)
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting overlays")
            
            settings = {
                "osdSettings": {
                    "isNameEnabled": show_name,
                    "isDateEnabled": show_date,
                    "isLogoEnabled": show_logo
                }
            }
            api.update_camera(camera_id, settings)
            
            # Refresh states
            controller_id = self._get_controller_for_camera(dev)
            self.update_camera_states(controller_id, camera_id)
            
        except Exception as e:
            self.logger.error(f"Error setting overlays: {e}")
    
    def actionSetStatusMessage(self, action):
        """Set camera status message"""
        try:
            dev = indigo.devices[action.deviceId]
            message = action.props.get("message", "")
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting status message")
            
            settings = {
                "lcdMessage": {
                    "text": message
                }
            }
            api.update_camera(camera_id, settings)
            
        except Exception as e:
            self.logger.error(f"Error setting status message: {e}")
    
    def actionEnableDetections(self, action):
        """Enable detection types"""
        try:
            dev = indigo.devices[action.deviceId]
            motion = action.props.get("motion", True)
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Setting detection types")
            
            settings = {
                "recordingSettings": {
                    "enableMotionDetection": motion
                }
            }
            api.update_camera(camera_id, settings)
            
            # Refresh states
            controller_id = self._get_controller_for_camera(dev)
            self.update_camera_states(controller_id, camera_id)
            
        except Exception as e:
            self.logger.error(f"Error enabling detections: {e}")
    
    def actionRebootCamera(self, action):
        """Reboot a camera"""
        try:
            dev = indigo.devices[action.deviceId]
            camera_id, api = self._get_camera_api(dev)
            
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Rebooting camera")
            api.reboot_camera(camera_id)
            
        except Exception as e:
            self.logger.error(f"Error rebooting camera: {e}")
    
    def actionTakeSnapshot(self, action):
        """Take a snapshot"""
        try:
            dev = indigo.devices[action.deviceId]
            save_path = action.props.get("savePath", "")
            
            camera_id, api = self._get_camera_api(dev)
            if not api:
                return
                
            self.logger.info(f"{dev.name}: Snapshot URL available in snapshotUrl state")
            
            if save_path:
                camera = api.get_camera(camera_id)
                camera_ip = camera.get('host', '')
                
                if camera_ip:
                    url = f"http://{camera_ip}/snap.jpeg"
                    request = urllib.request.Request(url)
                    
                    response = urllib.request.urlopen(request, timeout=10)
                    image_data = response.read()
                    
                    with open(save_path, 'wb') as f:
                        f.write(image_data)
                        
                    self.logger.info(f"{dev.name}: Snapshot saved to {save_path}")
                else:
                    self.logger.error(f"{dev.name}: Camera IP address not available")
                
        except Exception as e:
            self.logger.error(f"Error taking snapshot: {e}")
    
    ########################################
    # Action Methods - Network
    ########################################
    
    def actionRestartDevice(self, action):
        """Restart a network device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                self.logger.error(f"{dev.name}: Controller not connected")
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error(f"{dev.name}: UniFi Network not enabled")
                return
            
            api = controller["network_api"]
            self.logger.info(f"{dev.name}: Restarting device")
            api.restart_device(device_mac)
            
        except Exception as e:
            self.logger.error(f"Error restarting device: {e}")
    
    def actionDisableDevice(self, action):
        """Disable a network device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            device = api.get_device(device_mac)
            if not device:
                return
            
            device_id = device.get('_id')
            self.logger.info(f"{dev.name}: Disabling device")
            api.disable_device(device_id)
            
            # Update states
            time.sleep(1)
            self.update_network_device_states(controller_id, device_mac)
            
        except Exception as e:
            self.logger.error(f"Error disabling device: {e}")
    
    def actionEnableDevice(self, action):
        """Enable a network device"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            device = api.get_device(device_mac)
            if not device:
                return
            
            device_id = device.get('_id')
            self.logger.info(f"{dev.name}: Enabling device")
            api.enable_device(device_id)
            
            # Update states
            time.sleep(1)
            self.update_network_device_states(controller_id, device_mac)
            
        except Exception as e:
            self.logger.error(f"Error enabling device: {e}")
    
    def actionToggleDevice(self, action):
        """Toggle device enabled/disabled"""
        try:
            dev = indigo.devices[action.deviceId]
            
            if dev.states.get("disabled", False):
                self.actionEnableDevice(action)
            else:
                self.actionDisableDevice(action)
                
        except Exception as e:
            self.logger.error(f"Error toggling device: {e}")
    
    def actionSetDeviceLED(self, action):
        """Set device LED on/off"""
        try:
            dev = indigo.devices[action.deviceId]
            enabled = action.props.get("enabled", True)
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            device = api.get_device(device_mac)
            if not device:
                return
            
            device_id = device.get('_id')
            self.logger.info(f"{dev.name}: Setting LED to {enabled}")
            api.set_device_led(device_id, enabled)
            
            # Update states
            time.sleep(1)
            self.update_network_device_states(controller_id, device_mac)
            
        except Exception as e:
            self.logger.error(f"Error setting LED: {e}")
    
    def actionToggleDeviceLED(self, action):
        """Toggle device LED"""
        try:
            dev = indigo.devices[action.deviceId]
            current_state = dev.states.get("ledEnabled", False)
            
            action.props["enabled"] = not current_state
            self.actionSetDeviceLED(action)
                
        except Exception as e:
            self.logger.error(f"Error toggling LED: {e}")
    
    def actionLocateDevice(self, action):
        """Flash device LEDs for location"""
        try:
            dev = indigo.devices[action.deviceId]
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            
            if controller_id not in self.controllers:
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                return
            
            api = controller["network_api"]
            self.logger.info(f"{dev.name}: Flashing LEDs for location")
            api.locate_device(device_mac, True)
            
        except Exception as e:
            self.logger.error(f"Error locating device: {e}")
    
    ########################################
    # Action Methods - Ports
    ########################################
    
    def actionControlDevice(self, action):
        """Handle on/off control for relay-type devices (network devices and ports)"""
        try:
            dev = indigo.devices[action.deviceId]
            
            # The action object tells us what was requested (not the current state)
            # action can be: TurnOn, TurnOff, Toggle, RequestStatus
            
            if self.debug:
                self.logger.debug(f"actionControlDevice: device={dev.name}, action={action}")
            
            if dev.deviceTypeId == "networkDevice":
                # Network device on/off control
                self.update_network_device_enabled(dev)
            elif dev.deviceTypeId == "unifiPort":
                # Port device on/off control (respects control mode)
                # Pass the action so we know what was requested
                self.update_port_control(dev, action)
            elif dev.deviceTypeId == "clientDevice":
                # Client device on/off control (respects control mode)
                self.update_client_control(dev, action)
            else:
                self.logger.error(f"actionControlDevice called for unsupported device type: {dev.deviceTypeId}")
                
        except Exception as e:
            self.logger.error(f"Error in actionControlDevice: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    def actionEnablePort(self, action):
        """Enable a port"""
        try:
            dev = indigo.devices[action.deviceId]
            self._port_action(dev, "enable")
        except Exception as e:
            self.logger.error(f"Error enabling port: {e}")
    
    def actionDisablePort(self, action):
        """Disable a port"""
        try:
            dev = indigo.devices[action.deviceId]
            self._port_action(dev, "disable")
        except Exception as e:
            self.logger.error(f"Error disabling port: {e}")
    
    def actionCyclePort(self, action):
        """Power cycle a port"""
        try:
            dev = indigo.devices[action.deviceId]
            self._port_action(dev, "cycle")
        except Exception as e:
            self.logger.error(f"Error cycling port: {e}")
    
    def actionSetPoeMode(self, action):
        """Set PoE mode on a port"""
        try:
            dev = indigo.devices[action.deviceId]
            poe_mode = action.props.get("poeMode", "auto")
            self._port_action(dev, "set_poe", poe_mode)
        except Exception as e:
            self.logger.error(f"Error setting PoE mode: {e}")
    
    def _port_action(self, dev, action_type, param=None):
        """Perform an action on a port"""
        try:
            controller_id = int(dev.pluginProps.get("controllerId", 0))
            device_mac = dev.pluginProps.get("deviceMac", "")
            port_number = int(dev.pluginProps.get("portNumber", 0))
            
            if controller_id not in self.controllers:
                self.logger.error(f"{dev.name}: Controller not connected")
                return
            
            controller = self.controllers[controller_id]
            if "network_api" not in controller:
                self.logger.error(f"{dev.name}: UniFi Network not enabled")
                return
            
            api = controller["network_api"]
            
            # Get parent switch to find device_id
            device = api.get_device(device_mac)
            if not device:
                self.logger.error(f"{dev.name}: Parent switch not found")
                return
            
            device_id = device.get('_id')
            
            # Find port_idx from port_table
            port_table = device.get('port_table', [])
            port_idx = None
            for port in port_table:
                if port.get('port_num') == port_number or port.get('port_idx') == port_number:
                    port_idx = port.get('port_idx', port_number)
                    break
            
            if port_idx is None:
                self.logger.error(f"{dev.name}: Port index not found")
                return
            
            # Perform action
            if action_type == "enable":
                self.logger.info(f"{dev.name}: Enabling port")
                api.enable_port(device_id, port_idx)
            elif action_type == "disable":
                self.logger.info(f"{dev.name}: Disabling port")
                api.disable_port(device_id, port_idx)
            elif action_type == "cycle":
                self.logger.info(f"{dev.name}: Power cycling port")
                api.cycle_port(device_mac, port_idx)  # cycle_port uses MAC not device_id
            elif action_type == "set_poe":
                self.logger.info(f"{dev.name}: Setting PoE mode to {param}")
                api.set_port_poe_mode(device_id, port_idx, param)
            
            # Refresh states after a delay
            time.sleep(2)
            self.update_port_states(controller_id, device_mac, port_number)
            
        except Exception as e:
            self.logger.error(f"Error performing port action: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
    
    ########################################
    # Helper Methods
    ########################################
    
    def _get_camera_api(self, dev):
        """Get camera ID and API for a camera device"""
        controller_id = int(dev.pluginProps.get("controllerId", 0))
        camera_id = dev.pluginProps.get("cameraId", "")
        
        if controller_id not in self.controllers:
            self.logger.error(f"{dev.name}: Controller not connected")
            return None, None
        
        controller = self.controllers[controller_id]
        if "protect_api" not in controller:
            self.logger.error(f"{dev.name}: UniFi Protect not enabled")
            return None, None
            
        api = controller["protect_api"]
        return camera_id, api
        
    def _get_controller_for_camera(self, dev):
        """Get controller ID for a camera device"""
        return int(dev.pluginProps.get("controllerId", 0))
