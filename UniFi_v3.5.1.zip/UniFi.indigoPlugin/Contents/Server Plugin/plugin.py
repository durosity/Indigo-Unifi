#! /usr/bin/env python
# -*- coding: utf-8 -*-
# UniFi Plugin for Indigo Domotics
# Author: Durosity
# Version: 3.5.1
#
# Architecture:
#   - Network:  Official Integration API (X-API-KEY) where possible,
#               legacy cookie auth as a documented bridge for endpoints
#               not yet exposed by the Integration API.
#   - Protect:  Official Integration API (Bearer) with JSON WebSockets.
#   - Access:   Official Developer API on port 12445 (Bearer) with WS.
#   - Drive:    Legacy cookie auth (no official API exists yet).

import indigo

import base64
import json
import os
import socket
import ssl
import struct
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from http.cookiejar import CookieJar


# ============================================================================
# Constants
# ============================================================================

PLUGIN_VERSION       = "3.5.1"

# Default ports
DEFAULT_HTTPS_PORT   = 443
DEFAULT_ACCESS_PORT  = 12445  # UniFi Access developer API runs on its own port

# Polling intervals (seconds)
DEFAULT_STATS_INTERVAL_SEC   = 300   # 5 min - configurable in controller UI
DEFAULT_SANITY_INTERVAL_SEC  = 900   # 15 min - configurable
AGGRESSIVE_INTERVAL_SEC      = 30    # only used when aggressive mode toggled

# WebSocket reconnect backoff
WS_RECONNECT_INITIAL_SEC     = 5
WS_RECONNECT_MAX_SEC         = 300
WS_RECONNECT_BACKOFF_FACTOR  = 2

# Network timeouts
DEFAULT_HTTP_TIMEOUT_SEC     = 30
BOOTSTRAP_TIMEOUT_SEC        = 60

# ----------------------------------------------------------------------------
# UniFi Drive (UNAS) endpoints
#
# Cross-checked against the memphi2/ha-unifi-drive HA integration (MIT-
# licensed). That project actively maintains support for current UNAS
# firmware. The plugin's earlier guesses at /proxy/drive/api/storage were
# wrong on current firmware; the v2 paths below are what UNAS responds to.
# ----------------------------------------------------------------------------
DRIVE_LOGIN_PATH               = "/api/auth/login"
DRIVE_STORAGE_PATH             = "/proxy/drive/api/v2/storage"
DRIVE_FAN_CONTROL_PATH         = "/proxy/drive/api/v2/systems/fan-control"
DRIVE_SYSTEM_PATH              = "/api/system"
DRIVE_REBOOT_PATH              = "/api/system/reboot"
DRIVE_POWEROFF_PATH            = "/api/system/poweroff"
DRIVE_FIRMWARE_UPDATE_PATH     = "/api/firmware/update"
DRIVE_APP_UPDATE_PATH          = "/api/applications/drive/update"

# Fan modes: canonical name (used in UI) -> tuple of API payload values to try
DRIVE_FAN_MODE_OPTIONS = ("Quiet", "Balance", "Cooling")
DRIVE_FAN_MODE_API_VALUES = {
    "Quiet":   ("quiet",),
    "Balance": ("default", "default_profile", "balance", "balanced"),
    "Cooling": ("cooling", "cool"),
}


# ============================================================================
# Shared HTTP helpers
# ============================================================================

def _build_ssl_context(verify_ssl):
    """Build an SSL context that either verifies certs or doesn't."""
    if verify_ssl:
        return ssl.create_default_context()
    return ssl._create_unverified_context()


def _build_opener(ssl_context, cookie_jar=None):
    """Build a urllib opener with optional cookie support."""
    handlers = [urllib.request.HTTPSHandler(context=ssl_context)]
    if cookie_jar is not None:
        handlers.append(urllib.request.HTTPCookieProcessor(cookie_jar))
    return urllib.request.build_opener(*handlers)


def _decode_error_body(http_error):
    """Read the body of an HTTPError and return a clean string for logs."""
    try:
        body = http_error.read()
        if not body:
            return ""
        text = body.decode("utf-8", errors="replace")
        # If it's HTML, don't dump the whole page
        stripped = text.lstrip()
        if stripped.startswith("<"):
            return f"(HTML response, status {http_error.code})"
        return text[:500]
    except Exception:
        return ""


class UnifiAuthError(Exception):
    """Raised when authentication fails."""


class UnifiNotFoundError(Exception):
    """Raised when a resource (camera, door, etc) is not found."""


class UnifiAPIError(Exception):
    """Generic API failure."""


# ============================================================================
# Drive payload parsing helpers
# ----------------------------------------------------------------------------
# UNAS storage payloads have a lot of field-name variation across firmware
# versions (memphi2's integration calls out 10+ variants per field). Rather
# than copy that whole helper module, we use a focused "first matching key"
# approach with the most common variant names.
# ============================================================================

_DRIVE_CAPACITY_KEYS = (
    "capacity", "total", "totalBytes", "totalSize", "totalCapacity",
    "capacityBytes", "size", "usableCapacity", "usableSize", "volumeSize",
)
_DRIVE_USAGE_KEYS = (
    "usage", "used", "usedBytes", "usedSize", "usedCapacity",
    "usedSpace", "usedSpaceBytes", "usedStorage",
)
_DRIVE_AVAILABLE_KEYS = (
    "available", "availableBytes", "availableSize", "availableCapacity",
    "free", "freeBytes", "freeSize", "freeSpace", "freeSpaceBytes",
    "remaining", "remainingBytes",
)
_DRIVE_AGG_CAPACITY_KEYS = (
    "totalStorage", "totalStorageBytes", "storageTotalBytes", "storageTotal",
)
_DRIVE_AGG_USAGE_KEYS = (
    "usedStorage", "usedStorageBytes", "storageUsedBytes", "storageUsed",
)
_DRIVE_AGG_AVAILABLE_KEYS = (
    "availableStorage", "availableStorageBytes", "storageAvailableBytes",
    "storageAvailable", "freeStorage",
)
_DRIVE_RAID_KEYS = (
    "raidType", "raid_type", "raidLevel", "raid_level",
    "poolType", "pool_type", "protection", "protectionLevel",
    "layout", "type",
)
_DRIVE_POOL_LIST_KEYS = (
    "pools", "storagePools", "storage_pools", "volumes", "volumeList",
)
_DRIVE_DISK_LIST_KEYS = (
    "disks", "drives", "members", "physicalDrives", "physicalDisks",
)

# Status values that mean "everything is fine" — used to decide whether to
# raise problem flags. Case-insensitive; new variants belong here, not in the
# call sites.
_DRIVE_HEALTHY_STATUSES = frozenset({
    "ok", "online", "healthy", "normal", "good",
    "fullyoperational", "fully_operational",
    "operational", "optimal",
    "active", "ready", "running",
})

# Status values that mean "this needs attention".
_DRIVE_PROBLEM_STATUSES = frozenset({
    "degraded", "warning", "unhealthy", "failed", "failing",
    "error", "critical", "missing", "offline",
})

# Status values that mean "this disk is showing early warning signs".
_DRIVE_AT_RISK_STATUSES = frozenset({
    "at_risk", "atrisk", "warning", "degraded", "predictivefail",
    "predictive_fail",
})


def _drive_is_healthy(status_text):
    """Return True if status_text is a known good status, False otherwise.
    None / empty / unknown statuses are treated as NOT healthy (conservative
    default — better to flag a phantom problem than miss a real one)."""
    if not status_text:
        return False
    return str(status_text).strip().lower().replace("-", "_") in _DRIVE_HEALTHY_STATUSES


def _drive_is_at_risk(status_text):
    if not status_text:
        return False
    return str(status_text).strip().lower().replace("-", "_") in _DRIVE_AT_RISK_STATUSES


# ============================================================================
# Client purge — MAC randomisation detection
# ----------------------------------------------------------------------------
# Per IEEE 802 (and RFC 9724), a locally-administered unicast MAC address has
# the second-least-significant bit of the first octet set to 1. iPhone "Private
# Address", Android "Use random MAC", and Windows "Random hardware addresses"
# all generate addresses that follow this rule.
#
# The simple test: the second hex digit of the first octet is 2, 6, A, or E
# (i.e. first-octet & 0x02 != 0).
# ============================================================================

def _mac_is_randomised(mac):
    """Return True if `mac` looks like a randomised/locally-administered MAC.

    Accepts any common MAC formatting (with or without separators, any case).
    Returns False for malformed input — safer to leave unknown MACs alone than
    to risk purging something legitimate.
    """
    if not mac:
        return False
    # Strip everything except hex digits
    hex_only = "".join(c for c in str(mac) if c in "0123456789abcdefABCDEF")
    if len(hex_only) < 2:
        return False
    try:
        first_octet = int(hex_only[:2], 16)
    except ValueError:
        return False
    # Bit 1 of the first octet is the U/L bit — set means locally administered
    return bool(first_octet & 0x02)


def _has_user_named_client(client):
    """Return True if the user has explicitly named or noted this client in
    UniFi (custom name, hostname override, or note)."""
    if not isinstance(client, dict):
        return False
    for k in ("name", "hostname_override", "display_name"):
        v = client.get(k)
        if v and str(v).strip():
            return True
    for k in ("noted", "note"):
        v = client.get(k)
        if v and str(v).strip():
            return True
    return False


def _has_user_metadata_other_than_name(client):
    """Return True if the user has set non-name metadata: fixed IP, user
    group, or device-type override. These all suggest 'I care about this
    client' beyond just naming it."""
    if not isinstance(client, dict):
        return False
    # Fixed IP assignment
    if client.get("use_fixedip") and client.get("fixed_ip"):
        return True
    # User group assignment
    ug = client.get("usergroup_id")
    if ug and str(ug).strip():
        return True
    # Device identification override
    for k in ("dev_id_override", "dev_cat", "dev_family"):
        v = client.get(k)
        if v not in (None, "", 0):
            return True
    return False


def _client_has_user_metadata(client):
    """Return True if a UniFi client record has ANY user-set metadata that
    suggests the user cares about it. Combines the name and metadata checks."""
    return _has_user_named_client(client) or _has_user_metadata_other_than_name(client)


def _client_age_seconds(client, now_ts=None):
    """Return the number of seconds since the client was last seen, or None
    if last_seen is missing/invalid."""
    if not isinstance(client, dict):
        return None
    last_seen = client.get("last_seen")
    if last_seen is None:
        return None
    try:
        ls = float(last_seen)
    except (TypeError, ValueError):
        return None
    if ls <= 0:
        return None
    if now_ts is None:
        now_ts = time.time()
    return max(0.0, now_ts - ls)


def _drive_first_number(payload, keys):
    """Return the first numeric value found in `payload` under any of `keys`."""
    if not isinstance(payload, dict):
        return None
    for k in keys:
        v = payload.get(k)
        if v is None:
            continue
        try:
            n = float(v)
            return n
        except (TypeError, ValueError):
            continue
    return None


def _drive_first_text(payload, keys):
    """Return the first non-empty string value in `payload` under any of `keys`."""
    if not isinstance(payload, dict):
        return None
    for k in keys:
        v = payload.get(k)
        if v is None:
            continue
        s = str(v).strip()
        if s:
            return s
    return None


def _drive_bytes_to_gb(value):
    """Convert a byte count to GB (1024^3). Returns None on bad input."""
    if value is None:
        return None
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    if n <= 0:
        return 0.0
    return round(n / (1024 ** 3), 2)


def _drive_extract_pools(storage_payload):
    """Find the pool list inside a storage payload. UNAS payloads put it under
    one of several keys, sometimes nested in a 'storage' or 'data' container."""
    if not isinstance(storage_payload, dict):
        return []

    # Try at top level
    for key in _DRIVE_POOL_LIST_KEYS:
        v = storage_payload.get(key)
        if isinstance(v, list):
            return [p for p in v if isinstance(p, dict)]

    # Try one level of nesting
    for container_key in ("storage", "storageInfo", "data", "result"):
        sub = storage_payload.get(container_key)
        if isinstance(sub, dict):
            for key in _DRIVE_POOL_LIST_KEYS:
                v = sub.get(key)
                if isinstance(v, list):
                    return [p for p in v if isinstance(p, dict)]

    return []


def _drive_extract_disks(storage):
    """Find the disk list. UniFi UNAS firmware puts disks at the TOP level of
    the storage payload (not nested per-pool); each disk's `poolId` field links
    it to its parent pool. Older firmware variants nested disks per-pool — we
    still handle those as a fallback."""
    if not isinstance(storage, dict):
        return []
    # Top-level disks array (current UNAS firmware)
    for key in _DRIVE_DISK_LIST_KEYS:
        v = storage.get(key)
        if isinstance(v, list):
            return [d for d in v if isinstance(d, dict)]
    # Try one level of nesting
    for container_key in ("storage", "storageInfo", "data", "result"):
        sub = storage.get(container_key)
        if isinstance(sub, dict):
            for key in _DRIVE_DISK_LIST_KEYS:
                v = sub.get(key)
                if isinstance(v, list):
                    return [d for d in v if isinstance(d, dict)]
    return []


def _drive_extract_disks_for_pool(storage, pool):
    """Return all disks belonging to a given pool. Disks reference their
    parent pool by `poolId`. Falls back to per-pool nesting on legacy firmware."""
    if not isinstance(pool, dict):
        return []
    # Modern: top-level disks list filtered by poolId
    pool_id = pool.get("id") or pool.get("guid") or pool.get("poolGuid") or pool.get("uuid")
    top_level = _drive_extract_disks(storage if isinstance(storage, dict) else {})
    if top_level and pool_id:
        filtered = [d for d in top_level if d.get("poolId") == pool_id or
                                              d.get("pool_id") == pool_id or
                                              d.get("poolGuid") == pool_id]
        if filtered:
            return filtered
        # If no disks matched by poolId but there's only one pool, all disks
        # implicitly belong to it.
        return top_level
    # Legacy: per-pool nesting
    for key in _DRIVE_DISK_LIST_KEYS:
        v = pool.get(key)
        if isinstance(v, list):
            return [d for d in v if isinstance(d, dict)]
    return []


# Backwards-compatible alias for old call sites that don't have storage context.
def _drive_extract_disks_from_pool(pool):
    """Deprecated: prefer _drive_extract_disks_for_pool(storage, pool)."""
    return _drive_extract_disks_for_pool({}, pool)


def _drive_pool_key(pool, index):
    """Return a stable identifier for a pool: guid > id > name > 'pool_N'."""
    if not isinstance(pool, dict):
        return f"pool_{index}"
    for k in ("poolGuid", "guid", "id", "uuid"):
        v = pool.get(k)
        if v:
            return str(v)
    name = _drive_first_text(pool, ("name", "displayName", "label"))
    if name:
        return f"name:{name}"
    return f"pool_{index}"


def _drive_pool_name(pool, index):
    """Return a display name for a pool."""
    name = _drive_first_text(pool, ("displayName", "name", "label"))
    return name or f"Pool {index + 1}"


def _drive_disk_key(disk, index):
    """Return a stable identifier for a disk: serial > guid > id > slot > 'disk_N'."""
    if not isinstance(disk, dict):
        return f"disk_{index}"
    for k in ("serialNumber", "serial", "guid", "id", "uuid"):
        v = disk.get(k)
        if v:
            return str(v)
    slot = disk.get("slotId") or disk.get("slot") or disk.get("bay") or disk.get("position")
    if slot is not None:
        return f"slot:{slot}"
    return f"disk_{index}"


def _drive_disk_name(disk, index, pool_index=0):
    """Return a display name for a disk. Prefer slot number since that's what
    you see on the physical UNAS chassis."""
    if isinstance(disk, dict):
        slot = (disk.get("slotId") or disk.get("slot") or
                disk.get("bay") or disk.get("position"))
        if slot is not None:
            return f"Slot {slot}"
        name = _drive_first_text(disk, ("displayName", "name", "label"))
        if name:
            return name
    return f"Disk {pool_index + 1}.{index + 1}"


# ============================================================================
# UniFi Network API
# ----------------------------------------------------------------------------
# This class wraps BOTH the official Integration API and the legacy cookie
# API. The Integration API is preferred where it's available; legacy is the
# documented bridge for endpoints Ubiquiti hasn't yet exposed officially.
#
# Each method documents which path it uses so it's easy to spot when a method
# can be promoted from legacy to integration as the official API expands.
# ============================================================================

class UnifiNetworkAPI:
    """UniFi Network API - Integration API where possible, legacy bridge elsewhere."""

    def __init__(self, host, port, api_key, username, password, site="default", verify_ssl=False, logger=None, debug=False):
        self.host         = host
        self.port         = int(port)
        self.api_key      = api_key
        self.username     = username
        self.password     = password
        self.site         = site
        self.verify_ssl   = verify_ssl
        self.logger       = logger
        self.debug        = debug

        self.base_url     = f"https://{host}:{self.port}"
        self.ssl_context  = _build_ssl_context(verify_ssl)

        # Separate openers for integration (no cookies needed) and legacy (cookies needed)
        self.integration_opener = _build_opener(self.ssl_context)
        self.legacy_cookies     = CookieJar()
        self.legacy_opener      = _build_opener(self.ssl_context, self.legacy_cookies)
        self.legacy_csrf        = None
        self.legacy_logged_in   = False

    # ------------------------------------------------------------------
    # Internal request helpers
    # ------------------------------------------------------------------

    def _integration_request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC):
        """Make a request to the official Integration API using the X-API-KEY."""
        if not self.api_key:
            raise UnifiAuthError("Network Integration API key is not configured")

        url = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None

        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("X-API-KEY", self.api_key)
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")

        try:
            response = self.integration_opener.open(req, timeout=timeout)
            payload = response.read().decode("utf-8")
            return json.loads(payload) if payload else {}
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Integration API auth failed (HTTP {e.code}): {err_body}")
            raise UnifiAPIError(f"Integration API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Integration API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Integration API returned invalid JSON: {e}")

    def _legacy_login(self):
        """Authenticate against the legacy cookie API. Idempotent."""
        if not self.username or not self.password:
            raise UnifiAuthError(
                "Legacy username/password not configured "
                "(needed for endpoints not yet in the Integration API)"
            )

        url = f"{self.base_url}/api/auth/login"
        body = json.dumps({
            "username":   self.username,
            "password":   self.password,
            "rememberMe": True,
        }).encode("utf-8")

        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")

        try:
            response = self.legacy_opener.open(req, timeout=DEFAULT_HTTP_TIMEOUT_SEC)
            response.read()  # drain
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(
                    f"Legacy login failed (HTTP {e.code}). "
                    f"Use a LOCAL-ONLY admin (no MFA, not a UI.com cloud account). "
                    f"Details: {err_body}"
                )
            raise UnifiAuthError(f"Legacy login HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAuthError(f"Legacy login network error: {e}")

        # Extract CSRF token from JWT cookie
        self.legacy_csrf = None
        for cookie in self.legacy_cookies:
            if cookie.name == "TOKEN":
                self.legacy_csrf = self._extract_csrf_from_jwt(cookie.value) or cookie.value
                break

        self.legacy_logged_in = True

    def _extract_csrf_from_jwt(self, jwt_value):
        """Pull csrfToken out of the JWT payload if present."""
        try:
            parts = jwt_value.split(".")
            if len(parts) < 2:
                return None
            payload = parts[1]
            # Pad for base64 decode
            padding = (-len(payload)) % 4
            if padding:
                payload += "=" * padding
            decoded = base64.urlsafe_b64decode(payload)
            data = json.loads(decoded)
            return data.get("csrfToken")
        except Exception:
            return None

    def _legacy_request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC, _retry=True):
        """Make a request to the legacy cookie API. Logs in lazily."""
        if not self.legacy_logged_in:
            self._legacy_login()

        url = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None

        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")
        if self.legacy_csrf and method in ("POST", "PUT", "PATCH", "DELETE"):
            req.add_header("X-CSRF-Token", self.legacy_csrf)

        try:
            response = self.legacy_opener.open(req, timeout=timeout)
            payload = response.read().decode("utf-8")
            if not payload:
                return {}
            # Legacy API sometimes returns HTML on errors; guard against it
            if payload.lstrip().startswith("<"):
                raise UnifiAPIError(f"Legacy API returned HTML (endpoint may not exist — service not installed?)")
            return json.loads(payload)
        except urllib.error.HTTPError as e:
            # 401 -> session expired. Re-login once and retry.
            if e.code == 401 and _retry:
                self.legacy_logged_in = False
                self.legacy_csrf      = None
                return self._legacy_request(method, path, data, timeout, _retry=False)
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Legacy API auth failed (HTTP {e.code}): {err_body}")
            raise UnifiAPIError(f"Legacy API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Legacy API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Legacy API returned invalid JSON: {e}")

    # ------------------------------------------------------------------
    # Public API - reads (currently legacy; promote to integration as
    # endpoints become available)
    # ------------------------------------------------------------------

    def get_site_info(self):
        """[LEGACY] Get site info."""
        return self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/self")

    def get_devices(self):
        """[LEGACY] Get all network devices (rich state including port_table, radio_table)."""
        # NOTE: Integration API has /sites/{id}/devices but with a much narrower
        # response shape. We use legacy here to preserve rich state monitoring.
        result = self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/stat/device")
        return result.get("data", []) if isinstance(result, dict) else []

    def get_device(self, mac_or_id):
        """[LEGACY] Find a device by MAC or _id."""
        target = (mac_or_id or "").lower()
        for d in self.get_devices():
            if d.get("mac", "").lower() == target or d.get("_id", "") == mac_or_id:
                return d
        return None

    def get_clients(self):
        """[LEGACY] Get all currently active clients."""
        result = self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/stat/sta")
        return result.get("data", []) if isinstance(result, dict) else []

    def get_all_clients(self):
        """[LEGACY] Get all known clients (active + inactive)."""
        result = self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/rest/user")
        return result.get("data", []) if isinstance(result, dict) else []

    def get_client(self, mac):
        """[LEGACY] Find a client by MAC across active and known."""
        target = (mac or "").lower()
        for c in self.get_clients():
            if c.get("mac", "").lower() == target:
                return c
        for c in self.get_all_clients():
            if c.get("mac", "").lower() == target:
                return c
        return None

    def get_wlans(self):
        """[LEGACY] Get all SSIDs/WLANs."""
        result = self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/rest/wlanconf")
        return result.get("data", []) if isinstance(result, dict) else []

    def get_networks(self):
        """[LEGACY] Get all networks/VLANs."""
        result = self._legacy_request("GET", f"/proxy/network/api/s/{self.site}/rest/networkconf")
        return result.get("data", []) if isinstance(result, dict) else []

    # ------------------------------------------------------------------
    # Public API - actions
    # ------------------------------------------------------------------

    def restart_device(self, mac):
        """[LEGACY] Restart a network device by MAC."""
        # Integration API: POST /sites/{siteId}/devices/{deviceId}/actions {"action":"RESTART"}
        # Switching to that requires mapping MAC -> deviceId from integration list.
        # Keep legacy for now; promote when we add an integration device cache.
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/devmgr",
                                    data={"cmd": "restart", "mac": mac})

    def locate_device(self, mac, enabled=True):
        """[LEGACY] Flash device LEDs."""
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/devmgr",
                                    data={"cmd": "set-locate", "mac": mac, "enabled": enabled})

    def set_device_led(self, device_id, enabled):
        """[LEGACY] Enable/disable device LED (uses _id, not mac)."""
        return self._legacy_request("PUT", f"/proxy/network/api/s/{self.site}/rest/device/{device_id}",
                                    data={"led_override": "on" if enabled else "off"})

    def disable_device(self, device_id, disabled=True):
        """[LEGACY] Disable/enable a device."""
        return self._legacy_request("PUT", f"/proxy/network/api/s/{self.site}/rest/device/{device_id}",
                                    data={"disabled": bool(disabled)})

    def cycle_port_poe(self, mac, port_idx):
        """[LEGACY] Power-cycle a PoE port."""
        # Integration API has POST /sites/{siteId}/devices/{deviceId}/interfaces/ports/{port}/actions
        # Will be promoted once we cache integration device IDs.
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/devmgr",
                                    data={"cmd": "power-cycle", "mac": mac, "port_idx": port_idx})

    def set_port_override(self, device_id, port_idx, overrides):
        """[LEGACY] Update port_overrides on a switch. Preserves other ports' overrides."""
        device = self.get_device(device_id)
        if not device:
            raise UnifiNotFoundError(f"Device {device_id} not found")

        existing = device.get("port_overrides", []) or []
        updated  = []
        found    = False
        for o in existing:
            if o.get("port_idx") == port_idx:
                merged = dict(o)
                merged.update(overrides)
                updated.append(merged)
                found = True
            else:
                updated.append(o)
        if not found:
            updated.append({"port_idx": port_idx, **overrides})

        return self._legacy_request("PUT", f"/proxy/network/api/s/{self.site}/rest/device/{device_id}",
                                    data={"port_overrides": updated})

    def set_port_poe_mode(self, device_id, port_idx, poe_mode):
        """[LEGACY] Set PoE mode on a port: off/auto/pasv24/passthrough."""
        return self.set_port_override(device_id, port_idx, {"poe_mode": poe_mode})

    def block_client(self, mac):
        """[LEGACY] Block a client by MAC."""
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/stamgr",
                                    data={"cmd": "block-sta", "mac": (mac or "").lower()})

    def unblock_client(self, mac):
        """[LEGACY] Unblock a client by MAC."""
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/stamgr",
                                    data={"cmd": "unblock-sta", "mac": (mac or "").lower()})

    def reconnect_client(self, mac):
        """[LEGACY] Force a client to reconnect."""
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/stamgr",
                                    data={"cmd": "kick-sta", "mac": (mac or "").lower()})

    def forget_client(self, mac):
        """[LEGACY] Remove a client from the controller entirely. This is the
        same as right-clicking a client in the UniFi UI and choosing 'Forget'.
        After this the client disappears from the client list. Calls the
        stamgr forget-sta command, which accepts either a single MAC or a
        list of MACs (we send a list for compatibility)."""
        macs = [(mac or "").lower()]
        return self._legacy_request("POST", f"/proxy/network/api/s/{self.site}/cmd/stamgr",
                                    data={"cmd": "forget-sta", "macs": macs})

    # ------------------------------------------------------------------
    # Connectivity tests
    # ------------------------------------------------------------------

    def test_integration(self):
        """[INTEGRATION] Test the API key by hitting /info."""
        result = self._integration_request("GET", "/proxy/network/integration/v1/info")
        return result

    def test_legacy(self):
        """[LEGACY] Test username/password by logging in."""
        if not self.legacy_logged_in:
            self._legacy_login()
        return self.get_site_info()


# ============================================================================
# UniFi Protect Integration API
# ----------------------------------------------------------------------------
# Uses the official Integration API at /proxy/protect/integration/v1/...
# with Bearer-token auth. JSON WebSocket subscriptions for real-time events
# (devices and events streams).
# ============================================================================

class UnifiProtectAPI:
    """UniFi Protect via the official Integration API (Bearer token + JSON WebSocket)."""

    BASE_PATH      = "/proxy/protect/integration/v1"
    WS_DEVICES     = "/proxy/protect/integration/v1/subscribe/devices"
    WS_EVENTS      = "/proxy/protect/integration/v1/subscribe/events"

    def __init__(self, host, port, api_key, verify_ssl=False, logger=None, debug=False):
        self.host        = host
        self.port        = int(port)
        self.api_key     = api_key
        self.verify_ssl  = verify_ssl
        self.logger      = logger
        self.debug       = debug

        self.base_url    = f"https://{host}:{self.port}"
        self.ssl_context = _build_ssl_context(verify_ssl)
        self.opener      = _build_opener(self.ssl_context)

        # Cached lookups, refreshed on demand
        self._cameras_by_id = {}
        self._sensors_by_id = {}
        self._lights_by_id  = {}
        self._chimes_by_id  = {}
        self._nvr_info      = {}
        self._cache_time    = 0

    # ------------------------------------------------------------------
    # Internal request
    # ------------------------------------------------------------------

    def _request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC):
        if not self.api_key:
            raise UnifiAuthError("Protect API key is not configured")

        url  = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None

        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("X-API-KEY", self.api_key)
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")

        try:
            response = self.opener.open(req, timeout=timeout)
            payload  = response.read().decode("utf-8")
            return json.loads(payload) if payload else {}
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Protect API auth failed (HTTP {e.code}): {err_body}")
            if e.code == 404:
                raise UnifiNotFoundError(f"Protect resource not found: {path}")
            raise UnifiAPIError(f"Protect API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Protect API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Protect API returned invalid JSON: {e}")

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def refresh_cache(self):
        """Refresh the internal device list caches."""
        cameras = self._request("GET", f"{self.BASE_PATH}/cameras")
        sensors = self._request("GET", f"{self.BASE_PATH}/sensors")
        try:
            lights = self._request("GET", f"{self.BASE_PATH}/lights")
        except UnifiNotFoundError:
            lights = []
        try:
            chimes = self._request("GET", f"{self.BASE_PATH}/chimes")
        except UnifiNotFoundError:
            chimes = []
        try:
            nvrs = self._request("GET", f"{self.BASE_PATH}/nvrs")
            # Some Protect versions expose only one NVR; some return an array
            self._nvr_info = nvrs[0] if isinstance(nvrs, list) and nvrs else nvrs
        except UnifiNotFoundError:
            self._nvr_info = {}

        # Each list response is a list of objects; build by-id maps
        self._cameras_by_id = {c.get("id"): c for c in (cameras or []) if c.get("id")}
        self._sensors_by_id = {s.get("id"): s for s in (sensors or []) if s.get("id")}
        self._lights_by_id  = {l.get("id"): l for l in (lights  or []) if l.get("id")}
        self._chimes_by_id  = {ch.get("id"): ch for ch in (chimes or []) if ch.get("id")}
        self._cache_time    = time.time()

    def _ensure_cache(self, max_age_sec=60):
        """Refresh cache if older than max_age_sec."""
        if (time.time() - self._cache_time) > max_age_sec:
            self.refresh_cache()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_nvr(self):
        """Get NVR info."""
        self._ensure_cache()
        return self._nvr_info

    def get_cameras(self):
        """Get all cameras."""
        self._ensure_cache()
        return list(self._cameras_by_id.values())

    def get_camera(self, camera_id):
        """Get a single camera by ID; refresh from server."""
        # Always refresh single-camera reads to get up-to-date state for triggers
        try:
            data = self._request("GET", f"{self.BASE_PATH}/cameras/{camera_id}")
            if data and data.get("id"):
                self._cameras_by_id[data["id"]] = data
            return data
        except UnifiNotFoundError:
            self._cameras_by_id.pop(camera_id, None)
            return None

    def get_sensors(self):
        self._ensure_cache()
        return list(self._sensors_by_id.values())

    def get_sensor(self, sensor_id):
        try:
            data = self._request("GET", f"{self.BASE_PATH}/sensors/{sensor_id}")
            if data and data.get("id"):
                self._sensors_by_id[data["id"]] = data
            return data
        except UnifiNotFoundError:
            self._sensors_by_id.pop(sensor_id, None)
            return None

    def get_lights(self):
        self._ensure_cache()
        return list(self._lights_by_id.values())

    def get_chimes(self):
        self._ensure_cache()
        return list(self._chimes_by_id.values())

    # ----- Actions -----

    def update_camera(self, camera_id, settings):
        """PATCH camera settings - send only fields you want to change."""
        return self._request("PATCH", f"{self.BASE_PATH}/cameras/{camera_id}", data=settings)

    def reboot_camera(self, camera_id):
        """Reboot a camera via the integration action endpoint."""
        return self._request("POST", f"{self.BASE_PATH}/cameras/{camera_id}/reboot")

    def get_camera_snapshot_url(self, camera_id):
        """Build a snapshot URL using Bearer auth (must be fetched with the API key header)."""
        return f"{self.base_url}{self.BASE_PATH}/cameras/{camera_id}/snapshot"

    # ----- Connectivity test -----

    def test_connection(self):
        """Test the Protect API by fetching the meta info / NVR list."""
        try:
            return self._request("GET", f"{self.BASE_PATH}/meta/info")
        except (UnifiNotFoundError, UnifiAPIError):
            # /meta/info isn't on every version; fall back to nvrs list
            return self._request("GET", f"{self.BASE_PATH}/nvrs")


# ============================================================================
# UniFi Access Developer API
# ----------------------------------------------------------------------------
# Runs on its own port (12445), uses Bearer-token auth, and
# /api/v1/developer/... paths. This is a SEPARATE API from the Integrations
# page used by Network and Protect — the token must be generated inside the
# UniFi Access application itself (not from the unified Integrations menu).
# Per Ubiquiti's official Access API reference at
# https://assets.identity.ui.com/unifi-access/api_reference.pdf
# ============================================================================

class UnifiAccessAPI:
    """UniFi Access via its Developer API (port 12445, Bearer token, separate from Network/Protect API)."""

    def __init__(self, host, port, api_key, verify_ssl=False, logger=None, debug=False):
        self.host        = host
        self.port        = int(port)
        self.api_key     = api_key
        self.verify_ssl  = verify_ssl
        self.logger      = logger
        self.debug       = debug

        self.base_url    = f"https://{host}:{self.port}"
        self.ssl_context = _build_ssl_context(verify_ssl)
        self.opener      = _build_opener(self.ssl_context)

    def _request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC):
        if not self.api_key:
            raise UnifiAuthError("Access API key is not configured")

        url  = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None

        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")

        try:
            response = self.opener.open(req, timeout=timeout)
            payload  = response.read().decode("utf-8")
            return json.loads(payload) if payload else {}
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Access API auth failed (HTTP {e.code}): {err_body}")
            if e.code == 404:
                raise UnifiNotFoundError(f"Access resource not found: {path}")
            raise UnifiAPIError(f"Access API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Access API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Access API returned invalid JSON: {e}")

    def _data_payload(self, response):
        """Access API wraps results in {'data': ...}. Unwrap safely."""
        if isinstance(response, dict) and "data" in response:
            return response["data"]
        return response

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_doors(self):
        """List all doors."""
        result = self._request("GET", "/api/v1/developer/doors")
        return self._data_payload(result) or []

    def get_door(self, door_id):
        """Get a specific door by ID."""
        result = self._request("GET", f"/api/v1/developer/doors/{door_id}")
        return self._data_payload(result)

    def unlock_door(self, door_id):
        """Temporarily unlock a door."""
        return self._request("PUT", f"/api/v1/developer/doors/{door_id}/unlocking_rule",
                             data={"type": "custom", "interval": 5})

    def get_devices(self):
        """List all access devices (hubs, readers)."""
        result = self._request("GET", "/api/v1/developer/devices")
        return self._data_payload(result) or []

    def get_access_policies(self):
        """List access policies."""
        result = self._request("GET", "/api/v1/developer/access_policies")
        return self._data_payload(result) or []

    def test_connection(self):
        """Test the Access API by listing doors."""
        return self._request("GET", "/api/v1/developer/doors")


# ============================================================================
# UniFi Drive (UNAS) - LEGACY only
# ----------------------------------------------------------------------------
# No official API exists yet. Uses the legacy cookie session created by the
# Network legacy auth (shares the cookie jar via the same UnifiNetworkAPI).
# When Ubiquiti publishes a Drive integration API, this class can be split.
# ============================================================================

class UnifiDriveAPI:
    """Standalone UniFi Drive (UNAS) API client.

    Endpoints and payload formats based on the memphi2/ha-unifi-drive
    integration (MIT-licensed), which is actively maintained against current
    UNAS firmware. Earlier reverse-engineered /proxy/drive/api/storage paths
    returned 404 on current firmware; the v2 paths used here are correct.

    Authentication supports either:
      * X-API-Key header (preferred — generated from UNAS Integrations page)
      * Legacy cookie auth via /api/auth/login (username + password fallback)
    """

    def __init__(self, host, port, api_key="", username="", password="",
                 verify_ssl=False, logger=None, debug=False):
        self.host         = host
        self.port         = int(port)
        self.api_key      = api_key
        self.username     = username
        self.password     = password
        self.verify_ssl   = verify_ssl
        self.logger       = logger
        self.debug        = debug

        self.base_url     = f"https://{host}:{self.port}"
        self.ssl_context  = _build_ssl_context(verify_ssl)

        # Separate openers: API-key path (no cookies) and legacy (with cookies)
        self.api_opener       = _build_opener(self.ssl_context)
        self.legacy_cookies   = CookieJar()
        self.legacy_opener    = _build_opener(self.ssl_context, self.legacy_cookies)
        self.legacy_csrf      = None
        self.legacy_logged_in = False

        # Firmware-aware caches
        self._fan_mode_write_payload_hint = None  # which payload shape last worked

    @property
    def auth_mode(self):
        """Return 'api_key' or 'legacy' depending on which auth path is active."""
        return "api_key" if self.api_key else "legacy"

    # ------------------------------------------------------------------
    # Auth - API key path
    # ------------------------------------------------------------------

    def _api_request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC,
                     expect_json=True):
        """Request using X-API-Key auth (preferred when configured)."""
        if not self.api_key:
            raise UnifiAuthError("Drive API key is not configured")

        url  = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None
        req  = urllib.request.Request(url, data=body, method=method)
        req.add_header("X-API-Key", self.api_key)
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")

        try:
            response = self.api_opener.open(req, timeout=timeout)
            payload  = response.read().decode("utf-8", errors="replace")
            if not expect_json:
                return response.status, payload
            return json.loads(payload) if payload else {}
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Drive API auth failed (HTTP {e.code}): {err_body}")
            raise UnifiAPIError(f"Drive API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Drive API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Drive API returned invalid JSON: {e}")

    # ------------------------------------------------------------------
    # Auth - Legacy cookie path
    # ------------------------------------------------------------------

    def _legacy_login(self):
        """Authenticate against /api/auth/login. Idempotent."""
        if not self.username or not self.password:
            raise UnifiAuthError("Drive legacy username/password not configured")

        url  = f"{self.base_url}{DRIVE_LOGIN_PATH}"
        body = json.dumps({
            "username":   self.username,
            "password":   self.password,
            "rememberMe": True,
        }).encode("utf-8")
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")

        try:
            response = self.legacy_opener.open(req, timeout=DEFAULT_HTTP_TIMEOUT_SEC)
            response.read()
        except urllib.error.HTTPError as e:
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(
                    f"Drive legacy login failed (HTTP {e.code}). "
                    f"Use a LOCAL-ONLY admin (no MFA). Details: {err_body}"
                )
            raise UnifiAuthError(f"Drive legacy login HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAuthError(f"Drive legacy login network error: {e}")

        # Extract CSRF token from the JWT TOKEN cookie payload
        self.legacy_csrf = None
        for cookie in self.legacy_cookies:
            if cookie.name == "TOKEN":
                try:
                    parts = cookie.value.split(".")
                    if len(parts) >= 2:
                        payload = parts[1]
                        padding = (-len(payload)) % 4
                        if padding:
                            payload += "=" * padding
                        decoded = base64.urlsafe_b64decode(payload)
                        self.legacy_csrf = json.loads(decoded).get("csrfToken")
                except Exception:
                    pass
                break

        self.legacy_logged_in = True

    def _legacy_request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC,
                        expect_json=True, _retry=True):
        """Request using legacy cookie auth. Logs in lazily, retries once on 401."""
        if not self.legacy_logged_in:
            self._legacy_login()

        url  = f"{self.base_url}{path}"
        body = json.dumps(data).encode("utf-8") if data is not None else None
        req  = urllib.request.Request(url, data=body, method=method)
        req.add_header("Accept", "application/json")
        if body is not None:
            req.add_header("Content-Type", "application/json")
        if self.legacy_csrf and method in ("POST", "PUT", "PATCH", "DELETE"):
            req.add_header("X-CSRF-Token", self.legacy_csrf)

        try:
            response = self.legacy_opener.open(req, timeout=timeout)
            payload  = response.read().decode("utf-8", errors="replace")
            if not expect_json:
                return response.status, payload
            if not payload:
                return {}
            if payload.lstrip().startswith("<"):
                raise UnifiAPIError("Drive legacy API returned HTML (endpoint may not exist on this firmware)")
            return json.loads(payload)
        except urllib.error.HTTPError as e:
            if e.code == 401 and _retry:
                self.legacy_logged_in = False
                self.legacy_csrf      = None
                return self._legacy_request(method, path, data, timeout, expect_json, _retry=False)
            err_body = _decode_error_body(e)
            if e.code in (401, 403):
                raise UnifiAuthError(f"Drive legacy auth failed (HTTP {e.code}): {err_body}")
            raise UnifiAPIError(f"Drive legacy API HTTP {e.code}: {err_body}")
        except urllib.error.URLError as e:
            raise UnifiAPIError(f"Drive legacy API network error: {e}")
        except json.JSONDecodeError as e:
            raise UnifiAPIError(f"Drive legacy API returned invalid JSON: {e}")

    # ------------------------------------------------------------------
    # Internal dispatch — pick the right auth path
    # ------------------------------------------------------------------

    def _request(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC,
                 expect_json=True):
        if self.api_key:
            return self._api_request(method, path, data=data, timeout=timeout,
                                     expect_json=expect_json)
        return self._legacy_request(method, path, data=data, timeout=timeout,
                                    expect_json=expect_json)

    def _request_raw(self, method, path, data=None, timeout=DEFAULT_HTTP_TIMEOUT_SEC):
        """Like _request but returns (status_code, body_text) without JSON parsing.
        Used for endpoints that may return non-JSON or where we need the status."""
        try:
            return self._request(method, path, data=data, timeout=timeout, expect_json=False)
        except UnifiAPIError as e:
            # Return synthetic error status so callers can fall through gracefully
            return 0, str(e)

    # ------------------------------------------------------------------
    # Public API — Storage & system
    # ------------------------------------------------------------------

    def get_storage_info(self):
        """Get the full storage payload from the UNAS Drive endpoint."""
        result = self._request("GET", DRIVE_STORAGE_PATH)
        if isinstance(result, dict):
            return result.get("data", result)
        return result if isinstance(result, dict) else {}

    def get_system_info(self):
        """Get UniFi OS system info (hostname, version, uptime, etc.)."""
        result = self._request("GET", DRIVE_SYSTEM_PATH)
        if isinstance(result, dict):
            return result.get("data", result)
        return result if isinstance(result, dict) else {}

    # ------------------------------------------------------------------
    # Public API — Fan control
    # ------------------------------------------------------------------

    def get_fan_info(self):
        """Read fan control state. Returns {} if endpoint unavailable."""
        try:
            result = self._request("GET", DRIVE_FAN_CONTROL_PATH)
            if isinstance(result, dict):
                return result.get("data", result)
        except UnifiAPIError as e:
            if self.debug and self.logger:
                self.logger.debug(f"Fan control endpoint unavailable: {e}")
            return {}
        return {}

    def set_fan_mode(self, canonical_mode):
        """Set fan mode. canonical_mode is one of DRIVE_FAN_MODE_OPTIONS.
        Tries multiple payload shapes since firmware varies."""
        if canonical_mode not in DRIVE_FAN_MODE_API_VALUES:
            raise UnifiAPIError(f"Unknown fan mode: {canonical_mode}")

        # Try the canonical values for this mode in order. memphi2 documents
        # several spellings (e.g. "default", "default_profile", "balance",
        # "balanced") that different firmware versions accept.
        api_values = DRIVE_FAN_MODE_API_VALUES[canonical_mode]

        # Payload shapes: bare {"profile": value} OR {"profile": value, "apply": True}
        last_error = None
        for api_value in api_values:
            payload_variants = [
                {"profile": api_value},
                {"profile": api_value, "apply": True},
                {"mode":    api_value},
                {"mode":    api_value, "apply": True},
            ]
            if self._fan_mode_write_payload_hint == "profile_apply":
                # Promote the apply-variant to the front
                payload_variants = [
                    {"profile": api_value, "apply": True},
                    {"profile": api_value},
                    {"mode":    api_value, "apply": True},
                    {"mode":    api_value},
                ]
            for payload in payload_variants:
                if self.debug and self.logger:
                    self.logger.debug(f"set_fan_mode trying PUT {DRIVE_FAN_CONTROL_PATH} "
                                      f"payload={payload}")
                try:
                    result = self._request("PUT", DRIVE_FAN_CONTROL_PATH, data=payload)
                    if self.debug and self.logger:
                        self.logger.debug(f"set_fan_mode response: {result!r}")
                    # Cache which shape worked
                    self._fan_mode_write_payload_hint = (
                        "profile_apply" if "apply" in payload else "profile_only"
                    )
                    return canonical_mode
                except UnifiAPIError as e:
                    last_error = e
                    if self.debug and self.logger:
                        self.logger.debug(f"set_fan_mode variant failed: {e}")
                    # 404/405 means endpoint not supported at all; abort.
                    msg = str(e)
                    if "HTTP 404" in msg or "HTTP 405" in msg:
                        raise

        raise UnifiAPIError(f"Fan mode set failed for all payload variants: {last_error}")

    # ------------------------------------------------------------------
    # Public API — Power actions
    # ------------------------------------------------------------------

    def reboot(self):
        """Reboot the UNAS appliance."""
        status, body = self._request_raw("POST", DRIVE_REBOOT_PATH)
        if status and (status < 200 or status >= 300):
            raise UnifiAPIError(f"Reboot failed: HTTP {status}: {body}")
        return True

    def shutdown(self):
        """Power off the UNAS appliance."""
        status, body = self._request_raw("POST", DRIVE_POWEROFF_PATH)
        if status and (status < 200 or status >= 300):
            raise UnifiAPIError(f"Shutdown failed: HTTP {status}: {body}")
        return True

    # ------------------------------------------------------------------
    # Public API — Updates
    # ------------------------------------------------------------------

    def get_firmware_update_info(self):
        """Get firmware update status (if available)."""
        try:
            result = self._request("GET", DRIVE_FIRMWARE_UPDATE_PATH)
            if isinstance(result, dict):
                return result.get("data", result)
        except UnifiAPIError:
            return {}
        return {}

    def get_app_update_info(self):
        """Get Drive application update status (if available)."""
        try:
            result = self._request("GET", DRIVE_APP_UPDATE_PATH)
            if isinstance(result, dict):
                return result.get("data", result)
        except UnifiAPIError:
            return {}
        return {}

    # ------------------------------------------------------------------
    # Connectivity test
    # ------------------------------------------------------------------

    def test_connection(self):
        """Test by fetching storage info."""
        return self.get_storage_info()


# ============================================================================
# UniFi Drive SSH client
# ----------------------------------------------------------------------------
# The UniFi REST API for fan control is read-only on current firmware (writes
# return HTTP 500). To actually change fan speeds the plugin SSHs into the
# UNAS and manages a small fan control service deployed there.
#
# Uses paramiko (added to requirements.txt). All operations are best-effort:
# any failure raises UnifiSSHError so the caller can surface it to the user.
# ============================================================================

class UnifiSSHError(Exception):
    """SSH operation failed."""


# Path constants on the UNAS — what we deploy and where.
_SSH_SCRIPT_PATH    = "/usr/local/sbin/indigo_fan_control.sh"
_SSH_SERVICE_PATH   = "/etc/systemd/system/indigo_fan_control.service"
_SSH_CONF_PATH      = "/etc/indigo_fan_control.conf"
_SSH_SERVICE_NAME   = "indigo_fan_control.service"

# Marker file used to detect whether the service has been deployed at all.
_SSH_MARKER_PATH    = "/etc/indigo_fan_control.deployed"


class UnifiDriveSSH:
    """SSH client wrapping paramiko for UNAS fan control management."""

    def __init__(self, host, port, username, password, logger=None, debug=False):
        self.host     = host
        self.port     = int(port) if port else 22
        self.username = username
        self.password = password
        self.logger   = logger
        self.debug    = debug
        self._client  = None
        self._paramiko_import_error = None

        try:
            import paramiko  # noqa: F401
            self._paramiko = paramiko
        except ImportError as e:
            self._paramiko = None
            self._paramiko_import_error = str(e)

    def _ensure_paramiko(self):
        if self._paramiko is None:
            raise UnifiSSHError(
                f"paramiko library not available: {self._paramiko_import_error}. "
                f"The plugin's requirements.txt declares it; ensure Indigo has "
                f"installed plugin dependencies."
            )

    def _connect(self):
        self._ensure_paramiko()
        if self._client is not None:
            # Test it's still alive
            try:
                transport = self._client.get_transport()
                if transport is not None and transport.is_active():
                    return self._client
            except Exception:
                pass
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

        client = self._paramiko.SSHClient()
        client.set_missing_host_key_policy(self._paramiko.AutoAddPolicy())
        try:
            client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=15,
                allow_agent=False,
                look_for_keys=False,
            )
        except Exception as e:
            raise UnifiSSHError(f"SSH connect to {self.host}:{self.port} failed: {e}")
        self._client = client
        return client

    def close(self):
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

    def run(self, command, timeout=30, check=True):
        """Run a shell command on the UNAS. Returns (exit_code, stdout, stderr)."""
        client = self._connect()
        try:
            stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
            exit_code = stdout.channel.recv_exit_status()
            out = stdout.read().decode("utf-8", errors="replace")
            err = stderr.read().decode("utf-8", errors="replace")
            if self.debug and self.logger:
                self.logger.debug(
                    f"SSH `{command}` -> exit={exit_code} "
                    f"stdout={out[:200]!r} stderr={err[:200]!r}"
                )
            if check and exit_code != 0:
                raise UnifiSSHError(
                    f"Command failed (exit {exit_code}): {command}\n"
                    f"stdout: {out.strip()}\nstderr: {err.strip()}"
                )
            return exit_code, out, err
        except UnifiSSHError:
            raise
        except Exception as e:
            raise UnifiSSHError(f"SSH command error: {e}")

    def write_file(self, remote_path, content, mode=0o755):
        """Upload `content` (string) to remote_path on the UNAS using SFTP.
        Sets the given file mode on the remote file."""
        client = self._connect()
        sftp = None
        try:
            sftp = client.open_sftp()
            with sftp.file(remote_path, "wb") as f:
                f.write(content.encode("utf-8") if isinstance(content, str) else content)
            try:
                sftp.chmod(remote_path, mode)
            except Exception:
                pass
            if self.debug and self.logger:
                self.logger.debug(f"SSH wrote {remote_path} ({len(content)} bytes, mode {oct(mode)})")
        except Exception as e:
            raise UnifiSSHError(f"SFTP write to {remote_path} failed: {e}")
        finally:
            if sftp is not None:
                try: sftp.close()
                except Exception: pass

    def remove_file(self, remote_path):
        """Best-effort delete of a remote file. Doesn't raise if missing."""
        try:
            self.run(f"rm -f {remote_path}", check=False)
        except UnifiSSHError:
            pass

    # ------------------------------------------------------------------
    # High-level operations
    # ------------------------------------------------------------------

    def deploy_fan_control(self, script_content, service_content):
        """Install the fan control script and systemd service. Idempotent —
        running again upgrades to the latest script content. Sets initial
        mode to 'default' so behaviour matches pre-deploy until the user
        explicitly chooses a mode."""
        # Upload script and service
        self.write_file(_SSH_SCRIPT_PATH,  script_content,  mode=0o755)
        self.write_file(_SSH_SERVICE_PATH, service_content, mode=0o644)

        # Ensure a conf file exists with a safe default
        conf_check_exit, _, _ = self.run(f"test -f {_SSH_CONF_PATH}", check=False)
        if conf_check_exit != 0:
            self.write_file(_SSH_CONF_PATH, "MODE=default\n", mode=0o644)

        # Drop the deployment marker
        self.write_file(_SSH_MARKER_PATH, "deployed by Indigo UniFi plugin\n", mode=0o644)

        # Reload systemd, enable + restart service
        self.run("systemctl daemon-reload")
        self.run(f"systemctl enable {_SSH_SERVICE_NAME}", check=False)
        self.run(f"systemctl restart {_SSH_SERVICE_NAME}")

    def remove_fan_control(self):
        """Uninstall: stop+disable service, remove all deployed files. After
        this the UNAS firmware's native fan controller takes over again."""
        self.run(f"systemctl stop {_SSH_SERVICE_NAME}", check=False)
        self.run(f"systemctl disable {_SSH_SERVICE_NAME}", check=False)
        self.remove_file(_SSH_SERVICE_PATH)
        self.remove_file(_SSH_SCRIPT_PATH)
        self.remove_file(_SSH_CONF_PATH)
        self.remove_file(_SSH_MARKER_PATH)
        self.run("systemctl daemon-reload", check=False)

    def set_mode(self, mode):
        """Set the active fan control mode. `mode` is one of:
        quiet, balance, cooling, default."""
        mode = (mode or "").strip().lower()
        if mode not in ("quiet", "balance", "cooling", "default"):
            raise UnifiSSHError(f"Unknown fan mode: {mode}")
        self.write_file(_SSH_CONF_PATH, f"MODE={mode}\n", mode=0o644)
        # Restart the service so the change takes effect immediately rather
        # than waiting up to 60s for the next loop iteration.
        self.run(f"systemctl restart {_SSH_SERVICE_NAME}", check=False)

    def is_deployed(self):
        """True if the fan control marker + service file are present."""
        try:
            exit_code, _, _ = self.run(
                f"test -f {_SSH_MARKER_PATH} && test -f {_SSH_SERVICE_PATH}",
                check=False,
            )
            return exit_code == 0
        except UnifiSSHError:
            return False

    def get_active_mode(self):
        """Read the current MODE from the remote conf file. Returns 'default'
        if not deployed or unreadable."""
        try:
            exit_code, out, _ = self.run(
                f"cat {_SSH_CONF_PATH} 2>/dev/null || echo MODE=default",
                check=False,
            )
            for line in (out or "").splitlines():
                line = line.strip()
                if line.startswith("MODE="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'").lower()
                    return val or "default"
            return "default"
        except UnifiSSHError:
            return "default"

    def get_service_status(self):
        """Returns 'active', 'inactive', 'failed', or 'unknown'."""
        try:
            _, out, _ = self.run(
                f"systemctl is-active {_SSH_SERVICE_NAME} 2>/dev/null || echo unknown",
                check=False,
            )
            return (out or "").strip() or "unknown"
        except UnifiSSHError:
            return "unknown"

    def run_diagnostic(self):
        """Run the fan control script once (not as service) to see what
        happens. Returns a multi-line string summarising:
          - one-shot script output (shows PWM writes and current temps)
          - service active state
          - last 30 journal lines for the service
          - current PWM values reported by sysfs
        """
        out_lines = []

        # 1. One-shot script run (logs all PWM writes and read-backs)
        try:
            exit_code, stdout, stderr = self.run(
                f"{_SSH_SCRIPT_PATH} 2>&1", check=False, timeout=30,
            )
            out_lines.append("=== One-shot script output ===")
            out_lines.append(stdout.strip() or "(no output)")
            if stderr.strip():
                out_lines.append(f"stderr: {stderr.strip()}")
            out_lines.append(f"exit code: {exit_code}")
        except UnifiSSHError as e:
            out_lines.append(f"One-shot script run failed: {e}")

        # 2. Service state
        try:
            status = self.get_service_status()
            out_lines.append(f"\n=== Service status: {status} ===")
        except Exception:
            pass

        # 3. Recent journal
        try:
            _, out, _ = self.run(
                f"journalctl -u {_SSH_SERVICE_NAME} -n 30 --no-pager 2>&1 || echo '(journalctl unavailable)'",
                check=False, timeout=15,
            )
            out_lines.append("\n=== Last 30 journal lines ===")
            out_lines.append((out or "(empty)").strip())
        except UnifiSSHError as e:
            out_lines.append(f"Journal fetch failed: {e}")

        # 4. Current PWM values
        try:
            _, out, _ = self.run(
                "for f in /sys/class/hwmon/hwmon0/pwm[1-4]; do "
                "  [ -e \"$f\" ] && echo \"$f = $(cat \"$f\")\"; done",
                check=False, timeout=10,
            )
            out_lines.append("\n=== Current PWM register values ===")
            out_lines.append((out or "(none found)").strip())
        except UnifiSSHError as e:
            out_lines.append(f"PWM read failed: {e}")

        # 5. Current mode in conf
        try:
            _, out, _ = self.run(
                f"cat {_SSH_CONF_PATH} 2>/dev/null || echo '(no conf file)'",
                check=False, timeout=5,
            )
            out_lines.append(f"\n=== Conf file ===")
            out_lines.append((out or "").strip())
        except UnifiSSHError:
            pass

        return "\n".join(out_lines)


# ============================================================================
# WebSocket client
# ----------------------------------------------------------------------------
# Lightweight raw WebSocket client (no external deps, plain urllib + ssl
# socket). Supports cookie auth (Network legacy WS) and Bearer auth (Protect
# integration / Access developer WS). Exponential backoff on reconnect.
# ============================================================================

class UnifiWebSocket:
    """Minimal WebSocket client with auto-reconnect and exponential backoff."""

    def __init__(self, host, port, ws_path, ssl_context, on_message, logger,
                 cookies=None, bearer_token=None, api_key=None, debug=False, label="ws"):
        self.host         = host
        self.port         = int(port)
        self.ws_path      = ws_path
        self.ssl_context  = ssl_context
        self.on_message   = on_message
        self.logger       = logger
        self.cookies      = cookies          # CookieJar or None
        self.bearer_token = bearer_token     # str or None - sets Authorization: Bearer
        self.api_key      = api_key          # str or None - sets X-API-KEY header
        self.debug        = debug
        self.label        = label

        self.thread       = None
        self.stop_flag    = False
        self.connected    = False
        self._backoff     = WS_RECONNECT_INITIAL_SEC

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self):
        self.stop_flag = False
        self.thread    = threading.Thread(target=self._loop, daemon=True,
                                          name=f"unifi-ws-{self.label}")
        self.thread.start()

    def stop(self):
        self.stop_flag = True
        if self.thread:
            self.thread.join(timeout=5)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def _loop(self):
        while not self.stop_flag:
            sock = None
            try:
                sock = self._connect_and_handshake()
                self.connected = True
                self._backoff  = WS_RECONNECT_INITIAL_SEC  # reset on success

                if self.debug:
                    self.logger.debug(f"[{self.label}] WebSocket connected")

                self._read_frames(sock)
            except _PermanentWSFailure as e:
                # Service not available / 502 / 503 - stop trying
                if self.debug:
                    self.logger.debug(f"[{self.label}] WebSocket permanently unavailable: {e}")
                self.stop_flag = True
                break
            except Exception as e:
                if not self.stop_flag:
                    if self.debug:
                        self.logger.debug(f"[{self.label}] WebSocket error: {e}")
            finally:
                self.connected = False
                if sock is not None:
                    try:
                        sock.close()
                    except Exception:
                        pass

            if self.stop_flag:
                break

            # Exponential backoff
            time.sleep(self._backoff)
            self._backoff = min(self._backoff * WS_RECONNECT_BACKOFF_FACTOR,
                                WS_RECONNECT_MAX_SEC)

    # ------------------------------------------------------------------
    # Connection / handshake
    # ------------------------------------------------------------------

    def _connect_and_handshake(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        wrapped = self.ssl_context.wrap_socket(sock, server_hostname=self.host)
        wrapped.connect((self.host, self.port))

        ws_key = base64.b64encode(os.urandom(16)).decode("ascii")

        request_lines = [
            f"GET {self.ws_path} HTTP/1.1",
            f"Host: {self.host}:{self.port}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {ws_key}",
            "Sec-WebSocket-Version: 13",
            f"Origin: https://{self.host}:{self.port}",
        ]
        if self.bearer_token:
            request_lines.append(f"Authorization: Bearer {self.bearer_token}")
        if self.api_key:
            request_lines.append(f"X-API-KEY: {self.api_key}")
        if self.cookies is not None:
            cookie_header = "; ".join(f"{c.name}={c.value}" for c in self.cookies)
            if cookie_header:
                request_lines.append(f"Cookie: {cookie_header}")

        request = ("\r\n".join(request_lines) + "\r\n\r\n").encode("ascii")
        wrapped.send(request)

        # Read upgrade response
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = wrapped.recv(1024)
            if not chunk:
                raise UnifiAPIError("WebSocket: connection closed during handshake")
            buf += chunk
            if len(buf) > 16384:
                raise UnifiAPIError("WebSocket: handshake response too large")

        status_line = buf.split(b"\r\n", 1)[0].decode("ascii", errors="replace")
        if " 101 " not in status_line and not status_line.endswith(" 101"):
            # Specific permanent failures
            if "502" in status_line or "503" in status_line or "404" in status_line:
                raise _PermanentWSFailure(status_line)
            if "401" in status_line or "403" in status_line:
                raise _PermanentWSFailure(f"auth rejected ({status_line})")
            raise UnifiAPIError(f"WebSocket handshake failed: {status_line}")

        # Switch to longer timeout for steady-state reads
        wrapped.settimeout(60)
        return wrapped

    # ------------------------------------------------------------------
    # Frame reading
    # ------------------------------------------------------------------

    def _read_frames(self, sock):
        while not self.stop_flag:
            try:
                payload, opcode = self._read_frame(sock)
            except socket.timeout:
                # Send ping to keep alive
                self._send_ping(sock)
                continue
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"[{self.label}] frame read error: {e}")
                return

            if payload is None:
                # Close frame
                return

            if opcode == 0x9:   # ping -> pong
                self._send_pong(sock, payload)
                continue
            if opcode == 0xA:   # pong -> ignore
                continue
            if opcode not in (0x1, 0x2):  # only text/binary carry data
                continue

            try:
                text = payload.decode("utf-8")
                msg  = json.loads(text)
            except (UnicodeDecodeError, json.JSONDecodeError):
                # Not JSON - skip
                continue

            try:
                self.on_message(msg)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"[{self.label}] callback error: {e}")

    def _read_frame(self, sock):
        header = self._recv_exact(sock, 2)
        if header is None:
            return None, 0x8

        b1, b2 = header[0], header[1]
        opcode = b1 & 0x0F
        masked = (b2 & 0x80) != 0
        plen   = b2 & 0x7F

        if plen == 126:
            ext = self._recv_exact(sock, 2)
            plen = struct.unpack(">H", ext)[0]
        elif plen == 127:
            ext = self._recv_exact(sock, 8)
            plen = struct.unpack(">Q", ext)[0]

        mask_key = self._recv_exact(sock, 4) if masked else None

        payload = b""
        if plen > 0:
            payload = self._recv_exact(sock, plen) or b""
            if masked and mask_key:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

        if opcode == 0x8:
            return None, 0x8
        return payload, opcode

    def _recv_exact(self, sock, n):
        buf = b""
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return buf

    def _send_ping(self, sock):
        try:
            sock.send(struct.pack("BB", 0x89, 0))
        except Exception:
            pass

    def _send_pong(self, sock, payload):
        try:
            length = len(payload) if payload else 0
            if length < 126:
                header = struct.pack("BB", 0x8A, length)
            elif length <= 0xFFFF:
                header = struct.pack("BBH", 0x8A, 126, length)
            else:
                header = struct.pack("BBQ", 0x8A, 127, length)
            sock.send(header + (payload or b""))
        except Exception:
            pass


class _PermanentWSFailure(Exception):
    """Raised internally when WebSocket should stop trying to reconnect."""


# ============================================================================
# Plugin class
# ============================================================================

class Plugin(indigo.PluginBase):

    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        super(Plugin, self).__init__(pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
        self.debug             = pluginPrefs.get("showDebugInfo", False)

        # Per-controller state. See controllers dict structure below.
        self.controllers       = {}

        # Track deleted client MACs to prevent auto-recreation
        self.deleted_clients   = set(pluginPrefs.get("deletedClients", []))

        self.polling_thread    = None
        self.stop_polling      = False

        # Load embedded fan control assets that the plugin deploys to UNAS
        # over SSH. These ship inside the plugin bundle, next to plugin.py.
        plugin_dir = self._find_plugin_dir()
        self.fan_script_content  = self._load_asset(plugin_dir, "indigo_fan_control.sh")
        self.fan_service_content = self._load_asset(plugin_dir, "indigo_fan_control.service")

    def _find_plugin_dir(self):
        """Locate the directory that contains plugin.py and the bundled assets.

        Indigo's plugin host loads plugin.py via exec() so `__file__` is NOT
        defined in the module's globals. We fall back to multiple strategies:
          1. `__file__` (if a future Indigo sets it)
          2. CWD (Indigo sets working directory to the Server Plugin folder)
          3. Standard Indigo plugin install location
        """
        # Strategy 1: __file__ if defined
        try:
            return os.path.dirname(os.path.abspath(__file__))  # noqa: F821
        except NameError:
            pass

        # Strategy 2: current working directory
        cwd = os.getcwd()
        if os.path.exists(os.path.join(cwd, "indigo_fan_control.sh")):
            return cwd

        # Strategy 3: standard Indigo install path for this plugin
        try:
            plugin_id = self.pluginId  # e.g. "com.durosity.indigoplugin.unifi"
        except Exception:
            plugin_id = "com.durosity.indigoplugin.unifi"
        # Indigo plugins live at:
        #   /Library/Application Support/Perceptive Automation/Indigo <ver>/Plugins/<Name>.indigoPlugin/Contents/Server Plugin/
        candidates = [
            f"/Library/Application Support/Perceptive Automation/Indigo 2025.2/Plugins/UniFi.indigoPlugin/Contents/Server Plugin",
            f"/Library/Application Support/Perceptive Automation/Indigo 2024.2/Plugins/UniFi.indigoPlugin/Contents/Server Plugin",
            f"/Library/Application Support/Perceptive Automation/Indigo 2024.1/Plugins/UniFi.indigoPlugin/Contents/Server Plugin",
            f"/Library/Application Support/Perceptive Automation/Indigo 2023.2/Plugins/UniFi.indigoPlugin/Contents/Server Plugin",
            f"/Library/Application Support/Perceptive Automation/Indigo 2022.2/Plugins/UniFi.indigoPlugin/Contents/Server Plugin",
        ]
        for c in candidates:
            if os.path.exists(os.path.join(c, "indigo_fan_control.sh")):
                return c

        # Last resort — return CWD even though we couldn't verify
        return cwd

    def _load_asset(self, plugin_dir, filename):
        """Load a bundled asset file. Returns empty string on failure."""
        try:
            with open(os.path.join(plugin_dir, filename), "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            # Don't crash plugin startup over an asset issue — log and continue.
            try:
                self.logger.error(f"Could not load asset {filename}: {e}")
            except Exception:
                pass
            return ""

    # ------------------------------------------------------------------
    # Plugin lifecycle
    # ------------------------------------------------------------------

    def startup(self):
        self.logger.info(f"Starting UniFi Plugin v{PLUGIN_VERSION}")
        self.stop_polling   = False
        self.polling_thread = threading.Thread(target=self._polling_loop, daemon=True,
                                               name="unifi-poll")
        self.polling_thread.start()

    def shutdown(self):
        self.logger.info("Shutting down UniFi Plugin")
        self.stop_polling = True
        if self.polling_thread:
            self.polling_thread.join(timeout=5)

        for controller_id in list(self.controllers.keys()):
            self._stop_controller(controller_id)
        self.controllers.clear()

    def closedPrefsConfigUi(self, valuesDict, userCancelled):
        if userCancelled:
            return True
        self.debug = valuesDict.get("showDebugInfo", False)
        self.logger.info(f"Debug mode: {'enabled' if self.debug else 'disabled'}")
        return True

    # ------------------------------------------------------------------
    # Trigger plumbing
    # ------------------------------------------------------------------

    def triggerStartProcessing(self, trigger):
        if self.debug:
            self.logger.debug(f"Trigger started: {trigger.name} ({trigger.pluginTypeId})")

    def triggerStopProcessing(self, trigger):
        if self.debug:
            self.logger.debug(f"Trigger stopped: {trigger.name}")

    def _fire_trigger(self, event_id, device):
        """Fire any user triggers matching this event/device combination."""
        for trigger in indigo.triggers.iter("self"):
            if trigger.pluginTypeId != event_id:
                continue
            # Support both 'device' and 'deviceId' field names for compatibility
            device_filter = trigger.pluginProps.get("device", "") or \
                            trigger.pluginProps.get("deviceId", "")
            # Empty = "Any device"
            if device_filter == "" or device_filter == str(device.id):
                if self.debug:
                    self.logger.debug(f"Firing trigger '{trigger.name}' for {device.name}")
                indigo.trigger.execute(trigger)

    # ------------------------------------------------------------------
    # Device lifecycle
    # ------------------------------------------------------------------

    def deviceStartComm(self, dev):
        type_id = dev.deviceTypeId
        if type_id == "unifiController":
            self._start_controller(dev)
        elif type_id == "unifiDriveController":
            self._start_drive_controller(dev)
        elif type_id == "protectCamera":
            self._setup_camera_link(dev)
        elif type_id == "protectSensor":
            self._setup_sensor_link(dev)
        elif type_id == "networkDevice":
            self._setup_netdev_link(dev)
        elif type_id == "unifiPort":
            self._setup_port_link(dev)
        elif type_id == "clientDevice":
            self._setup_client_link(dev)
        elif type_id == "accessDoor":
            self._setup_door_link(dev)
        elif type_id == "driveFan":
            self._setup_fan_link(dev)
        elif type_id == "unifiDrivePool":
            self._setup_pool_link(dev)
        elif type_id == "unifiDriveDisk":
            self._setup_disk_link(dev)

    def deviceStopComm(self, dev):
        if dev.deviceTypeId in ("unifiController", "unifiDriveController"):
            self._stop_controller(dev.id)

    # ------------------------------------------------------------------
    # Controller start / stop
    # ------------------------------------------------------------------

    def _start_controller(self, dev):
        """Initialize a controller from its config."""
        try:
            address     = dev.pluginProps.get("address", "").strip()
            port        = int(dev.pluginProps.get("port", DEFAULT_HTTPS_PORT) or DEFAULT_HTTPS_PORT)
            access_port = int(dev.pluginProps.get("accessPort", DEFAULT_ACCESS_PORT) or DEFAULT_ACCESS_PORT)
            verify_ssl  = bool(dev.pluginProps.get("verifySSL", False))
            site        = dev.pluginProps.get("site", "default") or "default"

            # Auth credentials
            network_api_key = dev.pluginProps.get("networkApiKey", "").strip()
            # Network and Protect share one API key via the unified Integrations
            # page (Settings → Control Plane → Integrations) with X-API-KEY auth.
            protect_api_key = network_api_key
            # Access has a SEPARATE token, generated inside the UniFi Access app
            # (not the unified Integrations page). It uses Bearer auth on port 12445.
            access_api_key  = dev.pluginProps.get("accessApiKey", "").strip()
            legacy_user     = dev.pluginProps.get("legacyUsername", "").strip()
            legacy_pass     = dev.pluginProps.get("legacyPassword", "")

            # Feature toggles
            enable_network = bool(dev.pluginProps.get("enableNetwork", True))
            enable_protect = bool(dev.pluginProps.get("enableProtect", True))
            enable_access  = bool(dev.pluginProps.get("enableAccess",  False))

            # Polling settings
            aggressive    = bool(dev.pluginProps.get("aggressivePolling", False))
            try:
                stats_interval = int(dev.pluginProps.get("statsIntervalSec", DEFAULT_STATS_INTERVAL_SEC))
            except (TypeError, ValueError):
                stats_interval = DEFAULT_STATS_INTERVAL_SEC
            try:
                sanity_interval = int(dev.pluginProps.get("sanityIntervalSec", DEFAULT_SANITY_INTERVAL_SEC))
            except (TypeError, ValueError):
                sanity_interval = DEFAULT_SANITY_INTERVAL_SEC

            if not address:
                self.logger.error(f"{dev.name}: Controller address is empty")
                dev.updateStateOnServer("status", "Error: Missing address")
                dev.updateStateOnServer("connected", False)
                return

            self.logger.info(f"{dev.name}: Connecting to {address}:{port}")

            controller = {
                "device":               dev,
                "address":              address,
                "port":                 port,
                "access_port":          access_port,
                "site":                 site,
                "cameras":              {},
                "sensors":              {},
                "lights":               {},
                "chimes":               {},
                "network_devices":      {},
                "ports":                {},
                "clients":              {},
                "doors":                {},
                "fan_device":           None,
                "stats_interval_sec":   max(60, stats_interval),
                "sanity_interval_sec":  max(0,  sanity_interval),  # 0 = off
                "aggressive":           aggressive,
                "last_stats_at":        0,
                "last_sanity_at":       0,
                "websockets":           [],
            }

            # ---- Network API ----
            if enable_network:
                net_api = UnifiNetworkAPI(
                    address, port, network_api_key,
                    legacy_user, legacy_pass, site=site,
                    verify_ssl=verify_ssl, logger=self.logger, debug=self.debug,
                )
                controller["network_api"] = net_api

                # Try integration first, fall back to legacy if no API key
                tried = []
                if network_api_key:
                    try:
                        net_api.test_integration()
                        self.logger.info(f"{dev.name}: Network Integration API OK")
                    except UnifiAuthError as e:
                        self.logger.warning(f"{dev.name}: Network Integration API key invalid: {e}")
                        tried.append("integration")
                    except UnifiAPIError as e:
                        self.logger.warning(f"{dev.name}: Network Integration API unavailable: {e}")
                        tried.append("integration")

                if legacy_user and legacy_pass:
                    try:
                        net_api.test_legacy()
                        self.logger.info(f"{dev.name}: Network legacy auth OK")
                    except UnifiAuthError as e:
                        self.logger.error(f"{dev.name}: Network legacy auth failed: {e}")
                    except UnifiAPIError as e:
                        self.logger.warning(f"{dev.name}: Network legacy auth unavailable: {e}")

                # Network WebSocket (legacy events stream) - real-time client/device updates
                if legacy_user and legacy_pass:
                    try:
                        ws = UnifiWebSocket(
                            host=address, port=port,
                            ws_path=f"/proxy/network/wss/s/{site}/events",
                            ssl_context=net_api.ssl_context,
                            on_message=lambda msg, cid=dev.id: self._on_network_ws(cid, msg),
                            logger=self.logger,
                            cookies=net_api.legacy_cookies,
                            bearer_token=None,
                            debug=self.debug,
                            label=f"{dev.name}-net",
                        )
                        ws.start()
                        controller["websockets"].append(ws)
                    except Exception as e:
                        self.logger.warning(f"{dev.name}: Network WebSocket failed: {e}")

            # ---- Protect API ----
            if enable_protect and protect_api_key:
                try:
                    protect_api = UnifiProtectAPI(
                        address, port, protect_api_key,
                        verify_ssl=verify_ssl, logger=self.logger, debug=self.debug,
                    )
                    protect_api.test_connection()
                    protect_api.refresh_cache()
                    controller["protect_api"] = protect_api
                    self.logger.info(f"{dev.name}: Protect Integration API OK "
                                     f"({len(protect_api.get_cameras())} cameras, "
                                     f"{len(protect_api.get_sensors())} sensors)")

                    # Subscribe to device updates and events streams
                    for ws_path, handler, label in [
                        (UnifiProtectAPI.WS_DEVICES, self._on_protect_devices_ws, "protect-devices"),
                        (UnifiProtectAPI.WS_EVENTS,  self._on_protect_events_ws,  "protect-events"),
                    ]:
                        ws = UnifiWebSocket(
                            host=address, port=port,
                            ws_path=ws_path,
                            ssl_context=protect_api.ssl_context,
                            on_message=lambda msg, cid=dev.id, h=handler: h(cid, msg),
                            logger=self.logger,
                            cookies=None,
                            api_key=protect_api_key,
                            debug=self.debug,
                            label=f"{dev.name}-{label}",
                        )
                        ws.start()
                        controller["websockets"].append(ws)
                except UnifiAuthError as e:
                    self.logger.error(f"{dev.name}: Protect API auth failed: {e}")
                except UnifiAPIError as e:
                    self.logger.warning(f"{dev.name}: Protect API unavailable: {e}")
            elif enable_protect:
                self.logger.warning(f"{dev.name}: Protect enabled but no API key configured")

            # ---- Access API ----
            # Access has a separate API server on its own port (12445), using a
            # separate API token generated from inside the UniFi Access app.
            if enable_access and access_api_key:
                try:
                    access_api = UnifiAccessAPI(
                        address, access_port, access_api_key,
                        verify_ssl=verify_ssl, logger=self.logger, debug=self.debug,
                    )
                    access_api.test_connection()
                    controller["access_api"] = access_api
                    self.logger.info(f"{dev.name}: Access Developer API OK")

                    # Subscribe to door notifications.
                    ws = UnifiWebSocket(
                        host=address, port=access_port,
                        ws_path="/api/v1/developer/devices/notifications",
                        ssl_context=access_api.ssl_context,
                        on_message=lambda msg, cid=dev.id: self._on_access_ws(cid, msg),
                        logger=self.logger,
                        cookies=None,
                        bearer_token=access_api_key,
                        debug=self.debug,
                        label=f"{dev.name}-access",
                    )
                    ws.start()
                    controller["websockets"].append(ws)
                except UnifiAuthError as e:
                    self.logger.error(f"{dev.name}: Access API auth failed: {e}")
                except UnifiAPIError as e:
                    self.logger.warning(f"{dev.name}: Access API unavailable: {e}")
            elif enable_access:
                self.logger.warning(f"{dev.name}: Access enabled but no API key configured")

            # NOTE: Drive (UNAS) is now handled by a separate device type,
            # unifiDriveController, since UNAS is a separate appliance with
            # its own IP and credentials. See _start_drive_controller().

            self.controllers[dev.id] = controller
            dev.updateStateOnServer("status", "Connected")
            dev.updateStateOnServer("connected", True)

            # Trigger initial state population
            controller["last_stats_at"]  = 0
            controller["last_sanity_at"] = 0

            # Set up any devices that were waiting for this controller
            self._setup_waiting_devices(dev.id)
            self.logger.info(f"{dev.name}: Connected")

        except Exception as e:
            self.logger.error(f"{dev.name}: Connection error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            dev.updateStateOnServer("status", f"Error: {e}")
            dev.updateStateOnServer("connected", False)

    def _stop_controller(self, controller_id):
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        for ws in controller.get("websockets", []):
            try:
                ws.stop()
            except Exception:
                pass
        ssh = controller.get("drive_ssh")
        if ssh is not None:
            try:
                ssh.close()
            except Exception:
                pass
        dev = controller["device"]
        try:
            dev.updateStateOnServer("status", "Disconnected")
            dev.updateStateOnServer("connected", False)
        except Exception:
            pass
        self.controllers.pop(controller_id, None)
        self.logger.info(f"{dev.name}: Disconnected")

    # ------------------------------------------------------------------
    # Drive controller start (separate device type, separate IP)
    # ------------------------------------------------------------------

    def _start_drive_controller(self, dev):
        """Initialize a standalone UNAS controller."""
        try:
            address     = dev.pluginProps.get("address", "").strip()
            try:
                port = int(dev.pluginProps.get("port", DEFAULT_HTTPS_PORT) or DEFAULT_HTTPS_PORT)
            except (TypeError, ValueError):
                port = DEFAULT_HTTPS_PORT
            verify_ssl  = bool(dev.pluginProps.get("verifySSL", False))

            api_key     = dev.pluginProps.get("driveApiKey", "").strip()
            legacy_user = dev.pluginProps.get("legacyUsername", "").strip()
            legacy_pass = dev.pluginProps.get("legacyPassword", "")

            try:
                stats_interval = int(dev.pluginProps.get("statsIntervalSec", DEFAULT_STATS_INTERVAL_SEC))
            except (TypeError, ValueError):
                stats_interval = DEFAULT_STATS_INTERVAL_SEC

            if not address:
                self.logger.error(f"{dev.name}: UNAS address is empty")
                dev.updateStateOnServer("status", "Error: Missing address")
                dev.updateStateOnServer("connected", False)
                return

            if not api_key and not (legacy_user and legacy_pass):
                self.logger.error(f"{dev.name}: Either API key or username/password is required")
                dev.updateStateOnServer("status", "Error: Missing credentials")
                dev.updateStateOnServer("connected", False)
                return

            self.logger.info(f"{dev.name}: Connecting to UNAS at {address}:{port}")

            controller = {
                "device":               dev,
                "address":              address,
                "port":                 port,
                "fan_device":           None,
                "stats_interval_sec":   max(60, stats_interval),
                "sanity_interval_sec":  0,
                "aggressive":           False,
                "last_stats_at":        0,
                "last_sanity_at":       0,
                "websockets":           [],
                # Empty maps so polling/setup code can iterate without checks
                "cameras":              {},
                "sensors":              {},
                "lights":               {},
                "chimes":               {},
                "network_devices":      {},
                "ports":                {},
                "clients":              {},
                "doors":                {},
                "is_drive_controller":  True,
            }

            try:
                drive_api = UnifiDriveAPI(
                    address, port, api_key=api_key,
                    username=legacy_user, password=legacy_pass,
                    verify_ssl=verify_ssl,
                    logger=self.logger, debug=self.debug,
                )
                drive_api.test_connection()
                controller["drive_api"] = drive_api
                auth_label = "API key" if api_key else "legacy auth"
                self.logger.info(f"{dev.name}: UNAS OK ({auth_label})")
            except UnifiAuthError as e:
                self.logger.error(f"{dev.name}: UNAS auth failed: {e}")
                dev.updateStateOnServer("status", "Error: Auth failed")
                dev.updateStateOnServer("connected", False)
                return
            except UnifiAPIError as e:
                self.logger.error(f"{dev.name}: UNAS unavailable: {e}")
                dev.updateStateOnServer("status", "Error: Unavailable")
                dev.updateStateOnServer("connected", False)
                return

            self.controllers[dev.id] = controller
            dev.updateStateOnServer("status", "Connected")
            dev.updateStateOnServer("connected", True)

            # Set up SSH client for fan control (if enabled in config)
            ssh_enabled  = bool(dev.pluginProps.get("sshEnabled", False))
            ssh_user     = (dev.pluginProps.get("sshUsername", "") or "").strip()
            ssh_pass     = dev.pluginProps.get("sshPassword", "") or ""
            try:
                ssh_port = int(dev.pluginProps.get("sshPort", "22") or "22")
            except (TypeError, ValueError):
                ssh_port = 22
            if ssh_enabled and ssh_user and ssh_pass:
                ssh = UnifiDriveSSH(
                    address, ssh_port, ssh_user, ssh_pass,
                    logger=self.logger, debug=self.debug,
                )
                controller["drive_ssh"] = ssh
                # Don't try to connect yet — we'll lazy-connect when needed.
                if self.debug:
                    self.logger.debug(f"{dev.name}: SSH helper configured for {ssh_user}@{address}:{ssh_port}")
            else:
                controller["drive_ssh"] = None
                if ssh_enabled:
                    self.logger.warning(
                        f"{dev.name}: SSH fan control enabled but username/password missing — "
                        f"fan write actions will return an error."
                    )

            # Trigger initial polling
            controller["last_stats_at"]  = 0
            controller["last_sanity_at"] = 0

            # Set up any Drive child devices waiting on this controller
            self._setup_waiting_devices(dev.id)

            # Do an immediate state refresh so the controller (and any
            # already-existing child devices) get populated right away rather
            # than waiting for the next poll tick.
            try:
                self._update_drive_states(dev.id)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"Initial drive state refresh failed: {e}")

            self.logger.info(f"{dev.name}: Connected")

        except Exception as e:
            self.logger.error(f"{dev.name}: UNAS connection error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            try:
                dev.updateStateOnServer("status", f"Error: {e}")
                dev.updateStateOnServer("connected", False)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Setup waiting devices (any device whose controller wasn't ready)
    # ------------------------------------------------------------------

    def _setup_waiting_devices(self, controller_id):
        for dev in indigo.devices.iter("self"):
            try:
                cid = int(dev.pluginProps.get("controllerId", 0))
            except (ValueError, TypeError):
                continue
            if cid != controller_id:
                continue
            type_id = dev.deviceTypeId
            if type_id == "protectCamera":
                self._setup_camera_link(dev)
            elif type_id == "protectSensor":
                self._setup_sensor_link(dev)
            elif type_id == "networkDevice":
                self._setup_netdev_link(dev)
            elif type_id == "unifiPort":
                self._setup_port_link(dev)
            elif type_id == "clientDevice":
                self._setup_client_link(dev)
            elif type_id == "accessDoor":
                self._setup_door_link(dev)
            elif type_id == "driveFan":
                self._setup_fan_link(dev)
            elif type_id == "unifiDrivePool":
                self._setup_pool_link(dev)
            elif type_id == "unifiDriveDisk":
                self._setup_disk_link(dev)

    def _get_controller(self, dev):
        """Return (controller_id, controller_dict) or (None, None)."""
        try:
            cid = int(dev.pluginProps.get("controllerId", 0))
        except (ValueError, TypeError):
            return None, None
        return cid, self.controllers.get(cid)

    # ------------------------------------------------------------------
    # Per-device link setup
    # ------------------------------------------------------------------

    def _setup_camera_link(self, dev):
        cid, controller = self._get_controller(dev)
        camera_id = dev.pluginProps.get("cameraId", "")
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "protect_api" not in controller:
            dev.updateStateOnServer("status", "Error: Protect not enabled")
            return
        if not camera_id:
            dev.updateStateOnServer("status", "Error: Missing camera ID")
            return
        controller["cameras"][camera_id] = dev.id
        self._update_camera_states(cid, camera_id)

    def _setup_sensor_link(self, dev):
        cid, controller = self._get_controller(dev)
        sensor_id = dev.pluginProps.get("sensorId", "")
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "protect_api" not in controller:
            dev.updateStateOnServer("status", "Error: Protect not enabled")
            return
        if not sensor_id:
            dev.updateStateOnServer("status", "Error: Missing sensor ID")
            return
        controller["sensors"][sensor_id] = dev.id
        self._update_sensor_states(cid, sensor_id)

    def _setup_netdev_link(self, dev):
        cid, controller = self._get_controller(dev)
        mac = dev.pluginProps.get("deviceMac", "").lower()
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "network_api" not in controller:
            dev.updateStateOnServer("status", "Error: Network not enabled")
            return
        if not mac:
            dev.updateStateOnServer("status", "Error: Missing MAC")
            return
        controller["network_devices"][mac] = dev.id
        self._update_netdev_states(cid, mac)

    def _setup_port_link(self, dev):
        cid, controller = self._get_controller(dev)
        mac = dev.pluginProps.get("deviceMac", "").lower()
        try:
            port_num = int(dev.pluginProps.get("portNumber", 0))
        except (TypeError, ValueError):
            port_num = 0
        if not controller:
            dev.updateStateOnServer("portName", "Waiting for controller")
            return
        if "network_api" not in controller:
            dev.updateStateOnServer("portName", "Error: Network not enabled")
            return
        if not mac or port_num <= 0:
            dev.updateStateOnServer("portName", "Error: Missing config")
            return
        controller["ports"][f"{mac}:{port_num}"] = dev.id
        self._update_port_states(cid, mac, port_num)

    def _setup_client_link(self, dev):
        cid, controller = self._get_controller(dev)
        mac = dev.pluginProps.get("clientMac", "").lower()
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "network_api" not in controller:
            dev.updateStateOnServer("status", "Error: Network not enabled")
            return
        if not mac:
            dev.updateStateOnServer("status", "Error: Missing MAC")
            return
        controller["clients"][mac] = dev.id
        self._update_client_states(cid, mac)

    def _setup_door_link(self, dev):
        cid, controller = self._get_controller(dev)
        door_id = dev.pluginProps.get("doorId", "")
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "access_api" not in controller:
            dev.updateStateOnServer("status", "Error: Access not enabled")
            return
        if not door_id:
            dev.updateStateOnServer("status", "Error: Missing door ID")
            return
        controller["doors"][door_id] = dev.id
        self._update_door_states(cid, door_id)

    def _setup_fan_link(self, dev):
        cid, controller = self._get_controller(dev)
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "drive_api" not in controller:
            dev.updateStateOnServer("status", "Error: Drive not enabled")
            return
        controller["fan_device"] = dev.id
        self._update_fan_states(cid)

    def _setup_pool_link(self, dev):
        cid, controller = self._get_controller(dev)
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "drive_api" not in controller:
            dev.updateStateOnServer("status", "Error: Drive not enabled")
            return
        controller.setdefault("pool_devices", {})
        key = dev.pluginProps.get("poolKey", "")
        if not key:
            dev.updateStateOnServer("status", "Error: Missing pool key")
            return
        controller["pool_devices"][key] = dev.id
        self._update_pool_states(cid, key)

    def _setup_disk_link(self, dev):
        cid, controller = self._get_controller(dev)
        if not controller:
            dev.updateStateOnServer("status", "Waiting for controller")
            return
        if "drive_api" not in controller:
            dev.updateStateOnServer("status", "Error: Drive not enabled")
            return
        controller.setdefault("disk_devices", {})
        key = dev.pluginProps.get("diskKey", "")
        if not key:
            dev.updateStateOnServer("status", "Error: Missing disk key")
            return
        controller["disk_devices"][key] = dev.id
        self._update_disk_states(cid, key)

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    def _polling_loop(self):
        """Tiered polling: stats interval (CPU/mem/temp), sanity interval (full re-sync)."""
        while not self.stop_polling:
            try:
                now = time.time()
                for cid in list(self.controllers.keys()):
                    try:
                        self._poll_controller(cid, now)
                    except Exception as e:
                        self.logger.error(f"Polling error on controller {cid}: {e}")
                        if self.debug:
                            self.logger.error(traceback.format_exc())
            except Exception as e:
                self.logger.error(f"Polling loop error: {e}")
            time.sleep(5)  # outer tick is cheap; the per-controller intervals gate the work

    def _poll_controller(self, controller_id, now):
        controller = self.controllers.get(controller_id)
        if not controller:
            return

        # Aggressive mode short-circuits both intervals to AGGRESSIVE_INTERVAL_SEC
        if controller.get("aggressive"):
            stats_iv  = AGGRESSIVE_INTERVAL_SEC
            sanity_iv = AGGRESSIVE_INTERVAL_SEC
        else:
            stats_iv  = controller["stats_interval_sec"]
            sanity_iv = controller["sanity_interval_sec"]

        do_stats  = (now - controller["last_stats_at"])  >= stats_iv  if stats_iv  > 0 else False
        do_sanity = (now - controller["last_sanity_at"]) >= sanity_iv if sanity_iv > 0 else False

        if do_sanity:
            controller["last_sanity_at"] = now
            self._sanity_resync(controller_id)

        if do_stats:
            controller["last_stats_at"] = now
            self._refresh_stats(controller_id)

    def _refresh_stats(self, controller_id):
        """Refresh only the slow-changing stats data (CPU, memory, throughput, drive)."""
        controller = self.controllers[controller_id]

        # Network device stats - we re-fetch the full device list since legacy
        # bundles all stats together
        if "network_api" in controller:
            try:
                # Single call refreshes data; per-device updates pull from cache
                # but we want fresh data so we just call _update_netdev_states which
                # internally calls get_device which does a fresh fetch
                # Optimization: fetch list once, distribute
                devices = controller["network_api"].get_devices()
                by_mac  = {d.get("mac", "").lower(): d for d in devices}
                for mac, dev_id in list(controller["network_devices"].items()):
                    if mac in by_mac:
                        self._apply_netdev_state(controller_id, mac, by_mac[mac])
                # Ports rely on the same fetch
                for port_key, dev_id in list(controller["ports"].items()):
                    try:
                        mac, port_num = port_key.split(":")
                        if mac in by_mac:
                            self._apply_port_state(controller_id, mac, int(port_num), by_mac[mac])
                    except Exception:
                        pass
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"Network stats refresh error: {e}")

        # Drive stats - always poll when API is connected, since the controller
        # device itself surfaces useful at-a-glance fields even if no child
        # pool/disk devices have been created yet.
        if "drive_api" in controller:
            try:
                self._update_drive_states(controller_id)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"Drive stats refresh error: {e}")
            if controller.get("fan_device"):
                try:
                    self._update_fan_states(controller_id)
                except Exception as e:
                    if self.debug:
                        self.logger.debug(f"Fan stats refresh error: {e}")
            # Daily check: if fan control was deployed but its marker file is
            # now missing (UniFi OS update wiped /etc), silently redeploy.
            # Triggered only when the user has opted in via the controller
            # config tickbox (default on).
            try:
                self._check_fan_control_deployment(controller_id)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"Fan control deployment check error: {e}")

        # Protect: cameras have a lot of stats (recording/bitrate/voltage). WebSocket
        # handles motion/smart events; this just keeps the slow stats fresh.
        if "protect_api" in controller:
            try:
                controller["protect_api"].refresh_cache()
                for camera_id in list(controller["cameras"].keys()):
                    self._update_camera_states(controller_id, camera_id, refresh=False)
                for sensor_id in list(controller["sensors"].keys()):
                    self._update_sensor_states(controller_id, sensor_id, refresh=False)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"Protect stats refresh error: {e}")

    def _sanity_resync(self, controller_id):
        """Fully re-sync state in case WebSocket dropped messages.
        Currently performs the same work as stats refresh; kept as a separate
        method so we can later add deeper checks (auto-rediscover new devices, etc)."""
        if self.debug:
            self.logger.debug(f"Sanity re-sync for controller {controller_id}")
        self._refresh_stats(controller_id)

        # Update controller-level states
        try:
            self._update_controller_states(controller_id)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Controller state refresh error: {e}")

    def _update_controller_states(self, controller_id):
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        dev = controller["device"]

        # Only write states that are actually declared on the unifiController
        # device type. Add new ones to Devices.xml before writing them here.
        declared_states = set(dev.states.keys())
        states = []

        if "protect_api" in controller:
            try:
                nvr = controller["protect_api"].get_nvr() or {}
                if nvr:
                    if "protectVersion" in declared_states:
                        states.append({"key": "protectVersion", "value": nvr.get("version", "Unknown")})
                    if "nvrName" in declared_states:
                        states.append({"key": "nvrName", "value": nvr.get("name", "Unknown")})
            except Exception:
                pass

        if states:
            try:
                dev.updateStatesOnServer(states)
            except Exception:
                pass

    # ------------------------------------------------------------------
    # WebSocket handlers
    # ------------------------------------------------------------------

    def _on_network_ws(self, controller_id, message):
        """Handle Network legacy WebSocket message."""
        try:
            meta = message.get("meta", {})
            msg_type = meta.get("message", "")

            if msg_type in ("device:update", "device:sync"):
                for d in message.get("data", []):
                    mac = d.get("mac", "").lower()
                    if mac and mac in self.controllers[controller_id]["network_devices"]:
                        self._apply_netdev_state(controller_id, mac, d)

            elif msg_type in ("sta:connect", "sta:disconnect", "sta:sync"):
                for c in message.get("data", []):
                    mac = c.get("mac", "").lower()
                    if mac and mac in self.controllers[controller_id]["clients"]:
                        # Trigger fresh fetch since WS data may be partial
                        self._update_client_states(controller_id, mac)

            elif msg_type in ("device-port:update", "device-port:sync"):
                for d in message.get("data", []):
                    mac = d.get("mac", "").lower()
                    if mac and mac in self.controllers[controller_id]["network_devices"]:
                        self._apply_netdev_state(controller_id, mac, d)
                        # Also update any port devices on this switch
                        for port_key in list(self.controllers[controller_id]["ports"].keys()):
                            try:
                                pmac, pidx = port_key.split(":")
                                if pmac == mac:
                                    self._apply_port_state(controller_id, pmac, int(pidx), d)
                            except Exception:
                                pass

        except Exception as e:
            if self.debug:
                self.logger.debug(f"Network WS handler error: {e}")

    def _on_protect_devices_ws(self, controller_id, message):
        """Handle Protect Integration API device update WebSocket message."""
        try:
            controller = self.controllers.get(controller_id)
            if not controller:
                return
            api = controller.get("protect_api")
            if not api:
                return

            # Integration API device updates have shape:
            # { "type": "update", "item": "camera", "id": "...", "modifiedFields": [...] }
            item    = message.get("item") or message.get("itemType")
            item_id = message.get("id")

            if not item or not item_id:
                return

            if item == "camera" and item_id in controller["cameras"]:
                self._update_camera_states(controller_id, item_id)
            elif item == "sensor" and item_id in controller["sensors"]:
                self._update_sensor_states(controller_id, item_id)
            # Lights / chimes can be added in v3.3.0 when device types exist

        except Exception as e:
            if self.debug:
                self.logger.debug(f"Protect devices WS handler error: {e}")

    def _on_protect_events_ws(self, controller_id, message):
        """Handle Protect Integration API event stream (motion, smart detect, doorbell)."""
        try:
            controller = self.controllers.get(controller_id)
            if not controller:
                return

            # Event stream shape (from openHAB / HA reverse engineering):
            #   { "type": "add" | "update", "item": "event",
            #     "event": { "type": "motion" | "smartDetectZone" | "ring" | ...,
            #                "device": "<camera_id>",
            #                "smartDetectTypes": [...],
            #                "start": <ms>, "end": <ms or null> } }
            event = message.get("event") or message
            evt_type = event.get("type", "")
            cam_id   = event.get("device") or event.get("camera") or event.get("deviceId")
            if not cam_id or cam_id not in controller["cameras"]:
                return

            dev = indigo.devices[controller["cameras"][cam_id]]
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if evt_type == "motion":
                end = event.get("end")
                if end is None:  # motion start
                    dev.updateStateOnServer("motionDetected", True)
                    dev.updateStateOnServer("onOffState",     True)
                    dev.updateStateOnServer("lastMotion",     now_str)
                    self._fire_trigger("motionDetected", dev)
                else:  # motion end
                    dev.updateStateOnServer("motionDetected", False)
                    dev.updateStateOnServer("onOffState",     False)

            elif evt_type in ("smartDetectZone", "smartDetectLine"):
                detect_types = event.get("smartDetectTypes", []) or []
                end          = event.get("end")
                is_active    = end is None
                if "person" in detect_types:
                    dev.updateStateOnServer("personDetected", is_active)
                    if is_active:
                        dev.updateStateOnServer("lastPersonDetection", now_str)
                        self._fire_trigger("personDetected", dev)
                if "vehicle" in detect_types:
                    dev.updateStateOnServer("vehicleDetected", is_active)
                    if is_active:
                        self._fire_trigger("vehicleDetected", dev)
                if "package" in detect_types:
                    dev.updateStateOnServer("packageDetected", is_active)
                    if is_active:
                        self._fire_trigger("packageDetected", dev)

            elif evt_type == "ring":
                dev.updateStateOnServer("doorbellRinging",  True)
                dev.updateStateOnServer("lastDoorbellRing", now_str)
                self._fire_trigger("doorbellRing", dev)
                # Auto-clear after a few seconds
                threading.Timer(5.0, lambda d=dev: self._clear_doorbell(d)).start()

        except Exception as e:
            if self.debug:
                self.logger.debug(f"Protect events WS handler error: {e}")

    def _clear_doorbell(self, dev):
        try:
            dev.updateStateOnServer("doorbellRinging", False)
        except Exception:
            pass

    def _on_access_ws(self, controller_id, message):
        """Handle Access door notifications WebSocket message.

        Access can deliver several message shapes:
          * dict — actual event payload
          * str  — a heartbeat/keepalive ("Hello", ping/pong text), OR a JSON
                   document delivered as a string that needs parsing
          * bytes — same as str but binary
          * None / empty — keepalive ticks
        Anything that isn't a dict event payload is silently ignored.
        """
        try:
            controller = self.controllers.get(controller_id)
            if not controller:
                return

            # Normalise to a dict if we can; otherwise drop silently.
            if isinstance(message, (bytes, bytearray)):
                try:
                    message = message.decode("utf-8", errors="replace")
                except Exception:
                    return
            if isinstance(message, str):
                stripped = message.strip()
                if not stripped:
                    return
                # Some Access servers send keepalive as plain text ("Hello",
                # "ping", etc.) — only attempt JSON parse if it looks like JSON.
                if stripped[0] not in "{[":
                    return
                try:
                    message = json.loads(stripped)
                except (json.JSONDecodeError, ValueError):
                    return
            if not isinstance(message, dict):
                return

            event_type = message.get("event") or message.get("type")
            data       = message.get("data") or message
            door_id    = (data.get("door_id") if isinstance(data, dict) else None) \
                         or message.get("doorId")
            if door_id and door_id in controller.get("doors", {}):
                self._update_door_states(controller_id, door_id)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Access WS handler error: {e}")

    # ------------------------------------------------------------------
    # State updates - Cameras (Protect Integration API)
    # ------------------------------------------------------------------

    def _update_camera_states(self, controller_id, camera_id, refresh=True):
        try:
            controller = self.controllers.get(controller_id)
            if not controller:
                return
            api = controller.get("protect_api")
            if not api:
                return
            camera = api.get_camera(camera_id) if refresh else \
                     api._cameras_by_id.get(camera_id)
            if not camera:
                return
            dev_id = controller["cameras"].get(camera_id)
            if not dev_id or dev_id not in indigo.devices:
                return
            dev = indigo.devices[dev_id]

            # Track previous state for triggers
            prev_connected = dev.states.get("isConnected", True)
            prev_dark      = dev.states.get("isDark", False)

            # Connection / model
            is_connected = camera.get("isConnected", camera.get("state") == "CONNECTED")
            is_dark      = camera.get("isDark", False)
            model        = camera.get("modelKey") or camera.get("type") or \
                           camera.get("marketName") or "Unknown"

            states = [
                {"key": "status",          "value": "online" if is_connected else "offline"},
                {"key": "isConnected",     "value": bool(is_connected)},
                {"key": "model",           "value": str(model)},
                {"key": "firmwareVersion", "value": camera.get("firmwareVersion", "Unknown")},
                {"key": "isDark",          "value": bool(is_dark)},
                {"key": "ipAddress",       "value": camera.get("host") or camera.get("ip", "Unknown")},
                {"key": "macAddress",      "value": camera.get("mac", "Unknown")},
            ]

            # Uptime
            uptime_sec = camera.get("uptime")
            if isinstance(uptime_sec, (int, float)) and uptime_sec > 0:
                days  = int(uptime_sec) // 86400
                hours = (int(uptime_sec) % 86400) // 3600
                states.append({"key": "uptime", "value": f"{days}d {hours}h"})
            else:
                states.append({"key": "uptime", "value": "Offline" if not is_connected else "0d 0h"})

            # Recording
            rec = camera.get("recordingSettings") or {}
            states.append({"key": "recordingMode", "value": rec.get("mode", "unknown")})

            # ISP / IR mode
            isp = camera.get("ispSettings") or camera.get("isp") or {}
            states.append({"key": "irMode", "value": isp.get("irLedMode", "unknown")})

            # LED / status light
            led = camera.get("ledSettings") or {}
            states.append({"key": "statusLight", "value": bool(led.get("isEnabled", False))})

            # Voltage if present
            voltage = camera.get("voltage")
            states.append({"key": "voltage", "value": voltage if voltage is not None else 0})

            # Link / phyRate
            phy = camera.get("phyRate") or camera.get("linkSpeed")
            if phy:
                states.append({"key": "linkSpeed", "value": phy})

            # RTSP URLs from channels
            channels = camera.get("channels") or []
            for ch in channels:
                if ch.get("isRtspEnabled") and ch.get("rtspAlias"):
                    name = (ch.get("name") or "").capitalize()
                    if name:
                        states.append({
                            "key":   f"rtspUrl{name}",
                            "value": f"rtsps://{api.host}:7441/{ch['rtspAlias']}?enableSrtp",
                        })

            # Snapshot URL (Bearer-auth path through the integration API)
            states.append({
                "key":   "snapshotUrl",
                "value": api.get_camera_snapshot_url(camera_id),
            })

            # NOTE: motion / smart detect / doorbell are driven by the WS event
            # stream (real-time). We don't poll those into state on stats refresh.

            dev.updateStatesOnServer(states)

            # Connection / dark triggers
            if bool(is_connected) != bool(prev_connected):
                self._fire_trigger("cameraConnected" if is_connected else "cameraDisconnected", dev)
            if bool(is_dark) != bool(prev_dark):
                self._fire_trigger("cameraDark" if is_dark else "cameraLight", dev)

        except Exception as e:
            self.logger.error(f"Camera {camera_id} state update error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    # ------------------------------------------------------------------
    # State updates - Sensors (Protect Integration API)
    # ------------------------------------------------------------------

    def _update_sensor_states(self, controller_id, sensor_id, refresh=True):
        try:
            controller = self.controllers.get(controller_id)
            if not controller:
                return
            api = controller.get("protect_api")
            if not api:
                return
            sensor = api.get_sensor(sensor_id) if refresh else \
                     api._sensors_by_id.get(sensor_id)
            if not sensor:
                return
            dev_id = controller["sensors"].get(sensor_id)
            if not dev_id or dev_id not in indigo.devices:
                return
            dev = indigo.devices[dev_id]

            # Track prev for triggers
            prev_motion  = dev.states.get("motionDetected", False)
            prev_contact = dev.states.get("isOpened",       False)
            prev_alarm   = dev.states.get("alarmActive",    False)

            is_connected = sensor.get("isConnected", sensor.get("state") == "CONNECTED")
            mount_type   = sensor.get("mountType", "")

            states = [
                {"key": "status",      "value": "online" if is_connected else "offline"},
                {"key": "isConnected", "value": bool(is_connected)},
                {"key": "model",       "value": sensor.get("modelKey") or sensor.get("type", "Unknown")},
                {"key": "macAddress",  "value": sensor.get("mac", "Unknown")},
                {"key": "mountType",   "value": mount_type},
            ]

            # Battery
            battery = sensor.get("batteryStatus") or {}
            if isinstance(battery, dict):
                lvl = battery.get("percentage")
                if lvl is not None:
                    states.append({"key": "batteryLevel", "value": int(lvl)})
                states.append({"key": "batteryLow", "value": bool(battery.get("isLow", False))})
                # Keep human-readable batteryStatus too
                if battery.get("isLow"):
                    states.append({"key": "batteryStatus", "value": "Low"})
                elif battery.get("isCharging"):
                    states.append({"key": "batteryStatus", "value": "Charging"})
                else:
                    states.append({"key": "batteryStatus", "value": "OK"})

            # Motion sensor
            stats = sensor.get("stats") or {}
            motion_stats = stats.get("motion", {}) if isinstance(stats, dict) else {}
            motion_active = bool(motion_stats.get("isTriggered", False))
            states.append({"key": "motionDetected", "value": motion_active})
            states.append({"key": "onOffState",     "value": motion_active})
            if motion_active:
                states.append({"key": "lastMotion",
                               "value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})

            # Contact (open/close)
            is_opened = bool(sensor.get("isOpened", False))
            states.append({"key": "isOpened", "value": is_opened})

            # Temperature / humidity / light from stats
            for key, src_key in (("temperature", "temperature"),
                                 ("humidity",    "humidity"),
                                 ("lightLevel",  "light")):
                src = stats.get(src_key, {}) if isinstance(stats, dict) else {}
                val = src.get("value") if isinstance(src, dict) else None
                if val is not None:
                    states.append({"key": key, "value": round(float(val), 1)})

            # Alarm
            alarm_stats  = stats.get("alarm", {}) if isinstance(stats, dict) else {}
            alarm_active = bool(alarm_stats.get("isTriggered", False))
            states.append({"key": "alarmActive", "value": alarm_active})

            # Sensor name + type
            states.append({"key": "sensorName", "value": sensor.get("name", "")})
            sensor_type = sensor.get("modelKey") or sensor.get("type") or "sensor"
            states.append({"key": "sensorType", "value": sensor_type})
            states.append({"key": "firmwareVersion", "value": sensor.get("firmwareVersion", "Unknown")})

            dev.updateStatesOnServer(states)

            # Triggers
            if motion_active and not prev_motion:
                self._fire_trigger("sensorMotionDetected", dev)
            if is_opened != prev_contact:
                self._fire_trigger("sensorOpened" if is_opened else "sensorClosed", dev)
            if alarm_active and not prev_alarm:
                self._fire_trigger("sensorAlarmTriggered", dev)

        except Exception as e:
            self.logger.error(f"Sensor {sensor_id} state update error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    # ------------------------------------------------------------------
    # State updates - Network devices (legacy)
    # ------------------------------------------------------------------

    def _update_netdev_states(self, controller_id, mac):
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            return
        try:
            d = controller["network_api"].get_device(mac)
            if d:
                self._apply_netdev_state(controller_id, mac, d)
        except Exception as e:
            self.logger.error(f"Net device {mac} state update error: {e}")

    def _apply_netdev_state(self, controller_id, mac, device):
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        dev_id = controller["network_devices"].get(mac)
        if not dev_id or dev_id not in indigo.devices:
            return
        dev = indigo.devices[dev_id]

        # Track previous connection state for triggers
        prev_connected = dev.states.get("isConnected", True)

        is_connected = device.get("state", 0) == 1
        is_disabled  = bool(device.get("disabled", False))

        states = [
            {"key": "status",          "value": "online" if is_connected else "offline"},
            {"key": "isConnected",     "value": is_connected},
            {"key": "adopted",         "value": is_connected},
            {"key": "disabled",        "value": is_disabled},
            {"key": "model",           "value": device.get("model", "Unknown")},
            {"key": "firmwareVersion", "value": device.get("version", "Unknown")},
            {"key": "ipAddress",       "value": device.get("ip", "Unknown")},
            {"key": "macAddress",      "value": device.get("mac", "Unknown")},
            {"key": "deviceType",      "value": device.get("type", "unknown")},
            {"key": "deviceName",      "value": device.get("name", "Unknown")},
            {"key": "onOffState",      "value": not is_disabled},
        ]

        # Uptime
        uptime_sec = device.get("uptime")
        if isinstance(uptime_sec, (int, float)):
            d_ = int(uptime_sec) // 86400
            h_ = (int(uptime_sec) % 86400) // 3600
            m_ = (int(uptime_sec) % 3600) // 60
            states.append({"key": "uptime",        "value": f"{d_}d {h_}h {m_}m"})
            states.append({"key": "uptimeSeconds", "value": int(uptime_sec)})

        # System stats
        sys_stats = device.get("system-stats") or {}
        for key, src_key in (("cpuUsage", "cpu"), ("memoryUsage", "mem")):
            v = sys_stats.get(src_key)
            if v is not None:
                try:
                    states.append({"key": key, "value": round(float(str(v).strip()), 1)})
                except (ValueError, TypeError):
                    pass
        temps = sys_stats.get("temps") or []
        if isinstance(temps, list) and temps:
            try:
                states.append({"key": "temperature",
                               "value": round(float(str(temps[0]).strip()), 1)})
            except (ValueError, TypeError):
                pass

        # LED
        led_override = device.get("led_override", "default")
        states.append({"key": "ledEnabled",  "value": led_override == "on"})
        states.append({"key": "ledOverride", "value": led_override})
        states.append({"key": "updateAvailable", "value": bool(device.get("upgradable", False))})

        device_type = device.get("type", "")
        if device_type == "usw":
            port_table = device.get("port_table") or []
            states.append({"key": "portCount", "value": len(port_table)})
            poe_total = 0.0
            for p in port_table:
                try:
                    poe_total += float(p.get("poe_power") or 0)
                except (ValueError, TypeError):
                    pass
            states.append({"key": "poeConsumption", "value": round(poe_total, 2)})
        elif device_type == "uap":
            states.append({"key": "connectedClients", "value": int(device.get("num_sta", 0))})
            states.append({"key": "guestClients",     "value": int(device.get("guest-num_sta", 0))})
            states.append({"key": "userClients",      "value": int(device.get("user-num_sta", 0))})
            for radio in (device.get("radio_table") or []):
                if not isinstance(radio, dict):
                    continue
                name = (radio.get("name") or "").lower()
                channel = radio.get("channel", 0)
                key = None
                if "ng" in name or "2g" in name or name == "wifi0":
                    key = "channel2G"
                elif "na" in name or "5g" in name or name == "wifi1":
                    key = "channel5G"
                if key:
                    try:
                        states.append({"key": key, "value": int(channel)})
                    except (ValueError, TypeError):
                        states.append({"key": key, "value": 0})
            sat = device.get("satisfaction")
            if sat is not None:
                try:
                    states.append({"key": "satisfaction", "value": int(sat)})
                except (ValueError, TypeError):
                    pass

        try:
            dev.updateStatesOnServer(states)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"updateStatesOnServer({dev.name}) failed: {e}")

        # Fire connection-state triggers
        if bool(is_connected) != bool(prev_connected):
            self._fire_trigger("deviceOnline" if is_connected else "deviceOffline", dev)

    # ------------------------------------------------------------------
    # State updates - Ports (legacy)
    # ------------------------------------------------------------------

    def _update_port_states(self, controller_id, mac, port_num):
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            return
        try:
            d = controller["network_api"].get_device(mac)
            if d:
                self._apply_port_state(controller_id, mac, port_num, d)
        except Exception as e:
            self.logger.error(f"Port {mac}:{port_num} state update error: {e}")

    def _apply_port_state(self, controller_id, mac, port_num, device):
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        dev_id = controller["ports"].get(f"{mac}:{port_num}")
        if not dev_id or dev_id not in indigo.devices:
            return
        dev = indigo.devices[dev_id]

        # Find port by index
        port = None
        for p in (device.get("port_table") or []):
            if p.get("port_idx") == port_num:
                port = p
                break
        if not port:
            return

        # Previous values for triggers
        prev_link_up     = bool(dev.states.get("up", False))
        prev_poe_enabled = bool(dev.states.get("poeEnabled", False))

        is_up        = bool(port.get("up", False))
        poe_enabled  = bool(port.get("poe_enable", False))
        poe_power    = port.get("poe_power", 0)
        speed        = port.get("speed", 0)
        port_name    = port.get("name") or f"Port {port_num}"
        poe_mode     = port.get("poe_mode", "off")

        # On/off state depends on the device's control mode
        control_mode = dev.pluginProps.get("controlMode", "poe")
        if control_mode == "poe":
            on_off = poe_enabled
        else:
            on_off = is_up  # link-state mode

        states = [
            {"key": "portName",     "value": port_name},
            {"key": "up",           "value": is_up},
            {"key": "poeEnabled",   "value": poe_enabled},
            {"key": "poeEnable",    "value": poe_enabled},
            {"key": "poeMode",      "value": poe_mode},
            {"key": "poePower",     "value": float(poe_power) if poe_power else 0.0},
            {"key": "speed",        "value": speed},
            {"key": "onOffState",   "value": on_off},
        ]
        try:
            dev.updateStatesOnServer(states)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"updateStatesOnServer({dev.name}) failed: {e}")

        # Fire triggers
        if is_up != prev_link_up:
            self._fire_trigger("portLinkUp" if is_up else "portLinkDown", dev)
        if poe_enabled != prev_poe_enabled:
            self._fire_trigger("portPoeOn" if poe_enabled else "portPoeOff", dev)

    # ------------------------------------------------------------------
    # State updates - Clients (legacy)
    # ------------------------------------------------------------------

    def _update_client_states(self, controller_id, mac):
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            return
        try:
            client = controller["network_api"].get_client(mac)
            dev_id = controller["clients"].get(mac)
            if not dev_id or dev_id not in indigo.devices:
                return
            dev = indigo.devices[dev_id]

            # Previous values for triggers
            prev_connected = bool(dev.states.get("isConnected", False))
            prev_blocked   = bool(dev.states.get("isBlocked",   False))

            if not client:
                # Client not currently visible - mark offline but don't error
                dev.updateStateOnServer("status", "offline")
                dev.updateStateOnServer("isConnected", False)
                dev.updateStateOnServer("onOffState", False)
                if prev_connected:
                    self._fire_trigger("clientDisconnected", dev)
                return

            is_connected = bool(client.get("is_online", True))  # /stat/sta returns active clients only
            is_blocked   = bool(client.get("blocked", False))

            states = [
                {"key": "status",       "value": "online" if is_connected else "offline"},
                {"key": "isConnected",  "value": is_connected},
                {"key": "isBlocked",    "value": is_blocked},
                {"key": "ipAddress",    "value": client.get("ip", "")},
                {"key": "hostname",     "value": client.get("hostname") or client.get("name", "")},
                {"key": "macAddress",   "value": client.get("mac", "")},
                {"key": "manufacturer", "value": client.get("oui", "")},
                {"key": "rxBytes",      "value": int(client.get("rx_bytes", 0))},
                {"key": "txBytes",      "value": int(client.get("tx_bytes", 0))},
                {"key": "onOffState",   "value": is_connected and not is_blocked},
            ]

            ssid = client.get("essid")
            if ssid:
                states.append({"key": "ssid", "value": ssid})
            ap_mac = client.get("ap_mac")
            if ap_mac:
                states.append({"key": "apMac", "value": ap_mac})

            try:
                dev.updateStatesOnServer(states)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"updateStatesOnServer({dev.name}) failed: {e}")

            # Fire triggers
            if is_connected != prev_connected:
                self._fire_trigger("clientConnected" if is_connected else "clientDisconnected", dev)
            if is_blocked != prev_blocked:
                self._fire_trigger("clientBlocked" if is_blocked else "clientUnblocked", dev)

        except Exception as e:
            self.logger.error(f"Client {mac} state update error: {e}")

    # ------------------------------------------------------------------
    # State updates - Doors (Access)
    # ------------------------------------------------------------------

    def _update_door_states(self, controller_id, door_id):
        controller = self.controllers.get(controller_id)
        if not controller or "access_api" not in controller:
            return
        try:
            door = controller["access_api"].get_door(door_id)
            dev_id = controller["doors"].get(door_id)
            if not dev_id or dev_id not in indigo.devices:
                return
            dev = indigo.devices[dev_id]

            # Previous state
            prev_locked = bool(dev.states.get("isLocked", True))

            if not door:
                dev.updateStateOnServer("status", "Not found")
                return

            is_locked = not bool(door.get("door_lock_relay_status") == "unlock")
            states = [
                {"key": "status",     "value": "locked" if is_locked else "unlocked"},
                {"key": "isLocked",   "value": is_locked},
                {"key": "doorName",   "value": door.get("name", "Unknown")},
                {"key": "onOffState", "value": not is_locked},  # on = unlocked
            ]
            position = door.get("door_position_status")
            if position:
                states.append({"key": "doorState", "value": position})

            try:
                dev.updateStatesOnServer(states)
            except Exception as e:
                if self.debug:
                    self.logger.debug(f"updateStatesOnServer({dev.name}) failed: {e}")

            # Fire triggers
            if is_locked != prev_locked:
                self._fire_trigger("doorLocked" if is_locked else "doorUnlocked", dev)
        except Exception as e:
            self.logger.error(f"Door {door_id} state update error: {e}")

    # ------------------------------------------------------------------
    # State updates - Drive / Fan (legacy)
    # ------------------------------------------------------------------

    def _update_drive_states(self, controller_id):
        """Refresh the Drive controller device states, then cascade pool/disk updates.

        All UNAS data lives on the controller device itself; per-pool and
        per-disk detail is surfaced through child unifiDrivePool/unifiDriveDisk
        devices.
        """
        controller = self.controllers.get(controller_id)
        if not controller or "drive_api" not in controller:
            return
        api = controller["drive_api"]

        # Always fetch storage + system; firmware/app updates are best-effort
        try:
            storage  = api.get_storage_info() or {}
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Drive storage fetch error: {e}")
            storage = {}

        try:
            system = api.get_system_info() or {}
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Drive system fetch error: {e}")
            system = {}

        # Debug: dump the raw payloads so field-name mismatches are easy to
        # diagnose. Only fires when debug logging is enabled on the plugin.
        # JSON is truncated to ~4 KB per payload to avoid log spam.
        if self.debug:
            try:
                storage_dump = json.dumps(storage, default=str, indent=2)
                if len(storage_dump) > 4000:
                    storage_dump = storage_dump[:4000] + "\n…(truncated)"
                self.logger.debug(f"[Drive raw /storage payload]\n{storage_dump}")
            except Exception:
                self.logger.debug(f"[Drive raw /storage payload — not JSON-serialisable: {type(storage)}]")
            try:
                system_dump = json.dumps(system, default=str, indent=2)
                if len(system_dump) > 4000:
                    system_dump = system_dump[:4000] + "\n…(truncated)"
                self.logger.debug(f"[Drive raw /system payload]\n{system_dump}")
            except Exception:
                self.logger.debug(f"[Drive raw /system payload — not JSON-serialisable: {type(system)}]")

        # Cache the parsed payloads so pool/disk updates don't need to refetch
        controller["last_storage"]  = storage
        controller["last_system"]   = system
        controller["last_storage_at"] = time.time()

        # Pool list (extracted once, used for both aggregate counts and per-pool updates)
        pools = _drive_extract_pools(storage)
        controller["last_pools"] = pools

        # ---- Mirror at-a-glance info to the Drive Controller device.
        # We only write states the controller device type actually declares.
        try:
            controller_dev = controller.get("device")
            if controller_dev is not None and controller_dev.deviceTypeId == "unifiDriveController":
                declared = set(controller_dev.states.keys())
                ctrl_states = []

                # Simple text fields from /api/system
                if "hostname" in declared:
                    v = _drive_first_text(system, ("name", "hostname", "deviceName"))
                    if v: ctrl_states.append({"key": "hostname", "value": v})

                if "macAddress" in declared:
                    v = _drive_first_text(system, ("mac", "macAddress", "mac_address"))
                    if v: ctrl_states.append({"key": "macAddress", "value": v})

                # Model lives under hardware.shortname (e.g. "UNASPRO")
                if "model" in declared:
                    hw = system.get("hardware") if isinstance(system, dict) else None
                    model = None
                    if isinstance(hw, dict):
                        model = _drive_first_text(hw, ("shortname", "model", "type", "name"))
                    if not model:
                        model = _drive_first_text(system, ("model",))
                    if model:
                        ctrl_states.append({"key": "model", "value": model})

                if "deviceState" in declared:
                    v = _drive_first_text(system, ("deviceState", "device_state", "status"))
                    if v: ctrl_states.append({"key": "deviceState", "value": v})

                if "cloudConnected" in declared:
                    v = system.get("cloudConnected") if isinstance(system, dict) else None
                    if v is not None:
                        ctrl_states.append({"key": "cloudConnected", "value": bool(v)})

                if "hasInternet" in declared:
                    v = system.get("hasInternet") if isinstance(system, dict) else None
                    if v is not None:
                        ctrl_states.append({"key": "hasInternet", "value": bool(v)})

                # Storage aggregates — try top-level keys first, fall back to
                # summing across pools.
                total_b = _drive_first_number(storage, _DRIVE_AGG_CAPACITY_KEYS)
                used_b  = _drive_first_number(storage, _DRIVE_AGG_USAGE_KEYS)
                avail_b = _drive_first_number(storage, _DRIVE_AGG_AVAILABLE_KEYS)
                if total_b is None and pools:
                    total_b = sum((_drive_first_number(p, _DRIVE_CAPACITY_KEYS) or 0) for p in pools) or None
                if used_b is None and pools:
                    used_b = sum((_drive_first_number(p, _DRIVE_USAGE_KEYS) or 0) for p in pools) or None
                if avail_b is None and total_b is not None and used_b is not None:
                    avail_b = max(0, total_b - used_b)
                total_gb = _drive_bytes_to_gb(total_b)
                used_gb  = _drive_bytes_to_gb(used_b)
                avail_gb = _drive_bytes_to_gb(avail_b)
                if "totalCapacity" in declared and total_gb is not None:
                    ctrl_states.append({"key": "totalCapacity", "value": total_gb})
                if "usedSpace"     in declared and used_gb  is not None:
                    ctrl_states.append({"key": "usedSpace",     "value": used_gb})
                if "freeSpace"     in declared and avail_gb is not None:
                    ctrl_states.append({"key": "freeSpace",     "value": avail_gb})
                if "usagePercent"  in declared and total_gb and total_gb > 0 and used_gb is not None:
                    ctrl_states.append({"key": "usagePercent",
                                        "value": round((used_gb / total_gb) * 100, 1)})

                # Derive overallStatus from the pool statuses since the storage
                # endpoint doesn't expose a top-level overall status. If all
                # pools healthy -> "ok"; any not -> "problem".
                if "overallStatus" in declared:
                    explicit = _drive_first_text(storage, ("overallStatus", "overall_status", "status"))
                    if explicit:
                        ctrl_states.append({"key": "overallStatus", "value": explicit})
                    elif pools:
                        any_problem = any(
                            not _drive_is_healthy(_drive_first_text(p, ("status", "state")))
                            for p in pools
                        )
                        ctrl_states.append({"key": "overallStatus",
                                            "value": "problem" if any_problem else "ok"})
                    else:
                        ctrl_states.append({"key": "overallStatus", "value": "unknown"})

                if "poolCount" in declared:
                    ctrl_states.append({"key": "poolCount", "value": len(pools)})

                # Disks (top-level array). Build once, reuse for counts.
                all_disks = _drive_extract_disks(storage)
                if "diskCount" in declared:
                    ctrl_states.append({"key": "diskCount", "value": len(all_disks)})
                if "atRiskDiskCount" in declared:
                    at_risk = sum(
                        1 for d in all_disks
                        if d.get("atRisk") or d.get("at_risk") or
                           (isinstance(d.get("riskReasons"), list) and d["riskReasons"]) or
                           _drive_is_at_risk(_drive_first_text(d, ("state", "status", "health")))
                    )
                    ctrl_states.append({"key": "atRiskDiskCount", "value": at_risk})
                if "averageDiskTemperature" in declared:
                    temps = [
                        _drive_first_number(d, ("temperature", "temp", "temperatureC", "temperature_c"))
                        for d in all_disks
                    ]
                    temps = [t for t in temps if t is not None]
                    if temps:
                        ctrl_states.append({"key": "averageDiskTemperature",
                                            "value": round(sum(temps) / len(temps), 1)})

                # SSH fan control deployment status (best effort — don't fail
                # the poll if SSH is offline or slow). Only checks every 10
                # poll cycles to keep network traffic down.
                ssh = controller.get("drive_ssh")
                if ssh is not None and ("fanControlDeployed" in declared or
                                        "fanControlActiveMode" in declared):
                    last_check = controller.get("last_ssh_check_at", 0)
                    if time.time() - last_check > 300:  # at most every 5 min
                        try:
                            deployed = ssh.is_deployed()
                            ctrl_states.append({"key": "fanControlDeployed", "value": bool(deployed)})
                            if deployed:
                                active_mode = ssh.get_active_mode()
                                ctrl_states.append({"key": "fanControlActiveMode", "value": active_mode})
                            else:
                                ctrl_states.append({"key": "fanControlActiveMode", "value": ""})
                            controller["last_ssh_check_at"] = time.time()
                        except UnifiSSHError as e:
                            if self.debug:
                                self.logger.debug(f"SSH deployment check failed: {e}")

                if ctrl_states:
                    try:
                        controller_dev.updateStatesOnServer(ctrl_states)
                    except Exception as e:
                        if self.debug:
                            self.logger.debug(f"Controller updateStatesOnServer failed: {e}")
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Controller mirror error: {e}")

        # ---- Cascade: pool devices and disk devices ----
        controller["pools_by_key"] = {}
        controller["disks_by_key"] = {}

        # Build a pool_id -> (pool_key, pool_index) lookup so we can attribute
        # each disk back to its parent pool when iterating top-level disks.
        pool_id_to_key = {}
        for idx, pool in enumerate(pools):
            pkey = _drive_pool_key(pool, idx)
            controller["pools_by_key"][pkey] = {"data": pool, "index": idx}
            for id_field in ("id", "guid", "poolGuid", "uuid"):
                pid = pool.get(id_field)
                if pid:
                    pool_id_to_key[pid] = (pkey, idx)
                    break

        all_disks = _drive_extract_disks(storage)
        for didx, disk in enumerate(all_disks):
            dkey = _drive_disk_key(disk, didx)
            pool_id  = disk.get("poolId") or disk.get("pool_id") or disk.get("poolGuid")
            pkey, pidx = pool_id_to_key.get(pool_id, ("", 0))
            controller["disks_by_key"][dkey] = {
                "data": disk, "index": didx, "pool_index": pidx, "pool_key": pkey,
            }

        # Update all pool devices we know about
        for pkey, pool_dev_id in (controller.get("pool_devices") or {}).items():
            self._update_pool_states(controller_id, pkey)
        for dkey, disk_dev_id in (controller.get("disk_devices") or {}).items():
            self._update_disk_states(controller_id, dkey)

    def _update_pool_states(self, controller_id, pool_key):
        """Refresh a single unifiDrivePool device's states from cached pool data."""
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        pool_entry = (controller.get("pools_by_key") or {}).get(pool_key)
        dev_id = (controller.get("pool_devices") or {}).get(pool_key)
        if not dev_id or dev_id not in indigo.devices:
            return
        dev = indigo.devices[dev_id]
        if not pool_entry:
            try:
                dev.updateStatesOnServer([
                    {"key": "status",     "value": "Not found"},
                    {"key": "poolStatus", "value": "missing"},
                ])
            except Exception:
                pass
            return

        pool  = pool_entry["data"]
        index = pool_entry["index"]
        states = []

        name = _drive_pool_name(pool, index)
        states.append({"key": "poolName", "value": name})

        status = _drive_first_text(pool, ("status", "state", "health")) or "unknown"
        states.append({"key": "poolStatus", "value": status})
        states.append({"key": "status",     "value": "Connected"})

        cap_b   = _drive_first_number(pool, _DRIVE_CAPACITY_KEYS)
        used_b  = _drive_first_number(pool, _DRIVE_USAGE_KEYS)
        avail_b = _drive_first_number(pool, _DRIVE_AVAILABLE_KEYS)
        # If "available" not in payload but we have cap and used, derive it.
        if avail_b is None and cap_b is not None and used_b is not None:
            avail_b = max(0, cap_b - used_b)

        cap_gb   = _drive_bytes_to_gb(cap_b)
        used_gb  = _drive_bytes_to_gb(used_b)
        avail_gb = _drive_bytes_to_gb(avail_b)

        if cap_gb   is not None: states.append({"key": "capacity",  "value": cap_gb})
        if used_gb  is not None: states.append({"key": "used",      "value": used_gb})
        if avail_gb is not None: states.append({"key": "available", "value": avail_gb})
        if cap_gb and cap_gb > 0 and used_gb is not None:
            states.append({"key": "usagePercent",
                           "value": round((used_gb / cap_gb) * 100, 1)})

        # RAID level: prefer 'preferLevel' (raid5/raid6/etc) over 'type' (lvm)
        raid = (pool.get("preferLevel") or
                _drive_first_text(pool, _DRIVE_RAID_KEYS) or
                "unknown")
        states.append({"key": "raidLevel", "value": raid})

        # Disks for THIS pool — filter the top-level disk array by poolId.
        # The cached storage payload is held on the controller.
        cached_storage = controller.get("last_storage", {})
        disks = _drive_extract_disks_for_pool(cached_storage, pool)
        states.append({"key": "driveCount", "value": len(disks)})

        at_risk = sum(
            1 for d in disks
            if d.get("atRisk") or d.get("at_risk") or
               (isinstance(d.get("riskReasons"), list) and d["riskReasons"]) or
               _drive_is_at_risk(_drive_first_text(d, ("status", "state", "health")))
        )
        states.append({"key": "atRiskDriveCount", "value": at_risk})

        temps = [
            _drive_first_number(d, ("temperature", "temp", "temperatureC")) for d in disks
        ]
        temps = [t for t in temps if t is not None]
        if temps:
            states.append({"key": "averageDriveTemperature",
                           "value": round(sum(temps) / len(temps), 1)})

        # Rebuild/sync progress: at pool level OR in raidGroups[0].progress
        rebuild = _drive_first_number(pool, ("rebuildProgress", "rebuild_progress", "rebuildPercent"))
        if rebuild is None:
            raid_groups = pool.get("raidGroups")
            if isinstance(raid_groups, list) and raid_groups:
                rebuild = _drive_first_number(raid_groups[0], ("progress", "rebuildProgress"))
        if rebuild is not None:
            states.append({"key": "rebuildProgress", "value": round(rebuild, 1)})

        sync = _drive_first_number(pool, ("syncProgress", "sync_progress", "syncPercent",
                                          "resyncProgress", "scrubProgress"))
        if sync is not None:
            states.append({"key": "syncProgress", "value": round(sync, 1)})

        states.append({"key": "poolProblem",
                       "value": not _drive_is_healthy(status)})
        states.append({"key": "maintenanceActive",
                       "value": bool(pool.get("maintenance") or pool.get("inMaintenance"))})

        try:
            dev.updateStatesOnServer(states)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Pool update for {dev.name} failed: {e}")

    def _update_disk_states(self, controller_id, disk_key):
        """Refresh a single unifiDriveDisk device's states from cached disk data."""
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        disk_entry = (controller.get("disks_by_key") or {}).get(disk_key)
        dev_id = (controller.get("disk_devices") or {}).get(disk_key)
        if not dev_id or dev_id not in indigo.devices:
            return
        dev = indigo.devices[dev_id]
        if not disk_entry:
            try:
                dev.updateStatesOnServer([
                    {"key": "status",     "value": "Not found"},
                    {"key": "diskStatus", "value": "missing"},
                ])
            except Exception:
                pass
            return

        disk      = disk_entry["data"]
        index     = disk_entry["index"]
        pool_idx  = disk_entry.get("pool_index", 0)
        pool_key  = disk_entry.get("pool_key", "")

        # Get the parent pool name for display
        pool_name = "Unknown"
        if pool_key:
            pe = (controller.get("pools_by_key") or {}).get(pool_key)
            if pe:
                pool_name = _drive_pool_name(pe["data"], pe["index"])

        states = []
        states.append({"key": "status",     "value": "Connected"})
        states.append({"key": "diskName",   "value": _drive_disk_name(disk, index, pool_idx)})
        states.append({"key": "poolName",   "value": pool_name})

        # 'state' is the canonical field on current UNAS firmware (e.g. "optimal")
        # — older firmware may use 'status' or 'health'. _drive_first_text picks
        # the first that exists.
        d_status = _drive_first_text(disk, ("state", "status", "health")) or "unknown"
        states.append({"key": "diskStatus", "value": d_status})

        # At-risk detection: prefer the explicit riskReasons array if present
        # (current firmware), fall back to status-string matching for older.
        risk_reasons = disk.get("riskReasons")
        is_at_risk = bool(
            disk.get("atRisk") or disk.get("at_risk") or
            (isinstance(risk_reasons, list) and risk_reasons) or
            _drive_is_at_risk(d_status)
        )
        states.append({"key": "atRisk", "value": is_at_risk})

        temp = _drive_first_number(disk, ("temperature", "temp", "temperatureC", "temperature_c"))
        if temp is not None:
            states.append({"key": "temperature", "value": round(temp, 1)})

        poh = _drive_first_number(disk, ("powerOnHours", "power_on_hours", "powerOnTime"))
        if poh is not None:
            states.append({"key": "powerOnHours", "value": int(poh)})

        model = _drive_first_text(disk, ("model", "modelName", "device"))
        if model: states.append({"key": "model", "value": model})

        serial = _drive_first_text(disk, ("serialNumber", "serial", "serial_number"))
        if serial: states.append({"key": "serial", "value": serial})

        cap_b = _drive_first_number(disk, _DRIVE_CAPACITY_KEYS)
        cap_gb = _drive_bytes_to_gb(cap_b)
        if cap_gb is not None:
            states.append({"key": "capacityGB", "value": cap_gb})

        try:
            dev.updateStatesOnServer(states)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Disk update for {dev.name} failed: {e}")

    def _check_fan_control_deployment(self, controller_id):
        """Once a day, verify the SSH-deployed fan control is still installed
        on the UNAS. If it's gone (most likely because a UniFi OS update wiped
        the filesystem), redeploy silently.

        Skipped entirely when:
          - SSH isn't enabled / no SSH helper
          - The user has unticked 'Auto-redeploy after firmware updates'
          - We've never deployed it (first-time install — wait for the user
            to click the manual button)
          - We checked less than 24 hours ago
        """
        controller = self.controllers.get(controller_id)
        if not controller:
            return
        ssh = controller.get("drive_ssh")
        if ssh is None:
            return

        cdev = controller.get("device")
        if cdev is None:
            return

        # Respect user's opt-out
        if not bool(cdev.pluginProps.get("autoRedeployFanControl", True)):
            return

        # Only check once per 24h
        last = controller.get("last_fan_redeploy_check_at", 0)
        now  = time.time()
        if now - last < 86400:
            return
        controller["last_fan_redeploy_check_at"] = now

        # Only consider redeploying if we previously deployed (fanControlDeployed
        # state is true). First-time setup must be done manually.
        try:
            previously_deployed = bool(cdev.states.get("fanControlDeployed", False))
        except Exception:
            previously_deployed = False
        if not previously_deployed:
            return

        # Check if still installed
        try:
            if ssh.is_deployed():
                if self.debug:
                    self.logger.debug(f"{cdev.name}: Fan control deployment intact.")
                return
        except UnifiSSHError as e:
            if self.debug:
                self.logger.debug(f"{cdev.name}: Fan control deployment check failed: {e}")
            return

        # Marker missing — redeploy silently.
        if not self.fan_script_content or not self.fan_service_content:
            self.logger.error(
                f"{cdev.name}: Fan control needs redeploy but bundled assets "
                f"are missing — cannot proceed automatically."
            )
            return

        self.logger.warning(
            f"{cdev.name}: Fan control was deployed but is no longer present "
            f"on the UNAS (likely after a UniFi OS update). Redeploying…"
        )
        try:
            ssh.deploy_fan_control(self.fan_script_content, self.fan_service_content)
            status      = ssh.get_service_status()
            active_mode = ssh.get_active_mode()
            self.logger.info(
                f"{cdev.name}: Fan control redeployed automatically. "
                f"Service: {status}, mode: {active_mode}"
            )
            try:
                cdev.updateStatesOnServer([
                    {"key": "fanControlDeployed",   "value": True},
                    {"key": "fanControlActiveMode", "value": active_mode},
                ])
            except Exception:
                pass
        except UnifiSSHError as e:
            self.logger.error(f"{cdev.name}: Auto-redeploy failed: {e}")
        except Exception as e:
            self.logger.error(f"{cdev.name}: Unexpected auto-redeploy error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    def _update_fan_states(self, controller_id):
        """Refresh the driveFan device's states.

        When SSH fan control is deployed on the UNAS, that is the source of
        truth for the active mode (because the UniFi REST API can't be told
        about our SSH-deployed script and continues reporting whatever native
        profile the user last picked in the UI). When SSH is not deployed,
        we fall back to the REST API value."""
        controller = self.controllers.get(controller_id)
        if not controller or "drive_api" not in controller:
            return
        dev_id = controller.get("fan_device")
        if not dev_id or dev_id not in indigo.devices:
            return
        dev = indigo.devices[dev_id]
        try:
            fan = controller["drive_api"].get_fan_info() or {}

            # Debug: surface the raw fan payload so the field names / shapes
            # for fan-control endpoints can be diagnosed.
            if self.debug:
                try:
                    fan_dump = json.dumps(fan, default=str, indent=2)
                    if len(fan_dump) > 2000:
                        fan_dump = fan_dump[:2000] + "\n…(truncated)"
                    self.logger.debug(f"[Drive raw /fan-control payload]\n{fan_dump}")
                except Exception:
                    self.logger.debug(f"[Drive raw /fan-control payload — type {type(fan).__name__}]")

            # RPM (still reported by API even when SSH is in control)
            rpm = _drive_first_number(fan, ("rpm", "currentRpm", "fanRpm")) or 0

            # Source of truth for display mode: SSH conf > API profile
            display_mode = None
            source       = "api"
            ssh = controller.get("drive_ssh")
            if ssh is not None:
                try:
                    if ssh.is_deployed():
                        # We trust the deployed config — even if SSH is briefly
                        # unreachable, the controller-level state cache reflects
                        # what we last set, which matches what's running on the
                        # UNAS (the systemd script reads the same conf file).
                        ssh_mode = ssh.get_active_mode()
                        # Map ssh mode -> canonical display name
                        mode_map = {
                            "quiet":   "Quiet",
                            "balance": "Balance",
                            "cooling": "Cooling",
                            "default": "Default",
                        }
                        display_mode = mode_map.get(ssh_mode.lower(), "Default")
                        source = "ssh"
                        if self.debug:
                            self.logger.debug(f"Fan mode source: SSH conf = {ssh_mode}")
                except Exception as e:
                    if self.debug:
                        self.logger.debug(f"SSH fan mode read failed, falling back to API: {e}")

            if display_mode is None:
                # API fallback. Map 'profile' to one of our canonical names.
                if not fan:
                    dev.updateStateOnServer("status", "Not available")
                    return
                raw_profile = (_drive_first_text(fan, ("profile", "currentProfile", "mode",
                                                        "fanMode", "fan_mode")) or "").lower()
                display_mode = "Balance"
                for canonical, api_values in DRIVE_FAN_MODE_API_VALUES.items():
                    if raw_profile in api_values:
                        display_mode = canonical
                        break

            # Anchor mapping: 0% Quiet, 50% Balance, 100% Cooling
            # "Default" doesn't map to a brightness — leave dimmer wherever the
            # user last set it. Mostly applicable when source==ssh and mode is
            # "default", which means "let firmware manage".
            mode_to_brightness = {"Quiet": 0, "Balance": 50, "Cooling": 100}
            states = [
                {"key": "fanMode",         "value": display_mode},
                {"key": "fanRPM",          "value": int(rpm)},
                {"key": "status",
                 "value": f"{display_mode} ({int(rpm)} RPM)" if rpm else display_mode},
            ]
            if display_mode in mode_to_brightness:
                states.append({"key": "brightnessLevel",
                               "value": mode_to_brightness[display_mode]})

            dev.updateStatesOnServer(states)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Fan state update error: {e}")

    # ------------------------------------------------------------------
    # Test Connection (callback from controller config UI)
    # ------------------------------------------------------------------

    def testConnection(self, valuesDict, typeId="", devId=0):
        """Test each enabled API path independently and report results."""
        try:
            address     = valuesDict.get("address", "").strip()
            port        = int(valuesDict.get("port", DEFAULT_HTTPS_PORT) or DEFAULT_HTTPS_PORT)
            access_port = int(valuesDict.get("accessPort", DEFAULT_ACCESS_PORT) or DEFAULT_ACCESS_PORT)
            verify_ssl  = bool(valuesDict.get("verifySSL", False))
            site        = valuesDict.get("site", "default") or "default"

            net_key     = valuesDict.get("networkApiKey", "").strip()
            # Protect uses the same key as Network (unified Integrations page)
            protect_key = net_key
            # Access uses a separate token generated inside the Access app itself
            access_key  = valuesDict.get("accessApiKey", "").strip()
            user        = valuesDict.get("legacyUsername", "").strip()
            pwd         = valuesDict.get("legacyPassword", "")

            if not address:
                self.logger.error("Test failed: Controller address is empty")
                return valuesDict

            self.logger.info(f"=== Testing connection to {address}:{port} ===")

            # Network Integration
            if net_key:
                try:
                    net = UnifiNetworkAPI(address, port, net_key, "", "",
                                          site=site, verify_ssl=verify_ssl,
                                          logger=self.logger, debug=self.debug)
                    net.test_integration()
                    self.logger.info("✓ Network Integration API: OK")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ Network Integration API: auth failed - {e}")
                except Exception as e:
                    self.logger.warning(f"✗ Network Integration API: {e}")
            else:
                self.logger.info("- Network Integration API: skipped (no key)")

            # Network Legacy
            if user and pwd:
                try:
                    net = UnifiNetworkAPI(address, port, "", user, pwd,
                                          site=site, verify_ssl=verify_ssl,
                                          logger=self.logger, debug=self.debug)
                    net.test_legacy()
                    self.logger.info("✓ Network Legacy auth: OK")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ Network Legacy auth: {e}")
                except Exception as e:
                    self.logger.warning(f"✗ Network Legacy auth: {e}")
            else:
                self.logger.info("- Network Legacy auth: skipped (no username/password)")

            # Protect (uses the shared API key)
            if protect_key:
                try:
                    p = UnifiProtectAPI(address, port, protect_key,
                                        verify_ssl=verify_ssl,
                                        logger=self.logger, debug=self.debug)
                    p.test_connection()
                    p.refresh_cache()
                    self.logger.info(f"✓ Protect API: OK ({len(p.get_cameras())} cameras, "
                                     f"{len(p.get_sensors())} sensors)")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ Protect API: auth failed - {e}")
                except Exception as e:
                    self.logger.warning(f"✗ Protect API: {e}")
            else:
                self.logger.info("- Protect API: skipped (no key)")

            # Access (uses a separate token generated inside the Access app,
            # not the unified Integrations page; Bearer auth on port 12445)
            if access_key:
                try:
                    a = UnifiAccessAPI(address, access_port, access_key,
                                       verify_ssl=verify_ssl,
                                       logger=self.logger, debug=self.debug)
                    doors = a.get_doors()
                    self.logger.info(f"✓ Access API: OK ({len(doors)} doors on port {access_port})")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ Access API: auth failed - {e}")
                except Exception as e:
                    self.logger.warning(f"✗ Access API: {e}")
            else:
                self.logger.info("- Access API: skipped (no token)")

            self.logger.info("=== Test complete ===")
            return valuesDict
        except Exception as e:
            self.logger.error(f"Test error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return valuesDict

    def testDriveConnection(self, valuesDict, typeId="", devId=0):
        """Test the UNAS connection from the Drive controller config UI."""
        try:
            address    = valuesDict.get("address", "").strip()
            try:
                port = int(valuesDict.get("port", DEFAULT_HTTPS_PORT) or DEFAULT_HTTPS_PORT)
            except (TypeError, ValueError):
                port = DEFAULT_HTTPS_PORT
            verify_ssl = bool(valuesDict.get("verifySSL", False))
            api_key    = valuesDict.get("driveApiKey", "").strip()
            user       = valuesDict.get("legacyUsername", "").strip()
            pwd        = valuesDict.get("legacyPassword", "")

            if not address:
                self.logger.error("UNAS test failed: address is empty")
                return valuesDict

            self.logger.info(f"=== Testing UNAS connection to {address}:{port} ===")

            if api_key:
                try:
                    d = UnifiDriveAPI(address, port, api_key=api_key,
                                      verify_ssl=verify_ssl,
                                      logger=self.logger, debug=self.debug)
                    d.test_connection()
                    self.logger.info("✓ UNAS API key auth: OK")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ UNAS API key auth failed: {e}")
                except Exception as e:
                    self.logger.warning(f"✗ UNAS API key auth: {e}")
            else:
                self.logger.info("- UNAS API key: skipped (no key configured)")

            if user and pwd:
                try:
                    d = UnifiDriveAPI(address, port, api_key="",
                                      username=user, password=pwd,
                                      verify_ssl=verify_ssl,
                                      logger=self.logger, debug=self.debug)
                    d.test_connection()
                    self.logger.info("✓ UNAS legacy auth: OK")
                except UnifiAuthError as e:
                    self.logger.error(f"✗ UNAS legacy auth failed: {e}")
                except Exception as e:
                    self.logger.warning(f"✗ UNAS legacy auth: {e}")
            else:
                self.logger.info("- UNAS legacy auth: skipped (no username/password)")

            self.logger.info("=== UNAS test complete ===")
            return valuesDict
        except Exception as e:
            self.logger.error(f"UNAS test error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
            return valuesDict

    # ------------------------------------------------------------------
    # Helpers for trigger / action UI lists
    # ------------------------------------------------------------------

    def getControllerList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of controller devices for action/event UI menus."""
        out = []
        for d in indigo.devices.iter("self.unifiController"):
            out.append((str(d.id), d.name))
        return out

    def getDriveControllerList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Return list of UNAS Drive controller devices."""
        out = []
        for d in indigo.devices.iter("self.unifiDriveController"):
            out.append((str(d.id), d.name))
        return out

    def getCameraList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Camera")]
        for d in indigo.devices.iter("self.protectCamera"):
            out.append((str(d.id), d.name))
        return out

    def getSensorList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Sensor")]
        for d in indigo.devices.iter("self.protectSensor"):
            out.append((str(d.id), d.name))
        return out

    def getNetworkDeviceList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Device")]
        for d in indigo.devices.iter("self.networkDevice"):
            out.append((str(d.id), d.name))
        return out

    def getPortDeviceList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Port")]
        for d in indigo.devices.iter("self.unifiPort"):
            out.append((str(d.id), d.name))
        return out

    def getClientList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Client")]
        for d in indigo.devices.iter("self.clientDevice"):
            out.append((str(d.id), d.name))
        return out

    def getDoorList(self, filter="", valuesDict=None, typeId="", targetId=0):
        out = [("", "Any Door")]
        for d in indigo.devices.iter("self.accessDoor"):
            out.append((str(d.id), d.name))
        return out

    def getPortList(self, filter="", valuesDict=None, typeId="", targetId=0):
        """Port number list, populated based on the selected parent switch."""
        ports = []
        parent_id = valuesDict.get("parentDevice") if valuesDict else None
        if not parent_id:
            return [("0", "Select a switch first")]
        try:
            parent = indigo.devices[int(parent_id)]
            count = int(parent.states.get("portCount", 0) or 0)
            if count <= 0:
                return [("0", "No ports available")]
            for n in range(1, count + 1):
                ports.append((str(n), f"Port {n}"))
        except Exception:
            return [("0", "Error loading ports")]
        return ports

    # ------------------------------------------------------------------
    # Discovery: create camera, sensor, network, port, client, door,
    # drive, fan devices
    # ------------------------------------------------------------------

    def _affix_name(self, base_name, valuesDict):
        """Wrap a discovered base name with the optional prefix and suffix
        from the controller config UI. Both default to empty."""
        prefix = (valuesDict.get("deviceNamePrefix", "") or "") if valuesDict else ""
        suffix = (valuesDict.get("deviceNameSuffix", "") or "") if valuesDict else ""
        return f"{prefix}{base_name}{suffix}"

    def _create_or_skip(self, name, type_id, props, folder=None):
        """Create a device if not already present (matched by props), return new device."""
        # Test for an existing device with the same key prop
        key_pairs = []
        if "cameraId" in props:
            key_pairs = [("cameraId", props["cameraId"])]
        elif "sensorId" in props:
            key_pairs = [("sensorId", props["sensorId"])]
        elif "doorId" in props:
            key_pairs = [("doorId", props["doorId"])]
        elif "deviceMac" in props and "portNumber" in props:
            key_pairs = [("deviceMac", props["deviceMac"]),
                         ("portNumber", str(props["portNumber"]))]
        elif "deviceMac" in props:
            key_pairs = [("deviceMac", props["deviceMac"])]
        elif "clientMac" in props:
            key_pairs = [("clientMac", props["clientMac"])]
        elif "diskKey" in props:
            key_pairs = [("diskKey", props["diskKey"])]
        elif "poolKey" in props:
            key_pairs = [("poolKey", props["poolKey"])]

        # If we have no key to match on, fall back to matching by name within
        # the same type — at worst this causes a duplicate-name collision the
        # user can rename, rather than silently swallowing all subsequent
        # devices of the same type (the bug this guards against).
        if not key_pairs:
            for d in indigo.devices.iter("self"):
                if d.deviceTypeId == type_id and d.name == name:
                    return None

        for d in indigo.devices.iter("self"):
            if d.deviceTypeId != type_id:
                continue
            if not key_pairs:
                continue
            match = all(str(d.pluginProps.get(k, "")) == str(v) for k, v in key_pairs)
            if match:
                return None  # already exists

        kwargs = dict(
            protocol    = indigo.kProtocol.Plugin,
            address     = "",
            deviceTypeId= type_id,
            name        = name,
            props       = props,
        )
        if folder:
            try:
                folder_id = indigo.devices.folder.create(folder).id if folder not in indigo.devices.folders else indigo.devices.folders[folder].id
                kwargs["folder"] = folder_id
            except Exception:
                pass
        return indigo.device.create(**kwargs)

    def createCameraDevices(self, valuesDict, typeId, devId):
        """Discover cameras and create devices."""
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "protect_api" not in controller:
                self.logger.error("Cannot discover cameras: Protect not connected on controller")
                return valuesDict
            cameras = controller["protect_api"].get_cameras()
            created = 0
            for cam in cameras:
                name = cam.get("name") or cam.get("marketName") or "Camera"
                props = {
                    "controllerId": str(controller_id),
                    "cameraId":     cam.get("id", ""),
                    "cameraName":   name,
                }
                full_name = self._affix_name(name, valuesDict)
                new_dev = self._create_or_skip(full_name, "protectCamera", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created camera device: {new_dev.name}")
            self.logger.info(f"Camera discovery: {created} new device(s) created, {len(cameras)} total")
        except Exception as e:
            self.logger.error(f"Error discovering cameras: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        return valuesDict

    def createSensorDevices(self, valuesDict, typeId, devId):
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "protect_api" not in controller:
                self.logger.error("Cannot discover sensors: Protect not connected")
                return valuesDict
            sensors = controller["protect_api"].get_sensors()
            created = 0
            for s in sensors:
                name = s.get("name") or "Sensor"
                props = {
                    "controllerId": str(controller_id),
                    "sensorId":     s.get("id", ""),
                    "sensorName":   name,
                }
                full_name = self._affix_name(name, valuesDict)
                new_dev = self._create_or_skip(full_name, "protectSensor", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created sensor device: {new_dev.name}")
            self.logger.info(f"Sensor discovery: {created} new device(s) created, {len(sensors)} total")
        except Exception as e:
            self.logger.error(f"Error discovering sensors: {e}")
        return valuesDict

    def createNetworkDevices(self, valuesDict, typeId, devId):
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "network_api" not in controller:
                self.logger.error("Cannot discover network devices: Network not connected")
                return valuesDict
            devices = controller["network_api"].get_devices()
            created = 0
            for d in devices:
                name = d.get("name") or d.get("model") or d.get("mac")
                props = {
                    "controllerId": str(controller_id),
                    "deviceMac":    d.get("mac", "").lower(),
                    "deviceName":   name,
                }
                full_name = self._affix_name(name, valuesDict)
                new_dev = self._create_or_skip(full_name, "networkDevice", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created network device: {new_dev.name}")
            self.logger.info(f"Network discovery: {created} new device(s) created, {len(devices)} total")
        except Exception as e:
            self.logger.error(f"Error discovering network devices: {e}")
        return valuesDict

    def createPortDevices(self, valuesDict, typeId, devId):
        """Create devices for ports of a switch."""
        try:
            controller_id = int(valuesDict.get("controllerId", 0))
            parent_id     = int(valuesDict.get("parentDevice", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "network_api" not in controller:
                self.logger.error("Cannot discover ports: Network not connected")
                return valuesDict
            if parent_id not in indigo.devices:
                self.logger.error("Parent switch device not found")
                return valuesDict
            parent = indigo.devices[parent_id]
            mac = parent.pluginProps.get("deviceMac", "").lower()
            d   = controller["network_api"].get_device(mac)
            if not d:
                self.logger.error("Could not find parent switch on controller")
                return valuesDict
            ports = d.get("port_table") or []
            created = 0
            for p in ports:
                pidx     = p.get("port_idx")
                pname    = p.get("name") or f"Port {pidx}"
                props = {
                    "controllerId":   str(controller_id),
                    "parentDevice":   str(parent_id),
                    "deviceMac":      mac,
                    "portNumber":     str(pidx),
                    "controlMode":    "poe",
                }
                new_dev = self._create_or_skip(
                    self._affix_name(f"{parent.name} - {pname}", valuesDict),
                    "unifiPort", props)
                if new_dev:
                    created += 1
            self.logger.info(f"Port discovery: {created} new device(s) created on {parent.name}")
        except Exception as e:
            self.logger.error(f"Error discovering ports: {e}")
        return valuesDict

    def createAccessDoors(self, valuesDict, typeId, devId):
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "access_api" not in controller:
                self.logger.error("Cannot discover doors: Access not connected")
                return valuesDict
            doors = controller["access_api"].get_doors()
            created = 0
            for door in doors:
                name = door.get("name", "Door")
                props = {
                    "controllerId": str(controller_id),
                    "doorId":       door.get("id", ""),
                    "doorName":     name,
                }
                new_dev = self._create_or_skip(self._affix_name(name, valuesDict), "accessDoor", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created door device: {new_dev.name}")
            self.logger.info(f"Door discovery: {created} new device(s) created, {len(doors)} total")
        except Exception as e:
            self.logger.error(f"Error discovering doors: {e}")
        return valuesDict

    def createFanDevice(self, valuesDict, typeId, devId):
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "drive_api" not in controller:
                self.logger.error("Cannot create Fan device: Drive not connected")
                return valuesDict
            props = {"controllerId": str(controller_id)}
            new_dev = self._create_or_skip(
                self._affix_name("UNAS Fan", valuesDict),
                "driveFan", props)
            if new_dev:
                self.logger.info(f"Created Fan device: {new_dev.name}")
            else:
                self.logger.info("Fan device already exists")
        except Exception as e:
            self.logger.error(f"Error creating Fan device: {e}")
        return valuesDict

    def _ssh_from_valuesDict(self, valuesDict, controller, dev_for_log=None):
        """Build a one-shot SSH client from the values currently in the config
        UI (which may not yet have been saved). Falls back to the running
        controller's SSH client when the dialog is being run after save.

        Returns (ssh, address, error_message_or_None). On error, ssh is None.
        """
        # Use the configured address from valuesDict (matches the rest of the
        # dialog state). If empty, fall back to the running controller.
        address = (valuesDict.get("address", "") or "").strip()
        if not address and controller:
            address = controller.get("address", "")
        if not address:
            return None, "", "No address configured for UNAS"

        if not bool(valuesDict.get("sshEnabled", False)):
            return None, address, "SSH fan control is not enabled (tick the checkbox)"

        ssh_user = (valuesDict.get("sshUsername", "") or "").strip()
        ssh_pass = valuesDict.get("sshPassword", "") or ""
        try:
            ssh_port = int(valuesDict.get("sshPort", "22") or "22")
        except (TypeError, ValueError):
            ssh_port = 22

        if not ssh_user or not ssh_pass:
            return None, address, "SSH username/password not provided"

        ssh = UnifiDriveSSH(
            address, ssh_port, ssh_user, ssh_pass,
            logger=self.logger, debug=self.debug,
        )
        return ssh, address, None

    def testFanControl(self, valuesDict, typeId, devId):
        """Run a diagnostic against the deployed fan control service. Useful
        when fans aren't actually changing despite SSH writes succeeding."""
        ssh = None
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)

            ssh, address, err = self._ssh_from_valuesDict(valuesDict, controller)
            if err:
                self.logger.error(f"Cannot run fan diagnostic: {err}")
                return valuesDict

            dev = controller.get("device") if controller else None
            name = dev.name if dev else f"UNAS at {address}"

            if not ssh.is_deployed():
                self.logger.error(
                    f"{name}: Fan control service is not deployed. "
                    f"Click 'Install/Update Fan Control on UNAS' first."
                )
                return valuesDict

            self.logger.info(f"{name}: Running fan control diagnostic…")
            output = ssh.run_diagnostic()
            self.logger.info(f"{name}: Fan control diagnostic results follow:\n{output}")
        except UnifiSSHError as e:
            self.logger.error(f"Fan control diagnostic failed: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error running fan diagnostic: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        finally:
            if ssh is not None:
                try: ssh.close()
                except Exception: pass
        return valuesDict

    def deployFanControl(self, valuesDict, typeId, devId):
        """Install the fan control script + systemd service on the UNAS over
        SSH. Builds an SSH client from the values currently in the config
        dialog so the user doesn't need to save first."""
        ssh = None
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)

            ssh, address, err = self._ssh_from_valuesDict(valuesDict, controller)
            if err:
                self.logger.error(f"Cannot deploy fan control: {err}")
                return valuesDict
            if not self.fan_script_content or not self.fan_service_content:
                self.logger.error(
                    "Cannot deploy fan control: bundled script/service assets are missing from the plugin."
                )
                return valuesDict

            dev = controller.get("device") if controller else None
            name = dev.name if dev else f"UNAS at {address}"
            self.logger.info(f"{name}: Deploying fan control to UNAS via SSH…")
            ssh.deploy_fan_control(self.fan_script_content, self.fan_service_content)

            # Verify the service ended up running and report what we deployed
            service_status = ssh.get_service_status()
            active_mode    = ssh.get_active_mode()
            self.logger.info(
                f"{name}: Fan control deployed. "
                f"Service: {service_status}, current mode: {active_mode}"
            )
            if service_status != "active":
                self.logger.warning(
                    f"{name}: Fan control service is '{service_status}' — "
                    f"check the UNAS systemd logs with: "
                    f"journalctl -u indigo_fan_control.service -n 50"
                )

            if dev is not None:
                try:
                    dev.updateStatesOnServer([
                        {"key": "fanControlDeployed",   "value": True},
                        {"key": "fanControlActiveMode", "value": active_mode},
                    ])
                except Exception:
                    pass
        except UnifiSSHError as e:
            self.logger.error(f"Fan control deploy failed: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error deploying fan control: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        finally:
            if ssh is not None:
                try: ssh.close()
                except Exception: pass
        return valuesDict

    def removeFanControl(self, valuesDict, typeId, devId):
        """Stop and remove the fan control service from the UNAS. Builds an
        SSH client from the values currently in the config dialog."""
        ssh = None
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)

            ssh, address, err = self._ssh_from_valuesDict(valuesDict, controller)
            if err:
                self.logger.error(f"Cannot remove fan control: {err}")
                return valuesDict

            dev = controller.get("device") if controller else None
            name = dev.name if dev else f"UNAS at {address}"
            self.logger.info(f"{name}: Removing fan control from UNAS via SSH…")
            ssh.remove_fan_control()
            self.logger.info(f"{name}: Fan control removed. UNAS firmware now manages fans.")
            if dev is not None:
                try:
                    dev.updateStatesOnServer([
                        {"key": "fanControlDeployed",   "value": False},
                        {"key": "fanControlActiveMode", "value": ""},
                    ])
                except Exception:
                    pass
        except UnifiSSHError as e:
            self.logger.error(f"Fan control removal failed: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error removing fan control: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        finally:
            if ssh is not None:
                try: ssh.close()
                except Exception: pass
        return valuesDict

    def createDrivePools(self, valuesDict, typeId, devId):
        """Discover storage pools on the UNAS and create devices for each."""
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "drive_api" not in controller:
                self.logger.error("Cannot discover pools: Drive not connected")
                return valuesDict

            # Refresh the cached storage payload so we have current pool data
            try:
                storage = controller["drive_api"].get_storage_info() or {}
                controller["last_storage"] = storage
            except Exception as e:
                self.logger.error(f"Pool discovery: storage fetch failed: {e}")
                return valuesDict

            pools = _drive_extract_pools(storage)
            if not pools:
                self.logger.warning("Pool discovery: no pools found in storage payload")
                return valuesDict

            created = 0
            for idx, pool in enumerate(pools):
                pkey = _drive_pool_key(pool, idx)
                pname = _drive_pool_name(pool, idx)
                props = {
                    "controllerId": str(controller_id),
                    "poolKey":      pkey,
                }
                full_name = self._affix_name(f"UNAS Pool {pname}", valuesDict)
                new_dev = self._create_or_skip(full_name, "unifiDrivePool", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created pool device: {new_dev.name}")
            self.logger.info(f"Pool discovery: {created} new device(s) created, {len(pools)} total")
        except Exception as e:
            self.logger.error(f"Error discovering pools: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        return valuesDict

    def createDriveDisks(self, valuesDict, typeId, devId):
        """Discover all physical disks and create devices for each. Disks live
        at the top of the storage payload; their `poolId` field links each to
        its parent pool."""
        try:
            controller_id = int(devId or valuesDict.get("controllerId", 0))
            controller    = self.controllers.get(controller_id)
            if not controller or "drive_api" not in controller:
                self.logger.error("Cannot discover disks: Drive not connected")
                return valuesDict

            try:
                storage = controller["drive_api"].get_storage_info() or {}
                controller["last_storage"] = storage
            except Exception as e:
                self.logger.error(f"Disk discovery: storage fetch failed: {e}")
                return valuesDict

            disks = _drive_extract_disks(storage)
            if not disks:
                self.logger.warning("Disk discovery: no disks found in storage payload")
                return valuesDict

            # Build a pool_id -> (pool, index) lookup so we can put each disk's
            # parent pool name in the display name.
            pools = _drive_extract_pools(storage)
            pool_lookup = {}
            for pidx, pool in enumerate(pools):
                for id_field in ("id", "guid", "poolGuid", "uuid"):
                    pid = pool.get(id_field)
                    if pid:
                        pool_lookup[pid] = (pool, pidx)
                        break

            created = 0
            for didx, disk in enumerate(disks):
                dkey = _drive_disk_key(disk, didx)
                pool_id  = disk.get("poolId") or disk.get("pool_id") or disk.get("poolGuid")
                pool, pidx = pool_lookup.get(pool_id, (None, 0))
                pname = _drive_pool_name(pool, pidx) if pool else "Pool"
                dname = _drive_disk_name(disk, didx, pidx)
                props = {
                    "controllerId": str(controller_id),
                    "diskKey":      dkey,
                }
                full_name = self._affix_name(f"UNAS Disk {pname} {dname}", valuesDict)
                new_dev = self._create_or_skip(full_name, "unifiDriveDisk", props)
                if new_dev:
                    created += 1
                    self.logger.info(f"Created disk device: {new_dev.name}")
            self.logger.info(f"Disk discovery: {created} new device(s) created, {len(disks)} total")
        except Exception as e:
            self.logger.error(f"Error discovering disks: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())
        return valuesDict

    # ------------------------------------------------------------------
    # Helpers for action handlers
    # ------------------------------------------------------------------

    def _get_controller_for_dev(self, dev):
        try:
            cid = int(dev.pluginProps.get("controllerId", 0))
        except (TypeError, ValueError):
            return None, None
        return cid, self.controllers.get(cid)

    def _get_camera_api(self, dev):
        cid, controller = self._get_controller_for_dev(dev)
        if not controller or "protect_api" not in controller:
            self.logger.error(f"{dev.name}: Protect API not available")
            return None, None, None
        camera_id = dev.pluginProps.get("cameraId", "")
        return cid, camera_id, controller["protect_api"]

    # ------------------------------------------------------------------
    # Camera actions
    # ------------------------------------------------------------------

    def actionSetRecordingMode(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            mode = action.props.get("recordingMode", "always")
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            self.logger.info(f"{dev.name}: Setting recording mode to {mode}")
            api.update_camera(cam_id, {"recordingSettings": {"mode": mode}})
            self._update_camera_states(cid, cam_id)
        except Exception as e:
            self.logger.error(f"setRecordingMode error: {e}")

    def actionSetIRMode(self, action):
        try:
            dev  = indigo.devices[action.deviceId]
            mode = action.props.get("irMode", "auto")
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            self.logger.info(f"{dev.name}: Setting IR mode to {mode}")
            api.update_camera(cam_id, {"ispSettings": {"irLedMode": mode}})
            self._update_camera_states(cid, cam_id)
        except Exception as e:
            self.logger.error(f"setIRMode error: {e}")

    def actionSetStatusLight(self, action):
        try:
            dev     = indigo.devices[action.deviceId]
            enabled = bool(action.props.get("enabled", True))
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            self.logger.info(f"{dev.name}: Setting status light to {enabled}")
            api.update_camera(cam_id, {"ledSettings": {"isEnabled": enabled}})
            self._update_camera_states(cid, cam_id)
        except Exception as e:
            self.logger.error(f"setStatusLight error: {e}")

    def actionSetOverlays(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            settings = {"osdSettings": {
                "isNameEnabled": bool(action.props.get("showName", True)),
                "isDateEnabled": bool(action.props.get("showDate", True)),
                "isLogoEnabled": bool(action.props.get("showLogo", False)),
            }}
            self.logger.info(f"{dev.name}: Setting overlays")
            api.update_camera(cam_id, settings)
            self._update_camera_states(cid, cam_id)
        except Exception as e:
            self.logger.error(f"setOverlays error: {e}")

    def actionSetStatusMessage(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            api.update_camera(cam_id, {"lcdMessage": {"text": action.props.get("message", "")}})
        except Exception as e:
            self.logger.error(f"setStatusMessage error: {e}")

    def actionEnableDetections(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            api.update_camera(cam_id, {"recordingSettings":
                                       {"enableMotionDetection": bool(action.props.get("motion", True))}})
            self._update_camera_states(cid, cam_id)
        except Exception as e:
            self.logger.error(f"enableDetections error: {e}")

    def actionRebootCamera(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            self.logger.info(f"{dev.name}: Rebooting camera")
            api.reboot_camera(cam_id)
        except Exception as e:
            self.logger.error(f"rebootCamera error: {e}")

    def actionTakeSnapshot(self, action):
        """Fetch a snapshot via the integration API and optionally save to disk."""
        try:
            dev = indigo.devices[action.deviceId]
            cid, cam_id, api = self._get_camera_api(dev)
            if not api:
                return
            save_path = action.props.get("savePath", "").strip()
            if not save_path:
                self.logger.warning(f"{dev.name}: No save path specified for snapshot")
                return

            url = api.get_camera_snapshot_url(cam_id)
            req = urllib.request.Request(url, method="GET")
            req.add_header("Authorization", f"Bearer {api.api_key}")
            with api.opener.open(req, timeout=30) as response:
                data = response.read()
            with open(save_path, "wb") as f:
                f.write(data)
            self.logger.info(f"{dev.name}: Snapshot saved to {save_path}")
        except Exception as e:
            self.logger.error(f"takeSnapshot error: {e}")

    # ------------------------------------------------------------------
    # Network device actions
    # ------------------------------------------------------------------

    def actionRestartDevice(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("deviceMac", "")
            self.logger.info(f"{dev.name}: Restarting")
            controller["network_api"].restart_device(mac)
        except Exception as e:
            self.logger.error(f"restartDevice error: {e}")

    def actionSetDeviceLED(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("deviceMac", "")
            d = controller["network_api"].get_device(mac)
            if not d:
                return
            enabled = bool(action.props.get("enabled", True))
            controller["network_api"].set_device_led(d["_id"], enabled)
            self._update_netdev_states(cid, mac)
        except Exception as e:
            self.logger.error(f"setDeviceLED error: {e}")

    def actionLocateDevice(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("deviceMac", "")
            enabled = bool(action.props.get("enabled", True))
            controller["network_api"].locate_device(mac, enabled)
            self.logger.info(f"{dev.name}: Locate {'on' if enabled else 'off'}")
        except Exception as e:
            self.logger.error(f"locateDevice error: {e}")

    # ------------------------------------------------------------------
    # Client actions
    # ------------------------------------------------------------------

    def actionBlockClient(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("clientMac", "")
            controller["network_api"].block_client(mac)
            self.logger.info(f"{dev.name}: Blocked")
            self._update_client_states(cid, mac.lower())
        except Exception as e:
            self.logger.error(f"blockClient error: {e}")

    def actionUnblockClient(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("clientMac", "")
            controller["network_api"].unblock_client(mac)
            self.logger.info(f"{dev.name}: Unblocked")
            self._update_client_states(cid, mac.lower())
        except Exception as e:
            self.logger.error(f"unblockClient error: {e}")

    def actionReconnectClient(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            mac = dev.pluginProps.get("clientMac", "")
            controller["network_api"].reconnect_client(mac)
            self.logger.info(f"{dev.name}: Reconnect requested")
        except Exception as e:
            self.logger.error(f"reconnectClient error: {e}")

    # ------------------------------------------------------------------
    # Door action
    # ------------------------------------------------------------------

    def actionUnlockDoor(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "access_api" not in controller:
                return
            door_id = dev.pluginProps.get("doorId", "")
            controller["access_api"].unlock_door(door_id)
            self.logger.info(f"{dev.name}: Unlocked")
            self._update_door_states(cid, door_id)
        except Exception as e:
            self.logger.error(f"unlockDoor error: {e}")

    # ------------------------------------------------------------------
    # Drive (UNAS) actions — these target the unifiDriveController device
    # directly, since all UNAS state now lives on the controller itself.
    # ------------------------------------------------------------------

    def _get_drive_controller(self, action):
        """Resolve action.deviceId -> (controller_id, controller_dict, device).
        Returns (None, None, None) if not a connected Drive controller."""
        try:
            dev = indigo.devices[action.deviceId]
        except Exception:
            return None, None, None
        controller = self.controllers.get(dev.id)
        if not controller or "drive_api" not in controller:
            return None, None, dev
        return dev.id, controller, dev

    def actionRebootUNAS(self, action):
        cid, controller, dev = self._get_drive_controller(action)
        if not controller:
            name = dev.name if dev else f"device {action.deviceId}"
            self.logger.error(f"{name}: Cannot reboot — UNAS not connected")
            return
        try:
            controller["drive_api"].reboot()
            self.logger.info(f"{dev.name}: Reboot command sent")
            try:
                dev.updateStateOnServer("status", "Rebooting…")
            except Exception:
                pass
        except UnifiAuthError as e:
            self.logger.error(f"rebootUNAS auth error: {e}")
        except Exception as e:
            self.logger.error(f"rebootUNAS error: {e}")

    def actionShutdownUNAS(self, action):
        cid, controller, dev = self._get_drive_controller(action)
        if not controller:
            name = dev.name if dev else f"device {action.deviceId}"
            self.logger.error(f"{name}: Cannot shutdown — UNAS not connected")
            return
        try:
            controller["drive_api"].shutdown()
            self.logger.info(f"{dev.name}: Shutdown command sent")
            try:
                dev.updateStateOnServer("status", "Shutting down…")
            except Exception:
                pass
        except UnifiAuthError as e:
            self.logger.error(f"shutdownUNAS auth error: {e}")
        except Exception as e:
            self.logger.error(f"shutdownUNAS error: {e}")

    def _apply_fan_mode(self, controller_id, controller, canonical_mode, dev_for_log=None):
        """Apply a fan mode. Prefers SSH (if deployed and active) over REST
        (which is read-only on current UNAS firmware).

        Returns ("ssh"|"api", success_bool, error_message_or_None).
        """
        log_name = dev_for_log.name if dev_for_log is not None else "fan"
        canonical_mode_lower = canonical_mode.lower()

        # Prefer SSH if the fan control service is deployed
        ssh = controller.get("drive_ssh") if controller else None
        if ssh is not None:
            try:
                if ssh.is_deployed():
                    # Map our canonical names (Quiet/Balance/Cooling) to the
                    # script's lowercase mode tokens. "Default" is also a valid
                    # value that hands control back to firmware.
                    ssh_mode = {
                        "quiet":   "quiet",
                        "balance": "balance",
                        "cooling": "cooling",
                        "default": "default",
                    }.get(canonical_mode_lower, canonical_mode_lower)
                    ssh.set_mode(ssh_mode)
                    self.logger.info(f"{log_name}: Fan mode set via SSH to {ssh_mode}")
                    # Update deployment-state cache on the controller device
                    cdev = controller.get("device")
                    if cdev is not None:
                        try:
                            cdev.updateStateOnServer("fanControlActiveMode", ssh_mode)
                        except Exception:
                            pass
                    return ("ssh", True, None)
                else:
                    if self.debug:
                        self.logger.debug(
                            f"{log_name}: SSH configured but fan control not deployed — "
                            f"falling through to REST API (which is read-only on current firmware)"
                        )
            except UnifiSSHError as e:
                self.logger.error(f"{log_name}: SSH fan mode set failed: {e}")
                # Don't fall through to API — SSH is the intended path. Surface error.
                return ("ssh", False, str(e))

        # Fallback: REST API (will fail on current firmware but try anyway)
        api = controller.get("drive_api") if controller else None
        if api is None:
            return ("api", False, "Drive API not available")
        try:
            api.set_fan_mode(canonical_mode)
            self.logger.info(f"{log_name}: Fan mode set via REST to {canonical_mode}")
            return ("api", True, None)
        except Exception as e:
            return ("api", False, str(e))

    def actionSetFanMode(self, action):
        """Set fan mode. This action targets a driveFan device, not the controller —
        the fan is still a separate child device."""
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller:
                self.logger.error(f"{dev.name}: Cannot set fan mode — UNAS not connected")
                return
            mode = action.props.get("fanMode", "Balance")
            if mode not in DRIVE_FAN_MODE_OPTIONS:
                self.logger.error(f"{dev.name}: Unknown fan mode: {mode}")
                return
            method, ok, err = self._apply_fan_mode(cid, controller, mode, dev_for_log=dev)
            if not ok:
                self.logger.error(f"{dev.name}: Fan mode set FAILED via {method}: {err}")
                return
            self._update_fan_states(cid)
        except Exception as e:
            self.logger.error(f"setFanMode error: {e}")

    def actionWakeUNAS(self, action):
        """Send a Wake-on-LAN magic packet to the UNAS using its MAC."""
        cid, controller, dev = self._get_drive_controller(action)
        if not controller:
            name = dev.name if dev else f"device {action.deviceId}"
            self.logger.error(f"{name}: Cannot wake — no controller")
            return
        try:
            # Use the cached MAC from controller states if available
            mac = dev.states.get("macAddress") or ""
            if not mac:
                self.logger.error(f"{dev.name}: Cannot wake — no MAC address known. "
                                  f"The system info doesn't expose a MAC; you may need to set it manually.")
                return

            # Normalise: strip separators, lowercase
            mac_hex = "".join(c for c in mac if c.isalnum()).lower()
            if len(mac_hex) != 12:
                self.logger.error(f"{dev.name}: MAC '{mac}' is not a valid 6-byte address")
                return

            try:
                mac_bytes = bytes.fromhex(mac_hex)
            except ValueError:
                self.logger.error(f"{dev.name}: MAC '{mac}' could not be parsed as hex")
                return

            magic = b"\xff" * 6 + mac_bytes * 16

            # Send on UDP port 9 to both the broadcast address and the UNAS's IP
            # (covers most network setups).
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                for target in ("255.255.255.255", "<broadcast>"):
                    try:
                        sock.sendto(magic, (target, 9))
                    except Exception:
                        pass
                # Also try the UNAS IP directly (in case router blocks broadcast)
                address = controller.get("address")
                if address:
                    try:
                        sock.sendto(magic, (address, 9))
                    except Exception:
                        pass
            finally:
                sock.close()

            self.logger.info(f"{dev.name}: Wake-on-LAN magic packet sent to {mac}")
        except Exception as e:
            self.logger.error(f"wakeUNAS error: {e}")

    # ------------------------------------------------------------------
    # Relay / Dimmer control (called by Indigo when user toggles on/off)
    # ------------------------------------------------------------------

    def actionControlDevice(self, action, dev):
        """Handle relay (on/off) actions for ports, clients, network devices, doors.
        Dimmer devices (driveFan) are delegated to actionControlDimmerRelay."""
        try:
            # Dimmer devices use a different action namespace
            # (kDimmerRelayAction.*) than relays. Indigo routes BOTH through
            # this method when the plugin defines actionControlDevice, so
            # delegate dimmer types to the dimmer handler.
            if dev.deviceTypeId == "driveFan":
                return self.actionControlDimmerRelay(action, dev)

            cmd = action.deviceAction
            type_id = dev.deviceTypeId

            # Helper to determine on/off
            def is_on():
                if cmd == indigo.kDeviceAction.TurnOn:
                    return True
                if cmd == indigo.kDeviceAction.TurnOff:
                    return False
                if cmd == indigo.kDeviceAction.Toggle:
                    return not dev.onState
                return None

            target = is_on()
            if target is None:
                return

            cid, controller = self._get_controller_for_dev(dev)
            if not controller:
                return

            if type_id == "unifiPort":
                api = controller.get("network_api")
                if not api:
                    return
                control_mode = dev.pluginProps.get("controlMode", "poe")
                mac = dev.pluginProps.get("deviceMac", "")
                try:
                    pidx = int(dev.pluginProps.get("portNumber", 0))
                except (TypeError, ValueError):
                    return
                d = api.get_device(mac)
                if not d:
                    return
                if control_mode == "poe":
                    api.set_port_poe_mode(d["_id"], pidx, "auto" if target else "off")
                    self.logger.info(f"{dev.name}: PoE {'on' if target else 'off'}")
                elif control_mode == "powercycle":
                    if target:
                        api.cycle_port_poe(mac, pidx)
                        self.logger.info(f"{dev.name}: Power-cycled")
                    # off has no meaning for powercycle; ignore
                self._update_port_states(cid, mac, pidx)

            elif type_id == "clientDevice":
                api = controller.get("network_api")
                if not api:
                    return
                mac = dev.pluginProps.get("clientMac", "")
                if target:
                    api.unblock_client(mac)
                else:
                    api.block_client(mac)
                self.logger.info(f"{dev.name}: {'Unblocked' if target else 'Blocked'}")
                self._update_client_states(cid, mac.lower())

            elif type_id == "networkDevice":
                api = controller.get("network_api")
                if not api:
                    return
                mac = dev.pluginProps.get("deviceMac", "")
                d = api.get_device(mac)
                if not d:
                    return
                api.disable_device(d["_id"], disabled=not target)
                self.logger.info(f"{dev.name}: {'Enabled' if target else 'Disabled'}")
                self._update_netdev_states(cid, mac)

            elif type_id == "accessDoor":
                api = controller.get("access_api")
                if not api:
                    return
                if target:  # turning "on" = unlock
                    door_id = dev.pluginProps.get("doorId", "")
                    api.unlock_door(door_id)
                    self.logger.info(f"{dev.name}: Unlocked")
                    self._update_door_states(cid, door_id)
                # No standard lock command; the door re-locks automatically

        except Exception as e:
            self.logger.error(f"actionControlDevice error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    def actionControlDimmerRelay(self, action, dev):
        """Handle dimmer (brightness) actions for the UNAS fan.

        Three modes mapped to dimmer anchors:
          0%   → Quiet
          50%  → Balance
          100% → Cooling
        Intermediate values snap to the nearest anchor (0-24 Quiet,
        25-74 Balance, 75-100 Cooling). The dimmer brightness is forced
        to the snapped value so the UI matches the actual mode.
        """
        try:
            if dev.deviceTypeId != "driveFan":
                return

            self.logger.info(f"{dev.name}: fan dimmer action received (cmd={action.deviceAction})")

            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "drive_api" not in controller:
                self.logger.error(f"{dev.name}: Cannot set fan — Drive controller not connected")
                return

            # Determine target brightness
            cmd = action.deviceAction
            if cmd == indigo.kDimmerRelayAction.SetBrightness:
                target = action.actionValue
            elif cmd == indigo.kDimmerRelayAction.TurnOn:
                target = 100
            elif cmd == indigo.kDimmerRelayAction.TurnOff:
                target = 0
            elif cmd == indigo.kDimmerRelayAction.Toggle:
                target = 0 if dev.brightness > 0 else 100
            elif cmd == indigo.kDimmerRelayAction.BrightenBy:
                target = min(100, dev.brightness + action.actionValue)
            elif cmd == indigo.kDimmerRelayAction.DimBy:
                target = max(0, dev.brightness - action.actionValue)
            else:
                return

            # Snap to nearest anchor: 0=Quiet, 50=Balance, 100=Cooling
            if target <= 24:
                mode, snapped = "Quiet", 0
            elif target <= 74:
                mode, snapped = "Balance", 50
            else:
                mode, snapped = "Cooling", 100

            if target != snapped:
                self.logger.info(f"{dev.name}: Snapping brightness {target}% → {snapped}% ({mode})")

            method, ok, err = self._apply_fan_mode(cid, controller, mode, dev_for_log=dev)
            if not ok:
                self.logger.error(f"{dev.name}: Fan mode set FAILED via {method}: {err}")
                # Don't update dimmer brightness on failure — leave it where it
                # was so the user can see the change didn't stick.
                return

            # Force dimmer to the snapped value so the UI doesn't sit at a
            # value that doesn't correspond to a real mode.
            try:
                dev.updateStateOnServer("brightnessLevel", snapped)
            except Exception:
                pass

            # Refresh the actual reported state — confirms the API write took.
            self._update_fan_states(cid)
        except Exception as e:
            self.logger.error(f"actionControlDimmerRelay error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    # ------------------------------------------------------------------
    # Additional action handlers (compatibility with existing Actions.xml)
    # ------------------------------------------------------------------

    def actionRestartController(self, action):
        """Reboot the UniFi controller (UDM Pro etc) via the legacy power command."""
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                self.logger.error(f"{dev.name}: Network API not available")
                return
            # Legacy: POST /api/system/reboot — only available with legacy auth
            api = controller["network_api"]
            self.logger.info(f"{dev.name}: Rebooting controller (this will take several minutes)")
            try:
                api._legacy_request("POST", "/api/system/reboot")
            except Exception as e:
                self.logger.warning(f"Reboot command may have triggered disconnect: {e}")
        except Exception as e:
            self.logger.error(f"restartController error: {e}")

    def actionDisableDevice(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            d   = api.get_device(dev.pluginProps.get("deviceMac", ""))
            if not d:
                return
            api.disable_device(d["_id"], disabled=True)
            self.logger.info(f"{dev.name}: Disabled")
            self._update_netdev_states(cid, dev.pluginProps.get("deviceMac", "").lower())
        except Exception as e:
            self.logger.error(f"disableDevice error: {e}")

    def actionEnableDevice(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            d   = api.get_device(dev.pluginProps.get("deviceMac", ""))
            if not d:
                return
            api.disable_device(d["_id"], disabled=False)
            self.logger.info(f"{dev.name}: Enabled")
            self._update_netdev_states(cid, dev.pluginProps.get("deviceMac", "").lower())
        except Exception as e:
            self.logger.error(f"enableDevice error: {e}")

    def actionToggleDevice(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            currently_disabled = bool(dev.states.get("disabled", False))
            if currently_disabled:
                self.actionEnableDevice(action)
            else:
                self.actionDisableDevice(action)
        except Exception as e:
            self.logger.error(f"toggleDevice error: {e}")

    def actionToggleDeviceLED(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            d   = api.get_device(dev.pluginProps.get("deviceMac", ""))
            if not d:
                return
            currently_on = bool(dev.states.get("ledEnabled", False))
            api.set_device_led(d["_id"], not currently_on)
            self.logger.info(f"{dev.name}: LED {'off' if currently_on else 'on'}")
            self._update_netdev_states(cid, dev.pluginProps.get("deviceMac", "").lower())
        except Exception as e:
            self.logger.error(f"toggleDeviceLED error: {e}")

    # ----- Port actions -----

    def actionEnablePort(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            mac = dev.pluginProps.get("deviceMac", "")
            try:
                pidx = int(dev.pluginProps.get("portNumber", 0))
            except (TypeError, ValueError):
                return
            d = api.get_device(mac)
            if not d:
                return
            control_mode = dev.pluginProps.get("controlMode", "poe")
            if control_mode == "poe":
                api.set_port_poe_mode(d["_id"], pidx, "auto")
            else:
                api.set_port_override(d["_id"], pidx, {"port_idx": pidx, "forward": "all"})
            self.logger.info(f"{dev.name}: Enabled")
            self._update_port_states(cid, mac.lower(), pidx)
        except Exception as e:
            self.logger.error(f"enablePort error: {e}")

    def actionDisablePort(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            mac = dev.pluginProps.get("deviceMac", "")
            try:
                pidx = int(dev.pluginProps.get("portNumber", 0))
            except (TypeError, ValueError):
                return
            d = api.get_device(mac)
            if not d:
                return
            control_mode = dev.pluginProps.get("controlMode", "poe")
            if control_mode == "poe":
                api.set_port_poe_mode(d["_id"], pidx, "off")
            else:
                api.set_port_override(d["_id"], pidx, {"port_idx": pidx, "forward": "disabled"})
            self.logger.info(f"{dev.name}: Disabled")
            self._update_port_states(cid, mac.lower(), pidx)
        except Exception as e:
            self.logger.error(f"disablePort error: {e}")

    def actionCyclePort(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            mac = dev.pluginProps.get("deviceMac", "")
            try:
                pidx = int(dev.pluginProps.get("portNumber", 0))
            except (TypeError, ValueError):
                return
            api.cycle_port_poe(mac, pidx)
            self.logger.info(f"{dev.name}: Power-cycled")
            self._update_port_states(cid, mac.lower(), pidx)
        except Exception as e:
            self.logger.error(f"cyclePort error: {e}")

    def actionSetPoeMode(self, action):
        try:
            dev  = indigo.devices[action.deviceId]
            mode = action.props.get("poeMode", "auto")
            cid, controller = self._get_controller_for_dev(dev)
            if not controller or "network_api" not in controller:
                return
            api = controller["network_api"]
            mac = dev.pluginProps.get("deviceMac", "")
            try:
                pidx = int(dev.pluginProps.get("portNumber", 0))
            except (TypeError, ValueError):
                return
            d = api.get_device(mac)
            if not d:
                return
            api.set_port_poe_mode(d["_id"], pidx, mode)
            self.logger.info(f"{dev.name}: PoE mode set to {mode}")
            self._update_port_states(cid, mac.lower(), pidx)
        except Exception as e:
            self.logger.error(f"setPoeMode error: {e}")

    # ----- Client discovery (called from controller-scoped action menu) -----

    def actionDiscoverAllClients(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            try:
                min_days = int(action.props.get("minLastSeen", 30))
            except (TypeError, ValueError):
                min_days = 30
            self._discover_clients(dev.id, include_known=True, min_days=min_days)
        except Exception as e:
            self.logger.error(f"discoverAllClients error: {e}")

    def actionDiscoverUnknownClients(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            self._discover_clients(dev.id, include_known=False, min_days=0)
        except Exception as e:
            self.logger.error(f"discoverUnknownClients error: {e}")

    def actionRemoveMissingClients(self, action):
        try:
            dev = indigo.devices[action.deviceId]
            self._remove_missing_clients(dev.id)
        except Exception as e:
            self.logger.error(f"removeMissingClients error: {e}")

    def actionPurgeRandomisedClients(self, action):
        """Purge randomised-MAC clients that haven't been seen recently.

        Behaviour is governed by the controller's pluginProps:
          - purgeMinAgeHours      (default 24)
          - purgeSkipNamed        (default true)
          - purgeSkipMetadata     (default true)
          - purgeSkipIndigoDevice (default true)
          - purgeDryRun           (default false)
        """
        try:
            dev = indigo.devices[action.deviceId]
            self._purge_randomised_clients(dev.id)
        except Exception as e:
            self.logger.error(f"purgeRandomisedClients error: {e}")
            if self.debug:
                self.logger.error(traceback.format_exc())

    def _purge_randomised_clients(self, controller_id):
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            self.logger.error("Cannot purge: Network controller not connected")
            return
        api  = controller["network_api"]
        cdev = controller.get("device")
        cname = cdev.name if cdev else f"controller {controller_id}"

        props = cdev.pluginProps if cdev else {}
        try:
            min_age_hours = float(props.get("purgeMinAgeHours", 24) or 24)
        except (TypeError, ValueError):
            min_age_hours = 24.0
        skip_named    = bool(props.get("purgeSkipNamed", True))
        skip_metadata = bool(props.get("purgeSkipMetadata", True))
        skip_indigo   = bool(props.get("purgeSkipIndigoDevice", True))
        dry_run       = bool(props.get("purgeDryRun", False))
        min_age_sec   = min_age_hours * 3600.0

        # Build map of MAC -> Indigo device id for existing client devices,
        # so we know which to skip / which to delete after UniFi forget.
        indigo_macs = {}
        for d in indigo.devices.iter("self"):
            if d.deviceTypeId == "clientDevice":
                mac = (d.pluginProps.get("clientMac", "") or "").lower()
                if mac:
                    indigo_macs[mac] = d.id

        try:
            clients = api.get_all_clients() or []
        except Exception as e:
            self.logger.error(f"{cname}: Purge: failed to fetch client list: {e}")
            return

        # Categorise
        candidates    = []
        skipped_recent  = 0
        skipped_named   = 0
        skipped_meta    = 0
        skipped_indigo  = 0
        not_randomised  = 0
        now_ts = time.time()

        for c in clients:
            mac = (c.get("mac") or "").lower()
            if not mac:
                continue
            if not _mac_is_randomised(mac):
                not_randomised += 1
                continue
            age = _client_age_seconds(c, now_ts=now_ts)
            if age is None or age < min_age_sec:
                skipped_recent += 1
                continue
            if skip_named and _has_user_named_client(c):
                skipped_named += 1
                continue
            if skip_metadata and _has_user_metadata_other_than_name(c):
                skipped_meta += 1
                continue
            if skip_indigo and mac in indigo_macs:
                skipped_indigo += 1
                continue
            candidates.append((mac, c, age))

        action_word = "Would purge" if dry_run else "Purging"
        self.logger.info(
            f"{cname}: {action_word} {len(candidates)} randomised client(s) "
            f"(threshold {min_age_hours:.1f}h). "
            f"Skipped: {skipped_recent} too recent, {skipped_named} named, "
            f"{skipped_meta} metadata, {skipped_indigo} Indigo-tracked. "
            f"Non-randomised: {not_randomised}."
        )

        if not candidates:
            return

        purged_unifi  = 0
        purged_indigo = 0
        for mac, c, age in candidates:
            age_h = age / 3600.0
            display_name = c.get("name") or c.get("hostname") or c.get("oui") or mac
            line = f"  • {mac}  age={age_h:.1f}h  ({display_name})"
            self.logger.info(line)

            if dry_run:
                continue

            # 1. Ask UniFi to forget the client
            try:
                api.forget_client(mac)
                purged_unifi += 1
            except Exception as e:
                self.logger.error(f"    UniFi forget failed for {mac}: {e}")
                # If UniFi forget failed, still attempt Indigo removal — the
                # device is at least stale even if UniFi rejected the forget.

            # 2. Remove the Indigo device if one exists
            indigo_id = indigo_macs.get(mac)
            if indigo_id is not None:
                try:
                    indigo.device.delete(indigo_id)
                    purged_indigo += 1
                except Exception as e:
                    self.logger.error(f"    Indigo device delete failed for {mac}: {e}")

            # 3. Track in the deleted-clients set so future discovery doesn't
            # recreate it
            self.deleted_clients.add(mac)

        if not dry_run:
            try:
                self.pluginPrefs["deletedClients"] = list(self.deleted_clients)
            except Exception:
                pass
            self.logger.info(
                f"{cname}: Purge complete. {purged_unifi} forgotten in UniFi, "
                f"{purged_indigo} Indigo device(s) removed."
            )

    # Menu variants (use a controllerId from props instead of action.deviceId)
    def menuDiscoverCameras(self, valuesDict, typeId):
        try:
            cid = int(valuesDict.get("controllerId", 0))
            self.createCameraDevices(valuesDict, "protectCamera", cid)
        except Exception as e:
            self.logger.error(f"menuDiscoverCameras error: {e}")
        return valuesDict

    def menuDiscoverNetworkDevices(self, valuesDict, typeId):
        try:
            cid = int(valuesDict.get("controllerId", 0))
            self.createNetworkDevices(valuesDict, "networkDevice", cid)
        except Exception as e:
            self.logger.error(f"menuDiscoverNetworkDevices error: {e}")
        return valuesDict

    def menuDiscoverAllClients(self, valuesDict, typeId):
        try:
            cid = int(valuesDict.get("controllerId", 0))
            try:
                min_days = int(valuesDict.get("minLastSeen", 30))
            except (TypeError, ValueError):
                min_days = 30
            self._discover_clients(cid, include_known=True, min_days=min_days)
        except Exception as e:
            self.logger.error(f"menuDiscoverAllClients error: {e}")
        return valuesDict

    def menuDiscoverUnknownClients(self, valuesDict, typeId):
        try:
            cid = int(valuesDict.get("controllerId", 0))
            self._discover_clients(cid, include_known=False, min_days=0)
        except Exception as e:
            self.logger.error(f"menuDiscoverUnknownClients error: {e}")
        return valuesDict

    def menuRemoveMissingClients(self, valuesDict, typeId):
        try:
            cid = int(valuesDict.get("controllerId", 0))
            self._remove_missing_clients(cid)
        except Exception as e:
            self.logger.error(f"menuRemoveMissingClients error: {e}")
        return valuesDict

    # ----- Client discovery internals -----

    def _discover_clients(self, controller_id, include_known=True, min_days=30):
        """Create client devices, optionally filtered by last-seen window."""
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            self.logger.error("Cannot discover clients: Network not connected")
            return
        api = controller["network_api"]

        cutoff_ts = 0
        if min_days > 0:
            cutoff_ts = int(time.time()) - (min_days * 86400)

        try:
            active = api.get_clients()
        except Exception as e:
            self.logger.warning(f"Could not list active clients: {e}")
            active = []

        if include_known:
            try:
                known = api.get_all_clients()
            except Exception as e:
                self.logger.warning(f"Could not list known clients: {e}")
                known = []
        else:
            known = []

        # Merge by MAC, preferring active records (have more data)
        merged = {}
        for c in known:
            mac = (c.get("mac") or "").lower()
            if mac:
                merged[mac] = c
        for c in active:
            mac = (c.get("mac") or "").lower()
            if mac:
                merged[mac] = c

        # Existing devices, by MAC
        existing_macs = set()
        for d in indigo.devices.iter("self.clientDevice"):
            m = d.pluginProps.get("clientMac", "").lower()
            if m:
                existing_macs.add(m)

        created = 0
        skipped = 0
        for mac, c in merged.items():
            if mac in existing_macs:
                continue
            if mac in self.deleted_clients:
                skipped += 1
                continue
            last_seen = int(c.get("last_seen", 0) or 0)
            if cutoff_ts and last_seen and last_seen < cutoff_ts:
                continue
            if not include_known and last_seen and (time.time() - last_seen) < 0:
                # only unknown filter is just a presence filter; nothing more
                pass
            name     = c.get("name") or c.get("hostname") or c.get("oui") or mac
            props = {
                "controllerId": str(controller_id),
                "clientMac":    mac,
                "clientName":   name,
            }
            new_dev = self._create_or_skip(f"{name} (UniFi Client)", "clientDevice", props)
            if new_dev:
                created += 1
        self.logger.info(f"Client discovery: {created} created, {skipped} skipped (previously deleted)")

    def _remove_missing_clients(self, controller_id):
        """Remove client devices whose MAC is not in the controller's known set."""
        controller = self.controllers.get(controller_id)
        if not controller or "network_api" not in controller:
            self.logger.error("Cannot remove missing clients: Network not connected")
            return
        api = controller["network_api"]
        try:
            known_macs = {(c.get("mac") or "").lower()
                          for c in api.get_all_clients() + api.get_clients()}
        except Exception as e:
            self.logger.error(f"Could not list known clients: {e}")
            return

        removed = 0
        for d in list(indigo.devices.iter("self.clientDevice")):
            try:
                cid_dev = int(d.pluginProps.get("controllerId", 0))
            except (TypeError, ValueError):
                continue
            if cid_dev != controller_id:
                continue
            mac = d.pluginProps.get("clientMac", "").lower()
            if mac and mac not in known_macs:
                self.logger.info(f"Removing missing client device: {d.name}")
                self.deleted_clients.add(mac)
                indigo.device.delete(d.id)
                removed += 1
        # Persist deleted list so we don't auto-recreate
        try:
            self.pluginPrefs["deletedClients"] = list(self.deleted_clients)
        except Exception:
            pass
        self.logger.info(f"Client cleanup: {removed} removed")

    # ------------------------------------------------------------------
    # Track client deletion to avoid auto-recreation
    # ------------------------------------------------------------------

    def deviceDeleted(self, dev):
        try:
            if dev.deviceTypeId == "clientDevice":
                mac = dev.pluginProps.get("clientMac", "").lower()
                if mac:
                    self.deleted_clients.add(mac)
                    try:
                        self.pluginPrefs["deletedClients"] = list(self.deleted_clients)
                    except Exception:
                        pass
        except Exception:
            pass
        super().deviceDeleted(dev)
