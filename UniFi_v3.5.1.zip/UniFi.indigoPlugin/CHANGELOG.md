# Changelog

All notable changes to this project are documented here. This starts at
3.2.0 (the official-Integration-API rewrite); earlier history predates
public release.

## [3.5.1] - Auto-redeploy fan control

- Drive controller now checks once a day whether the SSH-deployed fan
  control service is still present on the UNAS, and silently redeploys it if
  a UniFi OS update has wiped it. Opt-out checkbox provided (default on).
  Only acts if the plugin previously did a manual deploy - first-time setup
  is never automatic.

## [3.5.0] - Randomised client purge

- New per-controller settings and a Purge Randomised Clients action.
  Detects locally-administered/randomised MAC addresses (iPhone Private
  Address, Android random MAC, etc.) per the IEEE 802 U/L bit rule, skips
  anything named, fixed-IP'd, grouped, or already tracked as an Indigo
  device, and removes stale entries from both UniFi (forget-sta) and
  Indigo. Configurable age threshold and a dry-run mode for safe testing.

## [3.4.2] - Fan control UX and correctness fixes

- Deploy/Test/Remove fan control buttons now build their SSH session from
  the values currently in the config dialog, so they work without saving
  first.
- Dimmer state for the fan device now sources its "current mode" from the
  SSH-deployed config file when fan control is deployed, instead of the
  UniFi REST API (which kept reporting a stale profile since the API can't
  be told about the SSH-driven changes). Fixes dimmer resetting to 100%
  every poll cycle.
- Added a Run Fan Control Diagnostic action: one-shot script run,
  service status, last 30 systemd journal lines, and current PWM register
  values, all returned in a single log block.
- Fan control script now logs to the systemd journal in service mode
  (previously silent) and reads back PWM values after every write to
  confirm they stuck.

## [3.4.1] - Startup crash fix

- Fixed NameError: name '__file__' is not defined on plugin startup.
  Indigo's plugin host runs plugin.py via exec(), so __file__ isn't
  set in the module namespace. Asset loading now falls back to the current
  working directory (which Indigo does set correctly) and then to known
  Indigo install paths.

## [3.4.0] - SSH-based fan control

- UniFi's own fan-control write API (PUT /proxy/drive/api/v2/systems/fan-control)
  was confirmed broken on current UNAS firmware - every payload shape
  returns HTTP 500, verified with a standalone probe script trying ~20
  variants (verbs, paths, payload wrappers). This is a firmware limitation,
  not a plugin bug.
- Added SSH-based fan control as a workaround: a bundled script (adapted
  from hoxxep/UNAS-Pro-fan-control) and systemd service, deployed to the
  UNAS on demand, that writes fan PWM directly via sysfs.
- New controller config fields: enable SSH, username/password/port, deploy
  and remove buttons.
- paramiko added to requirements.txt.

## [3.3.8] - Dimmer routing bug

- Found and fixed a routing bug where, because the plugin defines both
  actionControlDevice and actionControlDimmerRelay, Indigo routes ALL
  device actions (including dimmer brightness) through
  actionControlDevice. The fan dimmer's brightness changes were silently
  swallowed as a result. actionControlDevice now delegates to the dimmer
  handler for fan devices.

## [3.3.7] - Fan mode mapping

- Fan dimmer brightness anchors changed to 0% / 50% / 100% for
  Quiet / Balance / Cooling, with snap-to-nearest behaviour for
  intermediate values.
- Fan mode API write now tries multiple payload variants
  (profile/mode fields, with/without an apply flag).

## [3.3.6] - Duplicate-device detection bug

- Fixed _create_or_skip's uniqueness check silently treating every
  existing device of a type as a duplicate when the device type's key prop
  (e.g. diskKey, poolKey) wasn't in its recognised list - caused by
  Python's all([]) == True. Only the first disk/pool of a given type was
  ever being created; subsequent discovery runs reported "0 new" even
  though more existed. Added diskKey/poolKey to the match logic and a
  name-based fallback.

## [3.3.5] - Drive payload field corrections

- Corrected disk parsing to match real UNAS firmware payloads: disks live
  at the top level of the storage response (not nested per-pool), linked to
  their pool via poolId. Field names corrected (state not status,
  size not capacity, slotId for naming). RAID level sourced from
  preferLevel, rebuild progress from raidGroups[0].progress. At-risk
  detection uses the riskReasons array.
- Added fullyOperational/optimal (and other firmware-specific spellings)
  to the healthy-status whitelist.

## [3.3.4] - Access WebSocket crash fix

- Fixed 'str' object has no attribute 'get' in the Access WebSocket
  handler - some messages arrive as plain strings or JSON-as-string rather
  than parsed dicts. Handler now normalises and safely ignores anything it
  can't turn into a usable event.

## [3.3.3] - Drive device consolidation

- Removed the standalone unifiDrive appliance device type. All UNAS
  appliance-level data (storage totals, system info, pool/disk counts) now
  lives directly on the Drive controller device, avoiding duplicate state
  across two devices.

## [3.3.2] - Device creation crash fix

- Fixed indigo.device.create() failing with a C++ signature mismatch
  across every discovery button in the plugin (cameras, sensors, network
  devices, doors, pools, disks). The required protocol keyword argument
  was missing from the call.

## [3.3.1] - Drive Pool and Disk device types

- Corrected Drive API endpoints to the /proxy/drive/api/v2/ paths
  (confirmed against community reverse-engineering, since no official Drive
  API exists).
- Added unifiDrivePool and unifiDriveDisk device types with discovery
  actions, so multi-pool/multi-disk UNAS systems get one device per
  pool/disk rather than a single aggregate.

## [3.3.0] - Drive controller split

- Split the single controller device type into unifiController (Network /
  Protect / Access) and unifiDriveController (Drive/UNAS), since a UNAS is
  a separate appliance with its own IP and auth.
- Added device-name prefix/suffix options, applied consistently across all
  discovery types.

## [3.2.0] - Integration API rewrite

- Migrated Protect and Access to Ubiquiti's official Integration APIs
  (Bearer auth, JSON WebSockets). Motion, smart detection, and doorbell
  events now arrive in ~100ms over WebSocket instead of polling.
- Network uses the Integration API by default with a documented legacy
  fallback for endpoints not yet covered (port tables, radio tables, PoE
  overrides, client block/unblock).
- Rearchitected polling: WebSocket for real-time state, polling only for
  slow-changing stats, with configurable stats/sanity intervals.
- Exponential WebSocket reconnect backoff (5s to 5min).
